<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Skill Widget .
 *
 */
class artraz_Skill extends Widget_Base {

	public function get_name() {
		return 'artrazskill';
	}

	public function get_title() {
		return __( 'Skill Bar', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

    $this->start_controls_section(
			'skill_bar_section',
				[
					'label' 	=> __( 'Skill Bar', 'artraz' ),
					'tab' 		=> Controls_Manager::TAB_CONTENT,
				]
    );

    $this->add_control(
            'layout_style',
            [
                'label' 	=> __( 'Layout Style', 'artraz' ),
                'type' 		=> Controls_Manager::SELECT,
                'default' 	=> '1',
                'options' 	=> [
                    '1'  		=> __( 'Style One', 'artraz' ),
                ],
            ]
    );

	$repeater = new Repeater();

	$repeater->add_control(
			'skill_title',
				[
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'Skill' , 'artraz' ),
				'label_block'   => true,
			   ]
		);

    $repeater->add_control(
			'skill_num',
				[
				'label'         => __( 'Number', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( '90' , 'artraz' ),
				'label_block'   => true,
			   ]
		);

	$this->add_control(
			'skill_lists',
			[
				'label' 		=> __( 'Skill Lists', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
						[
							'skill_title' 		=> __( 'Title', 'artraz' ),
						],
				],
			]
	);

    $this->end_controls_section();

    //---------------------------------------
        //Style Section Start
    //---------------------------------------

	//-------------------------------------General styling-------------------------------------//

    $this->start_controls_section(
        'general_section',
        [
            'label' => __( 'General Style', 'artraz' ),
            'tab' 	=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'general_color',
        [
            'label' 	=> __( 'Bar Background', 'artraz' ),
            'type' 		=> Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .skill-feature .progress' => 'background-color: {{VALUE}}!important;',
            ],
        ]
    );

    $this->add_control(
        'general_color2',
        [
            'label' 	=> __( 'Bar Color', 'artraz' ),
            'type' 		=> Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .skill-feature .progress-bar' => 'background-color: {{VALUE}}!important;',
            ],
        ]
    );

    $this->end_controls_section();

	//-------------------------------------title styling-------------------------------------//

    $this->start_controls_section(
			'title_style_section',
			[
				'label' => __( ' Title Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

    $this->add_control(
        'title_color',
        [
            'label' 	=> __( 'Color', 'artraz' ),
            'type' 		=> Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .skill-feature_title' => 'color: {{VALUE}}!important;',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' 		=> 'title_typography',
            'label' 	=> __( 'Typography', 'artraz' ),
            'selector' 	=> '{{WRAPPER}} .skill-feature_title',
        ]
    );

    $this->add_responsive_control(
        'title_padding',
        [
            'label' 		=> __( 'Padding', 'artraz' ),
            'type' 			=> Controls_Manager::DIMENSIONS,
            'size_units' 	=> [ 'px', '%', 'em' ],
            'selectors' 	=> [
                '{{WRAPPER}} .skill-feature_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]
    );

    $this->end_controls_section();

    //-------------------------------------Number styling-------------------------------------//

    $this->start_controls_section(
        'content_style_section',
        [
            'label' => __( 'Number Style', 'artraz' ),
            'tab' 	=> Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'content_bg_color',
        [
            'label' 	=> __( 'Background Color', 'artraz' ),
            'type' 		=> Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .progress-value' => '--theme-color: {{VALUE}}!important;',
            ],
        ]
    );

    $this->add_control(
        'content_color',
        [
            'label' 	=> __( 'Color', 'artraz' ),
            'type' 		=> Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .progress-value' => 'color: {{VALUE}}!important;',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' 		=> 'content_typography',
            'label' 	=> __( '  Typography', 'artraz' ),
            'selector' 	=> '{{WRAPPER}} .progress-value',
        ]
    );

    $this->end_controls_section();


	}

	protected function render() {

    $settings = $this->get_settings_for_display();
    ?>

    <?php if( $settings['layout_style'] == '2' ): ?>

    <?php else: ?>
        <?php foreach( $settings['skill_lists'] as $data ): ?>
        <div class="skill-feature">
            <p class="skill-feature_title"><?php echo esc_html($data['skill_title']) ?></p>
            <div class="progress">
                <div class="progress-bar" style="width: <?php echo esc_attr($data['skill_num']) ?>%;">
                    <p class="progress-value"><?php echo esc_html($data['skill_num']) ?><?php echo esc_html__('%', 'artraz') ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        
    <?php endif; 

	}

}