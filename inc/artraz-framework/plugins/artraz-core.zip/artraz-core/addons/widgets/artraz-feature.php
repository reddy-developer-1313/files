<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Feature Widget .
 *
 */
class Artraz_feature extends Widget_Base {

	public function get_name() {
		return 'artrazfeature';
	}

	public function get_title() {
		return __( 'Features', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		 $this->start_controls_section(
			'service_section',
			[
				'label'     => __( 'Features', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2'  		=> __( 'Style Two', 'artraz' ),
				],
			]
		);


		$repeater = new Repeater();

		$repeater->add_control(
			'feature_icon',
			[
				'label'     => __( 'Icon Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'feature_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'feature_content',
            [
				'label'         => __( 'Content', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4'
			]
		);

		$this->add_control(
			'feature_list',
			[
				'label' 		=> __( 'Feature List', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'feature_title' 		=> __( 'Reasonable Prices', 'artraz' ),
					],
					[
						'feature_title' 		=> __( 'Exclusive Design', 'artraz' ),
					],
				],
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------Genearl styling-------------------------------------//

        $this->start_controls_section(
			'general_section',
			[
				'label' => __( ' General Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			
			]
		);

		$this->add_control(
			'general_color',
			[
				'label' 	=> __( 'Background', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-card' => 'background-color: {{VALUE}}!important;',
                ],
			]
        );	

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .feature-card',
			]
		);

		$this->add_responsive_control(
			'general_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .feature-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------Title styling------------------------------------*/

		$this->start_controls_section(
			'service_title_style',
			[
				'label' 	=> __( 'Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h4, {{WRAPPER}} h3'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'title_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} h4, {{WRAPPER}} h3',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4, {{WRAPPER}} h3 ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h4, {{WRAPPER}} h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

		/*-----------------------------------------Contetn styling------------------------------------*/

		$this->start_controls_section(
			'service_desc_style',
			[
				'label' 	=> __( 'Content Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} p'	=> 'color: {{VALUE}}!important;',
				],
			]
        );					
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'desc_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} p',
			]
		);

        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <?php if( $settings['layout_style'] == '2' ): ?>
      		<div class="about-feature-wrap">
      			<?php foreach( $settings['feature_list'] as $data ):  ?> 
	                <div class="about-feature">
	                    <div class="box-icon">
	                        <?php echo artraz_img_tag( array(
								'url'   => esc_url( $data['feature_icon']['url']  ),
							)); ?>
	                    </div>
	                    <h4 class="box-title"><?php echo esc_html( $data['feature_title'] );  ?></h4>
	                    <p class="box-text"><?php echo esc_html( $data['feature_content'] );  ?></p>
	                </div>
                <?php endforeach; ?>
                

            </div>
    	<?php else: ?>
        <div class="row gy-4">
            <?php 
			$x = 1;
			foreach( $settings['feature_list'] as $data ):  
			$x++; 
			?>
            <div class="col-xl-4 col-md-6">
                <div class="feature-card">
                    <div class="feature-card_icon shape-icon">
                        <?php echo artraz_img_tag( array(
							'url'   => esc_url( $data['feature_icon']['url']  ),
                            'class' => 'svg-img',
						)); ?>
                    </div>
                    <h3 class="feature-card_title"><?php echo esc_html( $data['feature_title'] );  ?></h3>
                    <p class="feature-card_text"><?php echo esc_html( $data['feature_content'] );  ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

      <?php endif; 

	}

}