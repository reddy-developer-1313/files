<?php

use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Text_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Header Widget .
 *
 */
class Artraz_Header extends Widget_Base {

	public function get_name() {
		return 'artrazheader';
	}
	public function get_title() {
		return __( 'Header', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz_header_elements' ];
	}
	protected function register_controls() {

		$this->start_controls_section(
			'layout_section',
			[
				'label' 	=> __( 'Header', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'1' => __( 'Style One', 'artraz' ),
					'2' => __( 'Style Two', 'artraz' ),
					'3' => __( 'Style Three', 'artraz' ),
					'4' => __( 'Style Four', 'artraz' ),
				],
				'default' => '1',
			]
        );
        $this->add_control(
			'style',
			[
				'label' 		=> __( 'Switch To difrance style?', 'artraz' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'artraz' ),
				'label_off' 	=> __( 'Hide', 'artraz' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 
					'layout_style'  => ['2'],
				],
			]
		);

		$this->add_control(
			'show_top_bar',
			[
				'label' 		=> __( 'Show Top Bar?', 'artraz' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'artraz' ),
				'label_off' 	=> __( 'Hide', 'artraz' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'condition'		=> [ 
					'layout_style'  => ['1', '2', '4'],
				],
			]
		);

		$this->add_control(
			'topbar_phone_icon',
			[
				'label' 		=> __( 'Phone Icon', 'artraz' ),
				'type' 			=> Controls_Manager::TEXT,
				'label_block' 	=> true,
				'default' 		=> '<i class="fat fa-phone"></i>',
				'condition'		=> [ 
					'layout_style'  => ['2', '3', '4'],
				],
			]
		);

		$this->add_control(
			'topbar_phone',
			[
				'label' 	=> __( 'Phone Number', 'artraz' ),
				'type' 		=> Controls_Manager::TEXT,
				'default' 	=> __( '(+153)-987-3657', 'artraz' ),
				'label_block' => true,
				'separator'		=> 'after',
				'condition'		=> [ 
					'layout_style'  => ['2', '3', '4'],
				],
			]
		);

		//Social 
		$this->add_control(
			'show_social',
			[
				'label' 		=> __( 'Show Social?', 'artraz' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Show', 'artraz' ),
				'label_off' 	=> __( 'Hide', 'artraz' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
				'separator'		=> 'before',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'social_icon',
			[
				'label' 	=> __( 'Social Icon', 'artraz' ),
				'type' 		=> Controls_Manager::ICONS,
				'default' 	=> [
					'value' 	=> 'fab fa-facebook-f',
					'library' 	=> 'solid',
				],
			]
		);

		$repeater->add_control(
			'icon_link',
			[
				'label' 		=> __( 'Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

		$this->add_control(
			'social_icon_list',
			[
				'label' 		=> __( 'Social Icon', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' => __( 'Add Social Icon','artraz' ),
					],
				],
				'condition'		=> [ 
					'show_social'  => 'yes',
					'layout_style'  => ['1', '2', '3'],
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'social_name',
			[
				'label' 	=> __( 'Social Name', 'artraz' ),
				'type' 			=> Controls_Manager::TEXT,
				'default' 	=> __( 'Facebook', 'artraz' ),
			]
		);

		$repeater->add_control(
			'icon_link',
			[
				'label' 		=> __( 'Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> true,
					'nofollow' 		=> true,
				],
			]
		);

		$this->add_control(
			'social_icon_list2',
			[
				'label' 		=> __( 'Social Icon', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' => __( 'Add Social Icon','artraz' ),
					],
				],
				'condition'		=> [ 
					'show_social'  => 'yes',
					'layout_style'  => '4',
				],
			]
		);

		$this->add_control(
			'logo_image',

			[
				'label' 		=> __( 'Upload Logo', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition'		=> [ 
					'layout_style'  => ['1', '2', '4'],
				],
			]
		);		

		$menus = $this->artraz_menu_select();

		if( !empty( $menus ) ){
	        $this->add_control(
				'artraz_menu_select',
				[
					'label'     	=> __( 'Select Artraz Menu', 'artraz' ),
					'type'      	=> Controls_Manager::SELECT,
					'options'   	=> $menus,
					'description' 	=> sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'artraz' ), admin_url( 'nav-menus.php' ) ),
					'condition'		=> [ 
						'layout_style'  => ['1', '2', '4'],
					],
				]
			);
		}else {
			$this->add_control(
				'no_menu',
				[
					'type' 				=> Controls_Manager::RAW_HTML,
					'raw' 				=> '<strong>' . __( 'There are no menus in your site.', 'artraz' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'artraz' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' 		=> 'after',
					'content_classes' 	=> 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}

		$this->add_control(
			'menu_bar_text',
			[
				'label' 		=> __( 'Menu Bar Text', 'artraz' ),
				'type' 			=> Controls_Manager::TEXT,
				'label_block' 	=> true,
				'default' 		=> 'Menu',
				'condition'		=> [ 
					'layout_style'  => ['3'],
				],
			]
		);

        $this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-----------------------------------General BG Styling-------------------------------------//
		 $this->start_controls_section(
			'general_styling',
			[
				'label'     => __( 'Background Styling', 'artraz' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'topbar_background_color',
			[

				'label'     => __( 'TopBar Background', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-top' => 'background-color: {{VALUE}}!important',
                ],
				'condition'		=> [ 
					'layout_style'  => ['1', '4'],
				],
			]
        );

		$this->add_control(
			'topbar_social_bg',
			[
				'label'     => __( 'Social Background', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .th-social' => 'background-color: {{VALUE}}!important',
                ],
				'condition'		=> [ 
					'layout_style'  => ['1'],
				],
			]
        );

        $this->add_control(
			'header_menu_bg',
			[
				'label' 		=> __( 'Menu Background', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .menu-area' => 'background-color: {{VALUE}} !important;',
                ],
			]
        );    
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Menu Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .menu-area',
			]
		);

		$this->add_control(
			'menu_bar_color',
			[
				'label' 		=> __( 'Menu Bar Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-menu-toggle' => 'color: {{VALUE}} !important;',
                ],
				'condition'		=> [ 
					'layout_style'  => ['3'],
				],
			]
        );  

		$this->add_control(
			'menu_bar_bg',
			[
				'label' 		=> __( 'Menu Bar Background', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-menu-toggle' => 'background-color: {{VALUE}} !important;',
                ],
				'condition'		=> [ 
					'layout_style'  => ['3'],
				],
			]
        ); 

		$this->end_controls_section();

       //-----------------------------------Topbar Styling-------------------------------------//
        $this->start_controls_section(
			'content_styling',
			[
				'label'     => __( 'Content Styling', 'artraz' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition'		=> [ 
					'layout_style'  => ['2', '3'],
				],
			]
        );

		$this->add_control(
			'content_color',
			[

				'label'     => __( 'Content Color', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-links li a' => 'color: {{VALUE}}!important',
                ],
				
			]
        );		

        $this->add_control(
			'content__h_color',
			[

				'label'     => __( 'Content Hover Color', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .header-links li a:hover' => 'color: {{VALUE}}!important;',
                ],
				
				
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'content_typography',
				'label' 	=> __( 'Content Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .header-links li a',
			]
        );

        
        $this->end_controls_section();

        //-----------------------------------Social Styling-------------------------------------//
        $this->start_controls_section(
			'social_styling',
			[
				'label'     => __( 'Social Styling', 'artraz' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition'		=> [ 
					'layout_style'  => ['1', '2', '3'],
				],
			]
        );

        $this->add_control(
			'topbar_social_color',
			[

				'label'     => __( 'Social Color', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .th-social a' => 'color: {{VALUE}}!important;',
                ],
				
				'separator'	=> 'before'
			]
        );
         $this->add_control(
			'topbar_social__h_color',
			[

				'label'     => __( 'Social Hover Color', 'artraz' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}}  .th-social a:hover' => 'color: {{VALUE}}!important;',
                ],
				
			]
        );
		$this->add_control(
			'social_font_size',
			[
				'label' => esc_html__( 'Icon Font Size', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 40,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .th-social a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        //-----------------------------------Menubar Styling-------------------------------------//
        $this->start_controls_section(
			'menubar_styling',
			[
				'label'     => __( 'Menu Styling', 'artraz' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition'		=> [ 
					'layout_style'  => ['1', '2', '4'],
				],
			]
        );
        $this->add_control(
			'menu_etxt_color',
			[
				'label' 			=> __( 'Menu Text Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} .main-menu>ul>li>a' => 'color: {{VALUE}} !important;',
                ]
			]
        );
        $this->add_control(
			'menu_text_hover_color',
			[
				'label' 			=> __( 'Menu Hover Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} .main-menu>ul>li>a:hover' => 'color: {{VALUE}} !important;',
                ]
			]
        );
        $this->add_control(
			'dropdown_txt_color',
			[
				'label' 			=> __( 'Dropdown Text Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} .main-menu ul.sub-menu li a' => 'color: {{VALUE}} !important;',
                ]
			]
        );
        $this->add_control(
			'dropdown_txt_hover_color',
			[
				'label' 			=> __( 'Dropdown Hover Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} .main-menu ul.sub-menu li a:hover' => 'color: {{VALUE}} !important;',
                ]
			]
        );
		$this->add_control(
			'dropdown_icon_color',
			[
				'label' 			=> __( 'Dropdown Icon Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} .main-menu ul.sub-menu li a:before' => 'color: {{VALUE}} !important;',
                ]
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 			=> 'menu_typography',
				'label' 		=> __( 'Menu Typography', 'artraz' ),
                'selector' 		=> '{{WRAPPER}} .main-menu>ul>li>a, {{WRAPPER}} .main-menu ul.sub-menu li a',
			]
		);

        $this->add_responsive_control(
			'menu_margin',
			[
				'label' 		=> __( 'Menu Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu>ul>li>a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ]
			]
        );

        $this->add_responsive_control(
			'menu_padding',
			[
				'label' 		=> __( 'Menu Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .main-menu>ul>li>a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
                ]
			]
		);

		$this->end_controls_section();

    }

    public function artraz_menu_select(){
	    $artraz_menu = wp_get_nav_menus();
	    $menu_array  = array();
		$menu_array[''] = __( 'Select A Menu', 'artraz' );
	    foreach( $artraz_menu as $menu ){
	        $menu_array[ $menu->slug ] = $menu->name;
	    }
	    return $menu_array;
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        //Menu by menu select
        $artraz_avaiable_menu   = $this->artraz_menu_select();
		if( ! $artraz_avaiable_menu ){
			return;
		}
		$args = [
			'menu' 			=> $settings['artraz_menu_select'],
			'menu_class' 	=> 'artraz-menu',
			'container' 	=> '',
		];

		 if( class_exists( 'ReduxFramework' ) ){
			 if(artraz_opt('artraz_menu_icon')){
	            $menu_icon = '';
	        }else{
	            $menu_icon = 'hide-icon';
	        }
	    }

		//Mobile menu 
        echo artraz_mobile_menu();

		?>

		<?php if( $settings['layout_style'] == '2' ): 
			$phone    	= $settings['topbar_phone'];
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$phoneurl       = str_replace( $replace_phone, $with, $phone );

			$style = $settings['style'] == 'yes' ? '' : 'bg-style2';

		?>
		<div class="th-header header-layout2  <?php echo esc_attr($style) ?>">
			<div class="sticky-wrapper">
				<div class="sticky-active">
					<div class="th-container container">
						<!-- Main Menu Area -->
						<div class="menu-area">
							<div class="row align-items-center justify-content-between">
								<div class="col-auto">
									<div class="header-logo">
										<a href="<?php echo esc_url( home_url( '/' ) ) ?>">
											<?php echo artraz_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url']  ),
											)); ?>
										</a>
									</div>
								</div>
								<div class="col-auto">
									<?php if(!empty( $settings['show_top_bar'])): ?>
									<div class="menu-top d-none d-md-block">
										<div class="row justify-content-end">
											<?php if(!empty( $phone)): ?>
											<div class="col-auto">
												<div class="header-links">
													<ul>
														<li><a href="<?php echo esc_attr('tel:' . $phoneurl); ?>" class="header-call"> <?php echo wp_kses_post($settings['topbar_phone_icon']); ?><?php echo esc_html($phone); ?></a></li>
													</ul>
												</div>
											</div>
											<?php endif; ?>
											<?php if($settings['show_social']): ?>
												<div class="col-auto">
													<div class="th-social">
													<?php	 foreach( $settings['social_icon_list'] as $social_icon ): 
															$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
															$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
														?>
														<a <?php echo esc_html($social_target) ?> <?php echo esc_html($social_nofollow) ?> href="<?php echo esc_url( $social_icon['icon_link']['url'] ) ?>"> <?php \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] ); ?></a> 
													<?php endforeach; ?>
													</div>
												</div>
											<?php endif; ?>
										</div>
									</div>
									<?php endif; ?>
									<nav class="main-menu <?php echo esc_attr($menu_icon); ?> d-none d-lg-inline-block">
										<?php if( ! empty( $settings['artraz_menu_select'] ) ){
											wp_nav_menu( $args );
										} ?>
									</nav>
									<button type="button" class="th-menu-toggle d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<?php elseif( $settings['layout_style'] == '3' ): 
			$phone    	= $settings['topbar_phone'];
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$phoneurl       = str_replace( $replace_phone, $with, $phone );
		?>
		<div class="th-header header-layout3">
			<!-- Main Menu -->
			<div class="sticky-wrapper">
				<div class="sticky-active">
					<div class="th-container container">
						<div class="menu-area">
							<div class="row justify-content-between align-items-center">
								<div class="col-auto">
									<button class="th-menu-toggle"><i class="fa-regular fa-bars-staggered"></i><?php echo esc_html($settings['menu_bar_text']); ?></button>
								</div>
								<div class="col-auto d-flex align-items-center">
									<?php if(!empty( $phone)): ?>
										<div class="header-links d-none d-sm-block">
											<ul>
												<li><a href="<?php echo esc_attr('tel:' . $phoneurl); ?>" class="header-call"> <?php echo wp_kses_post($settings['topbar_phone_icon']); ?><?php echo esc_html($phone); ?></a></li>
											</ul>
										</div>
									<?php endif; ?>
									<?php if($settings['show_social']): ?>
										<div class="th-social ms-5">
											<?php foreach( $settings['social_icon_list'] as $social_icon ): 
												$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
												$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
											?>
												<a <?php echo esc_html($social_target) ?> <?php echo esc_html($social_nofollow) ?> href="<?php echo esc_url( $social_icon['icon_link']['url'] ) ?>"> <?php \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] ); ?></a> 
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
		<?php elseif( $settings['layout_style'] == '4' ): 
			$phone    	= $settings['topbar_phone'];
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$phoneurl       = str_replace( $replace_phone, $with, $phone );
		?>
			<div class="th-header header-layout1">
				<?php if(!empty( $settings['show_top_bar'])): ?>
				<div class="header-top">
					<div class="th-container container">
						<div class="row justify-content-center justify-content-sm-between align-items-center">
							<?php if($settings['show_social']): ?>
							<div class="col-auto">
								<div class="header-links">
									<ul>
										<?php foreach( $settings['social_icon_list2'] as $data ): 
												$social_target    = $data['icon_link']['is_external'] ? ' target="_blank"' : '';
												$social_nofollow  = $data['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
											?>
											<li><a <?php echo esc_html($social_target) ?> <?php echo esc_html($social_nofollow) ?> href="<?php echo esc_url( $data['icon_link']['url'] ) ?>"> <?php echo esc_html($data['social_name']); ?></a></li>
										<?php endforeach; ?>
									</ul>
								</div>
							</div>
							<?php endif; ?>
							<?php if(!empty( $phone)): ?>
							<div class="col-auto d-none d-sm-block">
								<div class="header-links">
									<ul>
										<li><a href="<?php echo esc_attr('tel:' . $phoneurl); ?>" class="header-call"> <?php echo wp_kses_post($settings['topbar_phone_icon']); ?><?php echo esc_html($phone); ?></a></li>
									</ul>
								</div>
							</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
				<?php endif; ?>

				<div class="sticky-wrapper">
					<div class="sticky-active">
						<!-- Main Menu Area -->
						<div class="menu-area">
							<div class="container">
								<div class="row align-items-center justify-content-between">
									<div class="col-auto">
										<div class="header-logo">
											<a href="<?php echo esc_url( home_url( '/' ) ) ?>">
												<?php echo artraz_img_tag( array(
													'url'   => esc_url( $settings['logo_image']['url']  ),
												)); ?>
											</a>
										</div>
									</div>
									<div class="col-auto">
										<nav class="main-menu <?php echo esc_attr($menu_icon); ?> d-none d-lg-inline-block">
											<?php if( ! empty( $settings['artraz_menu_select'] ) ){
												wp_nav_menu( $args );
											} ?>
										</nav>
										<button type="button" class="th-menu-toggle d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		<?php else: ?>
		<div class="th-header header-layout4">
			<?php if(!empty( $settings['show_top_bar'])): ?>
			<div class="header-top">
				<div class="th-container container">
					<?php if($settings['show_social']): ?>
						<div class="social-box">
							<div class="th-social">
							<?php	 
								foreach( $settings['social_icon_list'] as $social_icon ): 
								$social_target    = $social_icon['icon_link']['is_external'] ? ' target="_blank"' : '';
								$social_nofollow  = $social_icon['icon_link']['nofollow'] ? ' rel="nofollow"' : '';
							?>
								<a <?php echo esc_html($social_target) ?> <?php echo esc_html($social_nofollow) ?> href="<?php echo esc_url( $social_icon['icon_link']['url'] ) ?>"> <?php \Elementor\Icons_Manager::render_icon( $social_icon['social_icon'], [ 'aria-hidden' => 'true' ] ); ?></a> 
							<?php endforeach; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<?php endif; ?>

			<div class="sticky-wrapper">
				<div class="sticky-active">
					<!-- Main Menu Area -->
					<div class="menu-area">
						<div class="container">
							<div class="row align-items-center justify-content-between">
								<div class="col-auto">
									<div class="header-logo">
										<a href="<?php echo esc_url( home_url( '/' ) ) ?>">
											<?php echo artraz_img_tag( array(
												'url'   => esc_url( $settings['logo_image']['url']  ),
											)); ?>
										</a>
									</div>
								</div>
								<div class="col-auto">
									<nav class="main-menu <?php echo esc_attr($menu_icon); ?> d-none d-lg-inline-block">
										<?php if( ! empty( $settings['artraz_menu_select'] ) ){
											wp_nav_menu( $args );
										} ?>
									</nav>
									<button type="button" class="th-menu-toggle d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php endif; 

	}
}