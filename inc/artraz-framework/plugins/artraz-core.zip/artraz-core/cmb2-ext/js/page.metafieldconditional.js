(function($){
    "use strict";
    
    let $artraz_page_breadcrumb_area      = $("#_artraz_page_breadcrumb_area");
    let $artraz_page_settings             = $("#_artraz_page_breadcrumb_settings");
    let $artraz_page_breadcrumb_image     = $("#_artraz_breadcumb_image");
    let $artraz_page_title                = $("#_artraz_page_title");
    let $artraz_page_title_settings       = $("#_artraz_page_title_settings");

    if( $artraz_page_breadcrumb_area.val() == '1' ) {
        $(".cmb2-id--artraz-page-breadcrumb-settings").show();
        if( $artraz_page_settings.val() == 'global' ) {
            $(".cmb2-id--artraz-breadcumb-image").hide();
            $(".cmb2-id--artraz-page-title").hide();
            $(".cmb2-id--artraz-page-title-settings").hide();
            $(".cmb2-id--artraz-custom-page-title").hide();
            $(".cmb2-id--artraz-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--artraz-breadcumb-image").show();
            $(".cmb2-id--artraz-page-title").show();
            $(".cmb2-id--artraz-page-breadcrumb-trigger").show();
    
            if( $artraz_page_title.val() == '1' ) {
                $(".cmb2-id--artraz-page-title-settings").show();
                if( $artraz_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--artraz-custom-page-title").hide();
                } else {
                    $(".cmb2-id--artraz-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--artraz-page-title-settings").hide();
                $(".cmb2-id--artraz-custom-page-title").hide();
    
            }
        }
    } else {
        $artraz_page_breadcrumb_area.parents('.cmb2-id--artraz-page-breadcrumb-area').siblings().hide();
    }


    // breadcrumb area
    $artraz_page_breadcrumb_area.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--artraz-page-breadcrumb-settings").show();
            if( $artraz_page_settings.val() == 'global' ) {
                $(".cmb2-id--artraz-breadcumb-image").hide();
                $(".cmb2-id--artraz-page-title").hide();
                $(".cmb2-id--artraz-page-title-settings").hide();
                $(".cmb2-id--artraz-custom-page-title").hide();
                $(".cmb2-id--artraz-page-breadcrumb-trigger").hide();
            } else {
                $(".cmb2-id--artraz-breadcumb-image").show();
                $(".cmb2-id--artraz-page-title").show();
                $(".cmb2-id--artraz-page-breadcrumb-trigger").show();
        
                if( $artraz_page_title.val() == '1' ) {
                    $(".cmb2-id--artraz-page-title-settings").show();
                    if( $artraz_page_title_settings.val() == 'default' ) {
                        $(".cmb2-id--artraz-custom-page-title").hide();
                    } else {
                        $(".cmb2-id--artraz-custom-page-title").show();
                    }
                } else {
                    $(".cmb2-id--artraz-page-title-settings").hide();
                    $(".cmb2-id--artraz-custom-page-title").hide();
        
                }
            }
        } else {
            $(this).parents('.cmb2-id--artraz-page-breadcrumb-area').siblings().hide();
        }
    });

    // page title
    $artraz_page_title.on("change",function(){
        if( $(this).val() == '1' ) {
            $(".cmb2-id--artraz-page-title-settings").show();
            if( $artraz_page_title_settings.val() == 'default' ) {
                $(".cmb2-id--artraz-custom-page-title").hide();
            } else {
                $(".cmb2-id--artraz-custom-page-title").show();
            }
        } else {
            $(".cmb2-id--artraz-page-title-settings").hide();
            $(".cmb2-id--artraz-custom-page-title").hide();

        }
    });

    //page settings
    $artraz_page_settings.on("change",function(){
        if( $(this).val() == 'global' ) {
            $(".cmb2-id--artraz-breadcumb-image").hide();
            $(".cmb2-id--artraz-page-title").hide();
            $(".cmb2-id--artraz-page-title-settings").hide();
            $(".cmb2-id--artraz-custom-page-title").hide();
            $(".cmb2-id--artraz-page-breadcrumb-trigger").hide();
        } else {
            $(".cmb2-id--artraz-breadcumb-image").show();
            $(".cmb2-id--artraz-page-title").show();
            $(".cmb2-id--artraz-page-breadcrumb-trigger").show();
    
            if( $artraz_page_title.val() == '1' ) {
                $(".cmb2-id--artraz-page-title-settings").show();
                if( $artraz_page_title_settings.val() == 'default' ) {
                    $(".cmb2-id--artraz-custom-page-title").hide();
                } else {
                    $(".cmb2-id--artraz-custom-page-title").show();
                }
            } else {
                $(".cmb2-id--artraz-page-title-settings").hide();
                $(".cmb2-id--artraz-custom-page-title").hide();
    
            }
        }
    });

    // page title settings
    $artraz_page_title_settings.on("change",function(){
        if( $(this).val() == 'default' ) {
            $(".cmb2-id--artraz-custom-page-title").hide();
        } else {
            $(".cmb2-id--artraz-custom-page-title").show();
        }
    });
    
})(jQuery);