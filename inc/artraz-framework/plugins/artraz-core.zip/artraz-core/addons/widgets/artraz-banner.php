<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Banner Widget.
 *
 */
class Artraz_Banner extends Widget_Base {

	public function get_name() {
		return 'artrazbanner';
	}

	public function get_title() {
		return __( 'Banner', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz_header_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'Banner_section',
			[
				'label' 	=> __( 'Banner', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Layout Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
					'5' 		=> __( 'Style Five', 'artraz' ),
					'6' 		=> __( 'Style Six', 'artraz' ),
					'7' 		=> __( 'Style Seven', 'artraz' ),
				],
			]
		);

  		$repeater = new Repeater();

        $repeater->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

        $repeater->add_control(
			'banner_subtitle', [
				'label' 		=> __( 'Sub Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Subtitle here' , 'artraz' ),
				'label_block' 	=> true,
				'separator' => 'before',
			]
        );

        $repeater->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater->add_control(
			'banner_title2', [
				'label' 		=> __( 'Title 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 2 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater->add_control(
			'banner_title3', [
				'label' 		=> __( 'Title 3', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 3 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );
        
        $repeater->add_control(
			'button_text',
			[
				'label' 	=> esc_html__( 'Button Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> esc_html__( 'Discover More', 'artraz' ),
				'separator' => 'before'
			]
        );

        $repeater->add_control(
			'button_link',
			[
				'label' 		=> esc_html__( 'Button Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'banner_slides',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'banner_subtitle' 	=> __( 'DESIGN IS MAKING SENSE OF THINGS.', 'artraz' ),
						'banner_title' 		=> __( 'Architecture', 'artraz' ),
						'banner_title2' 	=> __( 'With Different', 'artraz' ),
						'banner_title3' 	=> __( 'Approach', 'artraz' ),
					],
				],		
				'condition'	=> [
					'layout_style' => ['1']
				]			
			]
		);

		$repeater2 = new Repeater();

        $repeater2->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

        $repeater2->add_control(
			'banner_subtitle', [
				'label' 		=> __( 'Sub Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Subtitle here' , 'artraz' ),
				'label_block' 	=> true,
				'separator' => 'before',
			]
        );

        $repeater2->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater2->add_control(
			'banner_title2', [
				'label' 		=> __( 'Title 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 2 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater2->add_control(
			'banner_title3', [
				'label' 		=> __( 'Title 3', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 3 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater2->add_control(
			'banner_desc', [
				'label' 		=> __( 'Description', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Description here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$this->add_control(
			'banner_slides_2',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater2->get_controls(),
				'default' 		=> [
					[
						'banner_subtitle' 	=> __( 'DESIGN IS MAKING SENSE OF THINGS.', 'artraz' ),
						'banner_title' 		=> __( 'Architecture', 'artraz' ),
						'banner_title2' 	=> __( 'With Different', 'artraz' ),
						'banner_title3' 	=> __( 'Approach', 'artraz' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['2']
				]		
			]
		);

		$repeater3 = new Repeater();

        $repeater3->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

		$repeater3->add_control(
            'logo_big',
            [
                'label'     => __( 'Logo Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

		$repeater3->add_control(
			'banner_desc', [
				'label' 		=> __( 'Description', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Description here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater3->add_control(
			'banner_desc2', [
				'label' 		=> __( 'Description 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Description here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$this->add_control(
			'banner_slides_3',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater3->get_controls(),
				'default' 		=> [
					[
						'banner_desc' 	=> __( 'Sports Faciites Building, University of Cyprus', 'artraz' ),
						'banner_desc2' 		=> __( '/ 2015', 'artraz' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['3']
				]		
			]
		);

		$repeater4 = new Repeater();

        $repeater4->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

        $repeater4->add_control(
			'banner_subtitle', [
				'label' 		=> __( 'Sub Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Subtitle here' , 'artraz' ),
				'label_block' 	=> true,
				'separator' => 'before',
			]
        );

        $repeater4->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater4->add_control(
			'banner_title2', [
				'label' 		=> __( 'Title 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 2 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater4->add_control(
			'banner_meta', [
				'label' 		=> __( 'Meta Info', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Meta info here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater4->add_control(
			'banner_meta2', [
				'label' 		=> __( 'Meta Info 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Meta info here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$this->add_control(
			'banner_slides_4',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater4->get_controls(),
				'default' 		=> [
					[
						'banner_subtitle' 	=> __( 'DESIGN IS MAKING SENSE OF THINGS.', 'artraz' ),
						'banner_title' 		=> __( 'Architecture', 'artraz' ),
						'banner_title2' 	=> __( 'With Different', 'artraz' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['4']
				]		
			]
		);

		//---------------------------style 5---------------------------//

		$repeater4 = new Repeater();

        $repeater4->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );
        $repeater4->add_control(
            'banner_img2',
            [
                'label'     => __( 'Banner Image 2', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );
        $repeater4->add_control(
            'banner_img3',
            [
                'label'     => __( 'Title Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );

        $repeater4->add_control(
			'banner_subtitle', [
				'label' 		=> __( 'Sub Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Subtitle here' , 'artraz' ),
				'label_block' 	=> true,
				'separator' => 'before',
			]
        );

        $repeater4->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater4->add_control(
			'banner_title2', [
				'label' 		=> __( 'Title 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 2 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );
        $repeater4->add_control(
			'banner_title3', [
				'label' 		=> __( 'Title 3', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 3 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );
        $repeater4->add_control(
			'button_text',
			[
				'label' 	=> esc_html__( 'Button Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> esc_html__( 'Discover More', 'artraz' ),
				'separator' => 'before'
			]
        );

        $repeater4->add_control(
			'button_link',
			[
				'label' 		=> esc_html__( 'Button Link', 'artraz' ),
				'type' 		=> Controls_Manager::TEXT,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
			]
		);
		$repeater4->add_control(
			'video_link',
			[
				'label' 		=> esc_html__( 'Video Link', 'artraz' ),
				'type' 			=> Controls_Manager::TEXT,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
			]
		);

		

		$this->add_control(
			'banner_slides_5',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater4->get_controls(),
				'default' 		=> [
					[
						'banner_subtitle' 	=> __( 'DESIGN IS MAKING SENSE OF THINGS.', 'artraz' ),
						'banner_title' 		=> __( 'Architecture', 'artraz' ),
						'banner_title2' 	=> __( 'With Different', 'artraz' ),
					],
				],
				'condition'	=> [
					'layout_style' => ['5']
				]		
			]
		);

		$this->add_control(
			'scroll_bottom', [
				'label' 		=> __( 'Scroll Section Id', 'artraz' ),
				'description' 		=> __( 'Set Section Id for click and go', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'about-sec' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['2', '3']
				]
			]
        );

        $this->add_control(
            'banner_img',
            [
                'label'     => __( 'Banner Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition'	=> [
					'layout_style' => ['6','7']
				]
            ]
        );
        $this->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['6','7']
				]
			]
        );
        $this->add_control(
			'banner_title2', [
				'label' 		=> __( 'Title 2', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['7']
				]
			]
        );
        $this->add_control(
            'avatar',
            [
                'label'     => __( 'Avatar Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition'	=> [
					'layout_style' => ['6','7']
				]
            ]
        );
        $this->add_control(
			'avatar_text', [
				'label' 		=> __( 'Avatar Text', 'artraz' ),
				'type' 			=> Controls_Manager::WYSIWYG,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['7']
				]
			]
        );
        $this->add_control(
			'banner_subtitle', [
				'label' 		=> __( 'Subtitle', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['6','7']
				]
			]
        );
        $this->add_control(
			'banner_desc', [
				'label' 		=> __( 'Description', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 4,
				'default' 		=> __( 'Description here' , 'artraz' ),
				'label_block' 	=> true,
				'condition'	=> [
					'layout_style' => ['7']
				]
			]
        );
        $this->add_control(
			'button_text',
			[
				'label' 	=> esc_html__( 'Button Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> esc_html__( 'Discover More', 'artraz' ),
				'separator' => 'before',
				'condition'	=> [
					'layout_style' => ['6','7']
				]
			]
        );

        $this->add_control(
			'button_link',
			[
				'label' 		=> esc_html__( 'Button Link', 'artraz' ),
				'type' 		=> Controls_Manager::TEXT,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'condition'	=> [
					'layout_style' => ['6','7']
				]
			]
		);
		$this->add_control(
            'hero_img',
            [
                'label'     => __( 'Her Image 1', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition'	=> [
					'layout_style' => ['6','7']
				]
            ]
        );
        $this->add_control(
            'hero_img2',
            [
                'label'     => __( 'Her Image 2', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition'	=> [
					'layout_style' => ['6','7']
				]
            ]
        );
        $this->add_control(
            'hero_img3',
            [
                'label'     => __( 'Her Image 3', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
				'condition'	=> [
					'layout_style' => ['7']
				]
            ]
        );

        //---------------------------style 6---------------------------//

		$repeater6 = new Repeater();

        $repeater6->add_control(
            'img',
            [
                'label'     => __( 'Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 		=> Utils::get_placeholder_image_src(),
				],
            ]
        );
       
        $repeater6->add_control(
			'banner_title', [
				'label' 		=> __( 'Title 1', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$this->add_control(
			'banner_slides_6',
			[
				'label' 		=> __( 'Banners', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater6->get_controls(),
				
				'condition'	=> [
					'layout_style' => ['6']
				]		
			]
		);


		$this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

        //---------------------------------------Subtitle Style---------------------------------------//
		$this->start_controls_section(
			'subtitle_style',
			[
				'label' 	=> __( 'Subtitle Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['1', '2', '4']
				]
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .hero-subtitle' => 'color: {{VALUE}}',
                ],
			]
        );	

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'subtitle_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .hero-subtitle',
			]
        );

        $this->add_responsive_control(
			'subtitle_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'subtitle_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-subtitle' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();

		//---------------------------------------Title Style---------------------------------------//
		$this->start_controls_section(
			'title_all_styling',
			[
				'label' 	=> __( 'Title Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs2'
		);

			$this->start_controls_tab(
				'style_normal_tab2',
				[
					'label' => esc_html__( 'Title', 'artraz' ),
				]
			);

			$this->add_control(
				'overview_title_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .e-title'	=> 'color: {{VALUE}}!important;',
					],
				]
			);

			$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name' 			=> 'overview_title_typography',
					'label' 		=> __( 'Typography', 'artraz' ),
					'selector' 	=> '{{WRAPPER}} .e-title',
				]
			);

			$this->add_responsive_control(
				'overview_title_margin',
				[
					'label' 		=> __( 'Margin', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'overview_title_padding',
				[
					'label' 		=> __( 'Padding', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->end_controls_tab();

			//--------------------secound--------------------//
			$this->start_controls_tab(
				'style_hover_tab2',
				[
					'label' => esc_html__( 'Title 2', 'artraz' ),
				]
			);

			$this->add_control(
				'overview_title2_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-2'	=> 'color: {{VALUE}}!important;',
					],
				]
			);

			$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name' 			=> 'overview_title2_typography',
					'label' 		=> __( 'Typography', 'artraz' ),
					'selector' 	=> '{{WRAPPER}} .e-title-2',
				]
			);

			$this->add_responsive_control(
				'overview_title2_margin',
				[
					'label' 		=> __( 'Margin', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'overview_title2_padding',
				[
					'label' 		=> __( 'Padding', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->end_controls_tab();

			//--------------------three--------------------//
			$this->start_controls_tab(
				'style_hover_tab3',
				[
					'label' => esc_html__( 'Title 3', 'artraz' ),
					'condition'	=> [
						'layout_style' => ['1', '2']
					]
				]
			);

			$this->add_control(
				'overview_title3_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-3'	=> 'color: {{VALUE}}!important;',
					],
				]
			);

			$this->add_group_control(
			Group_Control_Typography::get_type(),
				[
					'name' 			=> 'overview_title3_typography',
					'label' 		=> __( 'Typography', 'artraz' ),
					'selector' 	=> '{{WRAPPER}} .e-title-3',
				]
			);

			$this->add_responsive_control(
				'overview_title3_margin',
				[
					'label' 		=> __( 'Margin', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
				'overview_title3_padding',
				[
					'label' 		=> __( 'Padding', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .e-title-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

			$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();


		//---------------------------------------Description Style---------------------------------------//
		$this->start_controls_section(
			'desc_style',
			[
				'label' 	=> __( 'Description Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['2']
				]
			]
		);
		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .hero-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'desc_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
				'selector' 	=> '{{WRAPPER}} .hero-text',
			]
		);
		$this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);

		$this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .hero-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
		$this->end_controls_section();


		//---------------------------------------Button Style---------------------------------------//
		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['1']
				]
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1' => '--title-black: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Hover Color ', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1:hover' => '--title-black: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( ' Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1' => 'background-color:{{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( ' Background Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1::before, {{WRAPPER}} .th-btn.btn1:hover' => 'background-color:{{VALUE}}',
                ],
			]
        );        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( ' Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn1',
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn1',
			]
		);

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Hover Border ', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn1:hover',
			]
		);

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( ' Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( ' Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( ' Border Radius', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn1' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

?>
	<?php if( $settings['layout_style'] == '2' ): ?>
	<div class="th-hero-wrapper hero-1">
        <div class="hero-slider-1 th-carousel" id="heroSlide1" data-fade="true" data-slide-show="1">
			<?php foreach( $settings['banner_slides_2'] as $data ): ?>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-bg-src="<?php echo esc_url($data['banner_img']['url']); ?>" data-overlay="black" data-opacity="6"></div>
                <div class="container">
                    <div class="hero-style1">
						<?php if(!empty($data['banner_subtitle'])): ?>
							<span class="h4 hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><?php echo wp_kses_post($data['banner_subtitle']) ?></span>
						<?php endif; ?>
						<?php if(!empty($data['banner_title'])): ?>
                        	<h1 class="hero-title e-title" data-ani="slideinleft" data-ani-delay="0.3s"><?php echo wp_kses_post($data['banner_title']) ?></h1>
						<?php endif; ?>
						<?php if(!empty($data['banner_title2'])): ?>
                        	<h1 class="hero-title e-title-2" data-ani="slideinleft" data-ani-delay="0.5s"><?php echo wp_kses_post($data['banner_title2']) ?></h1>
						<?php endif; ?>
						<?php if(!empty($data['banner_title3'])): ?>
                        	<h1 class="hero-title e-title-3 text-transparent" data-ani="slideinleft" data-ani-delay="0.7s"><?php echo wp_kses_post($data['banner_title3']) ?></h1>
						<?php endif; ?>
						<?php if(!empty($data['banner_desc'])): ?>
                        	<p class="hero-text" data-ani="slideinup" data-ani-delay="0.7s"><?php echo wp_kses_post($data['banner_desc']) ?></p>
						<?php endif; ?>
						
                        <?php if(!empty($settings['scroll_bottom'])): ?>
							<a href="#<?php echo esc_attr($settings['scroll_bottom']) ?>" class="scroll-bottom"></a>
						<?php endif; ?>
                    </div>
                </div>
                <div class="hero-shape"></div>
            </div>
			<?php endforeach; ?>
        </div>
        <div class="icon-box">
            <button data-slick-prev="#heroSlide1" class="slick-arrow default cursor-btn"><i class="fal fa-long-arrow-left"></i></button>
            <button data-slick-next="#heroSlide1" class="slick-arrow default cursor-btn"><i class="fal fa-long-arrow-right"></i></button>
        </div>
    </div>

	<?php elseif($settings['layout_style'] == '3' ): ?>
	<div class="th-hero-wrapper hero-2">
        <div class="hero-slider-2" id="heroSlide2">
			<?php foreach( $settings['banner_slides_3'] as $data ): ?>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-bg-src="<?php echo esc_url($data['banner_img']['url']); ?>" data-overlay="black" data-opacity="6"></div>
                <div class="container">
                    <div class="hero-style2">
                        <div class="hero-logo">
								<?php echo artraz_img_tag( array(
									'url'   => esc_url( $data['logo_big']['url']  ),
								)); ?>
                        </div>
						<?php if(!empty($data['banner_desc'])): ?>
                        	<p class="hero-text e-title"><?php echo wp_kses_post($data['banner_desc']); ?></p>
						<?php endif; ?>
						<?php if(!empty($data['banner_desc2'])): ?>
                        	<p class="hero-year e-title-2"><?php echo wp_kses_post($data['banner_desc2']); ?></p>
						<?php endif; ?>
                    </div>
                </div>
            </div>
			<?php endforeach; ?>
        </div>
        <div class="slider-nav-wrap">
            <div class="slider-nav">
                <button data-slick-prev="#heroSlide2" class="nav-btn"><i class="fal fa-long-arrow-left"></i></button>
                <div class="custom-dots"></div>
                <button data-slick-next="#heroSlide2" class="nav-btn"><i class="fal fa-long-arrow-right"></i></button>
            </div>
        </div>
		<?php if(!empty($settings['scroll_bottom'])): ?>
        	<a href="#<?php echo esc_attr($settings['scroll_bottom']) ?>" class="scroll-bottom"></a>
		<?php endif; ?>
        <div class="curve-shape"></div>
    </div>

	<?php elseif($settings['layout_style'] == '4' ): ?>
    <div class="th-hero-wrapper container th-container2">
        <div class="hero-slider-3 th-carousel" data-fade="true" data-slide-show="1">
			<?php foreach( $settings['banner_slides_4'] as $data ): ?>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-bg-src="<?php echo esc_url($data['banner_img']['url']); ?>" data-overlay="black" data-opacity="6"></div>
                <div class="container">
                    <div class="hero-style3">
						<?php if(!empty($data['banner_subtitle'])): ?>
							<span class="h5 hero-subtitle" data-ani="slideinup" data-ani-delay="0.1s"><?php echo wp_kses_post($data['banner_subtitle']) ?></span>
						<?php endif; ?>
						<?php if(!empty($data['banner_title'])): ?>
                        	<h1 class="hero-title e-title" data-ani="slideinup" data-ani-delay="0.3s"><?php echo wp_kses_post($data['banner_title']) ?></h1>
						<?php endif; ?>
						<?php if(!empty($data['banner_title2'])): ?>
                        	<h1 class="hero-title e-title-2" data-ani="slideinup" data-ani-delay="0.5s"><?php echo wp_kses_post($data['banner_title2']) ?></h1>
						<?php endif; ?>

                        <div class="hero-meta" data-ani="slideinup" data-ani-delay="0.7s">
							<?php if(!empty($data['banner_meta'])): ?>
                            	<span class="meta-info"><?php echo wp_kses_post($data['banner_meta']) ?></span>
							<?php endif; ?>
							<?php if(!empty($data['banner_meta2'])): ?>
                            	<span class="meta-info"><?php echo wp_kses_post($data['banner_meta2']) ?></span>
							<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
			<?php endforeach; ?>
        </div>
    </div>
    <?php elseif($settings['layout_style'] == '5' ): 

    	echo '<div class="th-hero-wrapper hero-1 hero-5">';
	        echo '<div class="hero-slider-1 th-carousel" id="heroSlide1" data-fade="true" data-slide-show="1">';
	        	foreach( $settings['banner_slides_5'] as $data ):
		            echo '<div class="th-hero-slide">';
		                echo '<div class="th-hero-bg" data-bg-src="'.esc_url($data['banner_img']['url']).'" data-overlay="black" data-opacity="8"></div>';
		                echo '<div class="container">';
		                    echo '<div class="hero-style1">';
		                    	if(!empty($data['banner_subtitle'])) {
			                        echo '<span class="h4 hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s">'.esc_html($data['banner_subtitle']).'</span>';
			                    }
			                    if(!empty($data['banner_title'])) {
			                        echo '<h1 class="hero-title" data-ani="slideinleft" data-ani-delay="0.3s">'.esc_html($data['banner_title']).' <img src="'.esc_url($data['banner_img3']['url']).'" alt="Image" class="title-img"></h1>';
			                    }
			                    if(!empty($data['banner_title2'])) {
			                        echo '<h1 class="hero-title" data-ani="slideinleft" data-ani-delay="0.5s">'.esc_html($data['banner_title2']).'</h1>';
			                    }
			                    if(!empty($data['banner_title3'])) {
			                        echo '<h1 class="hero-title text-transparent" data-ani="slideinleft" data-ani-delay="0.7s">'.esc_html($data['banner_title3']).'</h1>';
			                    }
		                        echo '<div class="btn-group" data-ani="slideinup" data-ani-delay="0.7s">';
		                        	if(!empty($data['button_text'])) {
			                            echo '<a href="'.esc_url( $data['button_link'] ).'" class="th-btn"><span class="line left"></span>'.esc_html($data['button_text']).'<span class="line"></span></a>';
			                        }
		                            echo '<a href="'.esc_url( $data['video_link'] ).'" class="play-btn popup-video style2"><i class="fas fa-play"></i></a>';
		                        echo '</div>';
		                    echo '</div>';
		                echo '</div>';
		                echo '<div class="hero-img" data-ani="slideinup" data-ani-delay="0.4s">';
		                    echo '<img src="'.esc_url($data['banner_img2']['url']).'" alt="Image">';
		                echo '</div>';
		            echo '</div>';
	            endforeach;
	        echo '</div>';
	    echo '</div>';
	elseif($settings['layout_style'] == '6' ): 

		echo '<div class="th-hero-wrapper hero-6" data-bg-src="'.esc_url($settings['banner_img']['url']).'">';
		    echo '<div class="container">';
		        echo '<div class="hero-style6">';
		            echo '<h1 class="hero-title wow fadeInUp" data-wow-delay="0.1s">'.esc_html( $settings['banner_title'] ).' <img src="'.esc_url($settings['avatar']['url']).'" alt="Image" class="title-img"></h1>';
		            echo '<h1 class="hero-title wow fadeInUp" data-wow-delay="0.3s"><a href="'.esc_url( $settings['button_link'] ).'" class="th-btn"><span class="line left"></span> '.esc_html($settings['button_text']).' <span class="line"></span></a> '.esc_html( $settings['banner_subtitle'] ).'</h1>';
		        echo '</div>';
		        echo '<div class="hero-img wow fadeInUp" data-wow-delay="0.4s" data-bg-src="'.esc_url($settings['hero_img']['url']).'">';
		            echo '<img class="wow fadeInLeft" data-wow-delay="0.5s" src="'.esc_url($settings['hero_img2']['url']).'" alt="Image">';
		        echo '</div>';
		    echo '</div>';
		    echo '<div class="brand-slider-area">';
		        echo '<div class="slick-marquee">';
		            foreach( $settings['banner_slides_6'] as $data ) {
			            echo '<div class="">';
			               echo ' <div class="marque-text">';
			                    echo '<img src="'.esc_url($data['img']['url']).'" alt="Logo">';
			                    echo esc_html( $data['banner_title'] );
			                echo '</div>';
			            echo '</div>';
			        }
		        echo '</div>';
		    echo '</div>';
		echo '</div>';
	elseif($settings['layout_style'] == '7' ): 

		echo '<div class="th-hero-wrapper hero-1 hero-5 hero-7">';
	        echo '<div class="hero-slider-1 th-carousel" id="heroSlide1" data-fade="true" data-slide-show="1">';

	            echo '<div class="th-hero-slide">';
	                echo '<div class="th-hero-bg" data-bg-src="'.esc_url($settings['banner_img']['url']).'" data-overlay="black2" data-opacity="8"></div>';
	                echo '<div class="container">';
	                    echo '<div class="hero-style1">';
	                        echo '<span class="h4 hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s">'.esc_html( $settings['banner_title'] ).'</span>';
	                        echo '<h1 class="hero-title2" data-ani="slideinleft" data-ani-delay="0.3s">'.esc_html( $settings['banner_title2'] ).'';
	                            echo '<img src="'.esc_url($settings['avatar']['url']).'" alt="Image" class="title-img">';
	                            if(!empty($settings['avatar_text'])) {
	                            	echo wp_kses_post( $settings['avatar_text'] );
	                            }

	                        echo '</h1>';
	                        echo '<h1 class="hero-title2" data-ani="slideinleft" data-ani-delay="0.5s">'.esc_html( $settings['banner_subtitle'] ).'</h1>';
	                        echo '<p class="hero-text2" data-ani="slideinleft" data-ani-delay="0.6s">'.esc_html( $settings['banner_desc'] ).'</p>';
	                        echo '<div class="btn-group" data-ani="slideinup" data-ani-delay="0.7s">';
	                            echo '<a href="'.esc_url( $settings['button_link'] ).'" class="th-btn"><span class="line left"></span>'.esc_html($settings['button_text']).'<span class="line"></span></a>';
	                        echo '</div>';
	                    echo '</div>';
	                echo '</div>';
	                echo '<div class="hero-img">';
	                    echo '<div class="img1" data-ani="slideinleft" data-ani-delay="0.5s">';
	                        echo '<img class="tilt-active" src="'.esc_url($settings['hero_img']['url']).'" alt="Image">';
	                    echo '</div>';
	                    echo '<div class="img2" data-ani="slideinup" data-ani-delay="0.3s">';
	                        echo '<img class="tilt-active" src="'.esc_url($settings['hero_img2']['url']).'" alt="Image">';
	                    echo '</div>';
	                    echo '<div class="img3" data-ani="slideinright" data-ani-delay="0.5s">';
	                        echo '<img class="tilt-active" src="'.esc_url($settings['hero_img3']['url']).'" alt="Image">';
	                    echo '</div>';
	                echo '</div>';
	            echo '</div>';

	            
	        echo '</div>';
	    echo '</div>';
	else: ?>
	<div class="th-hero-wrapper hero-4">
        <div class="hero-slider-4 th-carousel" id="heroSlide4" data-fade="false" data-slide-show="1">
			<?php foreach( $settings['banner_slides'] as $data ): ?>
            <div>
                <div class="th-hero-slide">
                    <div class="th-hero-bg" data-bg-src="<?php echo esc_url($data['banner_img']['url']); ?>" data-overlay="black" data-opacity="6"></div>
                    <div class="container">
                        <div class="hero-style4">
							<?php if(!empty($data['banner_subtitle'])): ?>
								<span class="h4 hero-subtitle" data-ani="slideinup" data-ani-delay="0.1s"><?php echo wp_kses_post($data['banner_subtitle']) ?></span>
                            <?php endif; ?>
							<?php if(!empty($data['banner_title'])): ?>
                            	<h1 class="hero-title e-title" data-ani="slideinup" data-ani-delay="0.3s"><?php echo wp_kses_post($data['banner_title']) ?></h1>
							<?php endif; ?>
							<?php if(!empty($data['banner_title2'])): ?>
                            	<h1 class="hero-title e-title-2" data-ani="slideinup" data-ani-delay="0.5s"><?php echo wp_kses_post($data['banner_title2']) ?></h1>
							<?php endif; ?>
							<?php if(!empty($data['banner_title3'])): ?>
                            	<h1 class="hero-title e-title-3 text-transparent" data-ani="slideinup" data-ani-delay="0.5s"><?php echo wp_kses_post($data['banner_title3']) ?></h1>
							<?php endif; ?>
							<?php if(!empty($data['button_text'])): ?>
                                <a href="<?php echo esc_url( $data['button_link']['url'] ); ?>" class="th-btn btn1" data-ani="slideinup" data-ani-delay="0.7s"><span class="line left"></span><?php echo esc_html($data['button_text']); ?><span class="line"></span></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
			<?php endforeach; ?>
        </div>
        <div class="icon-box">
            <button data-slick-prev="#heroSlide4" class="slick-arrow default cursor-btn"><i class="fal fa-long-arrow-left"></i></button>
            <button data-slick-next="#heroSlide4" class="slick-arrow default cursor-btn"><i class="fal fa-long-arrow-right"></i></button>
        </div>
    </div>

	<?php 
	endif; 
		
	}

}