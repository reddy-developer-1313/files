<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Footer Subscribed Widget .
 *
 */
class Artraz_Footer_Subscribe extends Widget_Base {

	public function get_name() {
		return 'artrazfootersubscribe';
	}

	public function get_title() {
		return __( 'Artraz Footer Subscribe', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz_footer_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'footer_subscribe_section',
			[
				'label' 	=> __( 'Footer Subscribe', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Subscribe Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
				],
			]
		);
       
		$this->add_control(
			'title',
			[
				'label'     => __( 'Title', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );
        $this->add_control(
			'sub_desc',
			[
				'label'     => __( 'Subtitle', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 3,
				'default'   => __( 'Subsrcibe to our upcoming latest article and news resources. Sign up today for hints. tips and the latest product news.', 'artraz' ),
			]
        );
        
        $this->end_controls_section();

		//--------------------------------------- Title Style---------------------------------------//

		$this->start_controls_section(
			'title_style',
			[
				'label' 	=> __( 'Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h3' => 'color: {{VALUE}}',
                ],
			]
        );
		$this->add_control(
			'title_border_color',
			[
				'label' 		=> __( 'Title Border Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} h3' => '--theme-color: {{VALUE}}',
                ],
			]
        );
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'title_typography',
				'label' 	=> __( 'Title Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} h3',
			]
        );
        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Title Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'desc_styling',
			[
				'label'     => __( 'Description Styling', 'artraz' ),
				'tab'       => Controls_Manager::TAB_STYLE,
			]
        );
        $this->add_control(
			'desc_txt_color',
			[
				'label' 			=> __( 'Description Color', 'artraz' ),
				'type' 				=> Controls_Manager::COLOR,
				'selectors' 		=> [
					'{{WRAPPER}} p' => '--body-color: {{VALUE}};',
                ]
			]
        );
        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Title Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Title Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		if ( $settings['layout_style'] == '1' ) {
			echo '<div class="footer-widget style2">';
				if(!empty($settings['title'])){
					echo '<h4 class="widget_title">'.esc_html($settings['title']).'</h4>';
				}
				echo '<div class="newsletter-widget">';
					if(!empty($settings['sub_desc'])){
						echo '<p class="md-24 mt-n2">'.esc_html($settings['sub_desc']).'</p>';
					}
					echo '<form class="newsletter-form">';
						echo '<input class="form-control" type="email" placeholder="'.esc_attr('Enter Email Address', 'artraz').'" required="">';
						echo '<button type="submit" class="th-btn w-100">'.esc_html('Subscribe now', 'artraz').'</button>';
					echo '</form>';
				echo '</div>';
			echo '</div>';
		} else {
			echo '<div class="newsletter-wrap">';
				echo '<div class="newsletter-content">';
					if(!empty($settings['title'])){
						echo '<h3 class="newsletter-title">'.esc_html($settings['title']).'</h3>';
					}
					if(!empty($settings['sub_desc'])){
						echo '<p class="newsletter-text">'.esc_html($settings['sub_desc']).'</p>';
					}
				echo '</div>';
				echo '<form class="newsletter-form">';
					echo '<div class="form-group">';
						echo '<input class="form-control" type="email" placeholder="'.esc_attr('Email Address', 'artraz').'" required="">';
						echo '<i class="fal fa-envelope"></i>';
					echo '</div>';
					echo '<button type="submit" class="th-btn style3">'.esc_html('Subscribe', 'artraz').'</button>';
				echo '</form>';
			echo '</div>';
		}
	}
}