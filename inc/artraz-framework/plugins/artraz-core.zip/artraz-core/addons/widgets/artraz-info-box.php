<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Info Box Widget .
 *
 */
class Artraz_Info_Box extends Widget_Base {

	public function get_name() {
		return 'artrazinfobox';
	}

	public function get_title() {
		return __( 'Info Box', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {


		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Info Box', 'artraz' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
				
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Layout Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2'  		=> __( 'Style Two', 'artraz' ),					
				],
			]
		);

		$this->add_control(
			'image',
			[
				'label'     => __( 'Text Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'layout_style' => ['2']
				]
			]
		);

		$this->add_control(
			'number',
            [
				'label'         => __( 'Number', 'artraz' ),
				'description'   => __( 'Set image for show number', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4',
				'condition' => [
					'layout_style' => ['2']
				]
			]
		);

		$this->add_control(
			'content',
            [
				'label'         => __( 'Content', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content here' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4',
			]
		);
        
		$this->add_control(
			'content2',
            [
				'label'         => __( 'Content 2', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content here' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4',
			]
		);
    
		 $this->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'tayde' ),
                'type' 		=> Controls_Manager::TEXT,
                'label_block' => true,
                'default'  	=> __( 'Button Text', 'tayde' ),
				'condition' => [
					'layout_style' => ['1']
				]
			]
        );

        $this->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'tayde' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'tayde' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				'condition' => [
					'layout_style' => ['1']
				]
			]
		); 

        $this->add_control(
			'button_text2',
			[
				'label' 	=> __( 'Button Text 2', 'tayde' ),
                'type' 		=> Controls_Manager::TEXT,
                'label_block' => true,
                'default'  	=> __( 'Button Text', 'tayde' ),
				'condition' => [
					'layout_style' => ['1']
				]
			]
        );

        $this->add_control(
			'button_link2',
			[
				'label' 		=> __( 'Link 2', 'tayde' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'tayde' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				'condition' => [
					'layout_style' => ['1']
				]
			]
		); 

        $this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------Content styling-------------------------------------//

        $this->start_controls_section(
			'section_title_style_section',
			[
				'label' => __( 'Content 1 Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'section_title_color',
			[
				'label' 	=> __( 'Color', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .e-text' => 'color: {{VALUE}}!important;',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_title_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}}  .e-text',
			]
		);

        $this->add_responsive_control(
			'section_title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}}  .e-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'section_title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}}  .e-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

        $this->end_controls_section();


        //-------------------------------------Content 2 styling-------------------------------------//

        $this->start_controls_section(
			'section_desc_style_section',
			[
				'label' => __( 'Content 2 Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'section_desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-text-2' => 'color: {{VALUE}}!important',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_desc_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-text-2',
			]
        );

        $this->add_responsive_control(
			'section_desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-text-2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'section_desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-text-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();

         //-------------------------------------Button styling-------------------------------------//

         $this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1']
				]
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-btn',
			]
        );


		$this->start_controls_tabs(
			'button_tabs'
		);


		$this->start_controls_tab(
			'normal_tab_label',
			[
				'label' => esc_html__( 'Normal', 'artraz' ),
			]
		);
		$this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Button Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn' => '--title-black: {{VALUE}}',
                ],
			]
        );
		$this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Button Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn' => 'background-color:{{VALUE}} !important',
                ],
			]
        );
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-btn',
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'hover_tab_label',
			[
				'label' => esc_html__( 'Hover', 'artraz' ),
			]
		);
		$this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Button Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn:hover' => '--title-black: {{VALUE}}',
                ],
			]
        );
		$this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Button Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn:hover:before, {{WRAPPER}} .e-btn:hover' => 'background-color:{{VALUE}} !Important',
                ],
			]
        );
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-btn:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Button Shadow', 'artraz' ),
				'selector' => '{{WRAPPER}} .e-btn',
			]
		);

        $this->end_controls_section();

		//-------------------------------------Button 2 styling-------------------------------------//

		$this->start_controls_section(
			'button_style_section2',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1']
				]
			]
        );

		$this->add_control(
			'button_color2',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn-2' => '--theme-color: {{VALUE}}',
                ],
			]
        );

		$this->add_control(
			'button_h_color2',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-btn-2:hover' => '--title-color: {{VALUE}} ',
                ],
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography2',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-btn-2',
			]
        );

        $this->end_controls_section();

	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <?php if( $settings['layout_style'] == '2' ): ?>
			<div class="experience-card">
				<span class="year" data-bg-src="<?php echo esc_url( $settings['image']['url']); ?>"><?php echo esc_html( $settings['number'] ); ?></span>
				<div class="content">
					<h3 class="title"><?php echo esc_html( $settings['content'] ); ?></h3>
					<h4 class="title2"><?php echo esc_html( $settings['content2'] ); ?></h4>
				</div>
			</div>
			
    	<?php else: ?>
            <div class="about-box">
                <div class="content left-content">
                    <p class="text e-text"><?php echo esc_html( $settings['content'] ); ?></p>
                    <a href="<?php echo esc_url( $settings['button_link']['url'] );?>" class="th-btn e-btn"><span class="line left"></span> <?php echo esc_html( $settings['button_text'] );  ?> <span class="line"></span></a>
                </div>
                <div class="content right-content">
                    <p class="text h6 e-text-2"><?php echo esc_html( $settings['content2'] ); ?></p>
                    <a href="<?php echo esc_url( $settings['button_link2']['url'] );?>" class="link-btn e-btn-2"><?php echo esc_html( $settings['button_text2'] );  ?></a>
                </div>
            </div>

		<?php endif;

	}

}