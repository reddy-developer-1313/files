<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Contact Form Widget .
 *
 */
class Artraz_Contact_Form extends Widget_Base {

	public function get_name() {
		return 'artrazcontactform';
	}

	public function get_title() {
		return __( 'Contact Form', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	public function get_as_contact_form(){
        if ( ! class_exists( 'WPCF7' ) ) {
            return;
        }
        $as_cfa         = array();
        $as_cf_args     = array( 'posts_per_page' => -1, 'post_type'=> 'wpcf7_contact_form' );
        $as_forms       = get_posts( $as_cf_args );
        $as_cfa         = ['0' => esc_html__( 'Select Form', 'artraz' ) ];
        if( $as_forms ){
            foreach ( $as_forms as $as_form ){
                $as_cfa[$as_form->ID] = $as_form->post_title;
            }
        }else{
            $as_cfa[ esc_html__( 'No contact form found', 'artraz' ) ] = 0;
        }
        return $as_cfa;
    }

	protected function register_controls() {

		$this->start_controls_section(
			'contact_form_section',
			[
				'label' 	=> __( 'Contact Form', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					// '3' 		=> __( 'Style Three', 'artraz' ),
					// '4' 		=> __( 'Style Four', 'artraz' ),
				],
			]
		);

        $this->add_control(
			'title',
			[
				'label' 	=> __( 'Title', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'rows' 		=> 2, 
                'default'  	=> __( 'Register For Your Child', 'artraz' ),
                'condition' => [
                	'layout_style' => ['4']
                ]
			]
        );        

         $this->add_control(
            'artraz_select_contact_form',
            [
                'label'   => esc_html__( 'Select Form', 'artraz' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '0',
                'options' => $this->get_as_contact_form(),
            ]
        );

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------General styling-------------------------------------//

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'bg_color',
			[
				'label' 		=> __( 'Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .contact-space' => 'background-color: {{VALUE}}!important',
                ],
			]
        );

       $this->add_responsive_control(
			'contact_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .contact-space' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

       	$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'contact_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'artraz' ),
				'selector' => '{{WRAPPER}} .contact-space',
			]
		);
		
        $this->end_controls_section();

        //----------------------------- Title styling-----------------------------//
        $this->start_controls_section(
			'title_styling',
			[
				'label' 	=> __( 'Title Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
                	'layout_style' => ['3']
                ]
			]
        );

        $this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Title Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .contact-space h2'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'title_typography',
		 		'label' 		=> __( 'Title Typography', 'artraz' ),
		 		'selector' 		=> '{{WRAPPER}} .contact-space h2',
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Title Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .contact-space h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();
        
	}

	protected function render() {

	    $settings = $this->get_settings_for_display();
	    ?>

		<?php if( $settings['layout_style'] == '2' ): ?>
			<div class="ajax-contact form1">
				<?php 
					if( !empty($settings['artraz_select_contact_form']) ){
						echo do_shortcode( '[contact-form-7  id="'.$settings['artraz_select_contact_form'].'"]' ); 
					}else{
						echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'artraz' ). '</p></div>';
					}
				?>
            </div>

    	<?php elseif( $settings['layout_style'] == '3' ): ?>


	    <?php else: ?>
			<div class="contact-form ajax-contact">
				<?php 
					if( !empty($settings['artraz_select_contact_form']) ){
						echo do_shortcode( '[contact-form-7  id="'.$settings['artraz_select_contact_form'].'"]' ); 
					}else{
						echo '<div class="alert alert-warning"><p class="m-0">' . __('Please Select contact form.', 'artraz' ). '</p></div>';
					}
				?>
            </div>
	    	 
	    <?php endif;

	}

}