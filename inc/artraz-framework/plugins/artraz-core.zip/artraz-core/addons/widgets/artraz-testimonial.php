<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
/**
 *
 * Testimonial Slider Widget .
 *
 */
class Artraz_Testimonial extends Widget_Base{

	public function get_name() {
		return 'artraztestimonialslider';
	}

	public function get_title() {
		return __( 'Testimonial Slider', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'testimonial_slider_section',
			[
				'label' 	=> __( 'Testimonial Slider', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
					'5' 		=> __( 'Style Five', 'artraz' ),
					'6' 		=> __( 'Style Six', 'artraz' ),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'client_image',
			[
				'label' 		=> __( 'Client Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'quote_image',
			[
				'label' 		=> __( 'Quote Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'client_name', [
				'label' 		=> __( 'Client Name', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Vlademir Hilto' , 'artraz' ),
				'label_block' 	=> true,
			]
        );
		$repeater->add_control(
			'client_desig', [
				'label' 		=> __( 'Client Designation', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'IT Student' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater->add_control(
			'client_feedback', [
				'label' 		=> __( 'Client Feedback', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '“Quickly maximize visionary solutions after mission critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche markets via growth strategies”' , 'artraz' ),
				'label_block' 	=> true,
			]
		);
		$repeater->add_control(
			'client_rating',
			[
				'label' 	=> __( 'Client Rating', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '5',
				'options' 	=> [
					'one'  		=> __( 'One Star', 'artraz' ),
					'two' 		=> __( 'Two Star', 'artraz' ),
					'three' 	=> __( 'Three Star', 'artraz' ),
					'four' 		=> __( 'Four Star', 'artraz' ),
					'five' 	 	=> __( 'Five Star', 'artraz' ),
				],
			]
		);
		$repeater->add_control(
			'feedback_title', [
				'label' 		=> __( 'Feedback title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Vlademir Hilto' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$this->add_control(
			'slides',
			[
				'label' 		=> __( 'Slides', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'client_image' 		=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{{ client_name }}}',
                'condition' => [
					'layout_style' => ['1', '2','4','5','6'],
				]
			]
		);
		$this->add_control(
			'bg',
			[
				'label' 		=> __( 'BG Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'condition' => [
					'layout_style' => ['4'],
				]
			]
		);
		$this->add_control(
			'quote',
			[
				'label' 		=> __( 'Quote Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'condition' => [
					'layout_style' => ['4'],
				]
			]
		);

        $this->add_control(
			'testi_sec_title', [
				'label' 		=> __( 'Section Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'WHAT CLIENT SAY?' , 'artraz' ),
				'label_block' 	=> true,
                'condition' => [
					'layout_style' => ['3'],
				]
			]
        );

        $repeater2 = new Repeater();

        $repeater2->add_control(
			'video_image',
			[
				'label' 		=> __( 'Video Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater2->add_control(
			'video_url',
			[
				'label' 		=> esc_html__( 'Video URL', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

        $repeater2->add_control(
			'video_overlay_text', [
				'label' 		=> __( 'Video Text', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Video' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

		$repeater2->add_control(
			'client_image',
			[
				'label' 		=> __( 'Client Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'default' 		=> [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater2->add_control(
			'quote_image',
			[
				'label' 		=> __( 'Quote Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
			]
		);
		$repeater2->add_control(
			'client_name', [
				'label' 		=> __( 'Client Name', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Vlademir Hilto' , 'artraz' ),
				'label_block' 	=> true,
			]
        );
		$repeater2->add_control(
			'client_desig', [
				'label' 		=> __( 'Client Designation', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'IT Student' , 'artraz' ),
				'label_block' 	=> true,
			]
        );

        $repeater2->add_control(
			'client_feedback', [
				'label' 		=> __( 'Client Feedback', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( '“Quickly maximize visionary solutions after mission critical action items productivate premium portals for impactful -services stinctively negotiate enabled niche markets via growth strategies”' , 'artraz' ),
				'label_block' 	=> true,
			]
		);

		$this->add_control(
			'slides_2',
			[
				'label' 		=> __( 'Slides', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater2->get_controls(),
				'default' 		=> [
					[
						'client_image' 		=> Utils::get_placeholder_image_src(),
					],
				],
				'title_field' 	=> '{{{ client_name }}}',
                'condition' => [
					'layout_style' => ['3'],
				]
			]
		);

		$this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

         //-------------------------------------title styling-------------------------------------//
         $this->start_controls_section(
			'section_title_style_section',
			[
				'label' => __( 'Title Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' 	=> [
                    'layout_style'    => '3',
                ]
			]
		);

        $this->add_control(
			'section_title_color',
			[
				'label' 	=> __( 'Color', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-sec-title' => 'color: {{VALUE}}!important;',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_title_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .testi-sec-title',
			]
		);

        $this->add_responsive_control(
			'section_title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'section_title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-sec-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

        $this->end_controls_section();

		/*-----------------------------------------Feedback styling------------------------------------*/

		$this->start_controls_section(
			'overview_con_styling',
			[
				'label' 	=> __( 'Feedback Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->start_controls_tabs(
			'style_tabs2'
		);

		$this->start_controls_tab(
			'style_normal_tab2',
			[
				'label' => esc_html__( 'Nmae', 'artraz' ),
			]
		);
        $this->add_control(
			'overview_title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_name'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_title_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .testi-box_name',
			]
		);

        $this->add_responsive_control(
			'overview_title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_name' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
		$this->end_controls_tab();

		//--------------------secound--------------------//

		$this->start_controls_tab(
			'style_hover_tab2',
			[
				'label' => esc_html__( 'Designation', 'artraz' ),
			]
		);
		$this->add_control(
			'overview_content_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_desig'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'overview_content_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .testi-box_desig',
			]
		);

        $this->add_responsive_control(
			'overview_content_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_desig' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'overview_content_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-box_desig' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();

		//--------------------three--------------------//

		$this->start_controls_tab(
			'style_hover_tab3',
			[
				'label' => esc_html__( 'Feedback', 'artraz' ),
			]
		);
		$this->add_control(
			'testi_feedback_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .testi-text'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'testi_feedback_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .testi-text',
			]
		);

        $this->add_responsive_control(
			'testi_feedback_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'testi_feedback_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .testi-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();


	}

	protected function render() {

		$settings = $this->get_settings_for_display();
		?>
		<?php if( $settings['layout_style'] == '2' ): ?>
            <div class="testi-card-wrap">
                <div class="row testi-card-slide th-carousel" id="testiSlide2" data-slide-show="1" data-fade="true">
                    <?php foreach( $settings['slides'] as $data ) : ?>
                    <div class="col-12">
                        <div class="testi-card">
                            <div class="testi-card_img">
                                <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['client_image']['url'] ),
                                ) ); ?>
                                <div class="testi-card_icon">
                                    <?php  echo artraz_img_tag( array(
                                        'url'	=> esc_url( $data['quote_image']['url'] ),
                                    ) ); ?>
                                </div>
                            </div>
                            <div class="testi-card_content">
                                <?php if( ! empty( $data['client_feedback'] ) ): ?>
                                    <p class="h3 testi-card_text testi-text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
                                <?php endif; ?>
                                <?php if( !empty( $data['client_name'] ) || !empty( $data['client_desig'] ) ): ?>
									<h6 class="testi-card_desig"><?php echo wp_kses_post( $data['client_desig'] ); ?> <span class="text-theme"> <?php echo esc_html( $data['client_name'] ); ?></span></h6>
			                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="icon-box">
                    <button data-slick-prev="#testiSlide2" class="slick-arrow default"><i class="fat fa-long-arrow-left"></i></button>
                    <button data-slick-next="#testiSlide2" class="slick-arrow default"><i class="fat fa-long-arrow-right"></i></button>
                </div>
            </div>
        <?php elseif( $settings['layout_style'] == '6' ): ?>
            <div class="row testi-box-slide th-carousel" data-slide-show="2" data-md-slide-show="1">
                <?php foreach( $settings['slides'] as $data ) : ?>
	                <div class="col-lg-6">
	                    <div class="testi-box">
	                        <?php if( ! empty( $data['client_feedback'] ) ): ?>
                                <p class="testi-box_text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
                            <?php endif; ?>
	                        <div class="testi-box_profile">
	                            <div class="testi-box_img">
	                                <?php  echo artraz_img_tag( array(
	                                    'url'	=> esc_url( $data['client_image']['url'] ),
	                                ) ); ?>
	                            </div>
	                            <div class="testi-box_info">
	                                <?php if( ! empty( $data['client_name'] ) ): ?>
                                        <h3 class="testi-box_name"><?php echo esc_html( $data['client_name'] ); ?></h3>
                                    <?php endif; ?>
	                                <?php if( ! empty( $data['client_desig'] ) ): ?>
                                        <span class="testi-box_desig"><?php echo esc_html( $data['client_desig'] ); ?></span>
                                    <?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="testi-box_icon">
	                            <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['quote_image']['url'] ),
                                ) ); ?>
	                        </div>
	                    </div>
	                </div>
                <?php endforeach; ?>
            </div>
        <?php elseif( $settings['layout_style'] == '5' ): ?>   

        	<div class="row testi-box-slide th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="1">
                <?php foreach( $settings['slides'] as $data ) : ?>
	                <div class="col-lg-6">
	                    <div class="testi-box style2">
	                        <div class="testi-box_review"> <?php
	                            if( $data['client_rating'] == 'one' ){
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
								}elseif( $data['client_rating'] == 'two' ){
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
								}elseif( $data['client_rating'] == 'three' ){
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
								}elseif( $data['client_rating'] == 'four' ){
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-light fa-solid fa-star"></i>';
								}else{
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
									echo '<i class="fa-sharp fa-solid fa-star"></i>';
								} ?>
	                        </div>
	                        <h3 class="testi-box_title"><?php echo esc_html( $data['feedback_title'] ); ?></h3>
	                        <?php if( ! empty( $data['client_feedback'] ) ): ?>
                                <p class="testi-box_text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
                            <?php endif; ?>
	                        <div class="testi-box_profile">
	                            <div class="testi-box_img">
	                                <?php  echo artraz_img_tag( array(
	                                    'url'	=> esc_url( $data['client_image']['url'] ),
	                                ) ); ?>
	                            </div>
	                            <div class="testi-box_info">
	                                <?php if( ! empty( $data['client_name'] ) ): ?>  
                                        <h4 class="testi-box_name"><?php echo esc_html( $data['client_name'] ); ?></h4>
                                    <?php endif; ?>
	                                <?php if( ! empty( $data['client_desig'] ) ): ?>
                                        <span class="testi-box_desig"><?php echo esc_html( $data['client_desig'] ); ?></span>
                                    <?php endif; ?>
	                            </div>
	                        </div>
	                        <div class="testi-box_icon">
	                            <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['quote_image']['url'] ),
                                ) ); ?>
	                        </div>
	                    </div>
	                </div>
                <?php endforeach; ?>

            </div>



		<?php elseif( $settings['layout_style'] == '3' ): ?>
            <section class="position-relative overflow-hidden  ">
        <div class="testi-video-slide th-carousel" id="testiVideo" data-asnavfor="#testiSlide1" data-slide-show="1" data-fade="true">
            <?php foreach( $settings['slides_2'] as $data ) : ?>
            <div>
                <?php if( ! empty( $data['video_overlay_text'] ) ): ?>
                    <span class="big-title"><?php echo esc_html( $data['video_overlay_text'] ); ?></span>
                <?php endif; ?>
                <div class="testi-video">
                    <?php  echo artraz_img_tag( array(
                        'url'	=> esc_url( $data['video_image']['url'] ),
                    ) ); ?>
                    <a href="<?php echo esc_url( $data['video_url']['url'] ); ?>" class="play-btn style2 popup-video"><i class="fas fa-play"></i></a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="testi-box-area">
            <div class="testi-box-wrap">
                <?php if( ! empty( $settings['testi_sec_title'] ) ): ?>
                    <h3 class="text-uppercase mt-n2 mb-30 testi-sec-title"><?php echo wp_kses_post( $settings['testi_sec_title'] ); ?></h3>
                <?php endif; ?>
                <div class="row testi-box-slide th-carousel" id="testiSlide1" data-asnavfor="#testiVideo" data-slide-show="1" data-fade="true">
                    <?php foreach( $settings['slides_2'] as $data ) : ?>
                    <div class="col-lg-6">
                        <div class="testi-box">
                            <?php if( ! empty( $data['client_feedback'] ) ): ?>
                                <p class="testi-box_text testi-text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
                            <?php endif; ?>
                            <div class="testi-box_profile">
                                <div class="testi-box_img">
                                    <?php  echo artraz_img_tag( array(
                                        'url'	=> esc_url( $data['client_image']['url'] ),
                                    ) ); ?>
                                </div>
                                <div class="testi-box_info">
                                    <?php if( ! empty( $data['client_name'] ) ): ?>
                                        <h3 class="testi-box_name"><?php echo esc_html( $data['client_name'] ); ?></h3>
                                    <?php endif; ?>
                                    <?php if( ! empty( $data['client_desig'] ) ): ?>
                                        <span class="testi-box_desig"><?php echo esc_html( $data['client_desig'] ); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="testi-box_icon">
                                <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['quote_image']['url'] ),
                                ) ); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="icon-box style1">
                    <button data-slick-prev="#testiSlide1" class="slick-arrow default"><i class="fat fa-long-arrow-left"></i></button>
                    <button data-slick-next="#testiSlide1" class="slick-arrow default"><i class="fat fa-long-arrow-right"></i></button>
                </div>
            </div>
        </div>
    </section>

    <?php elseif( $settings['layout_style'] == '4' ): ?>
    	<div class="testi-grid-wrap wow fadeInUp" data-wow-delay="0.2s" data-bg-src="<?php echo esc_url(  $settings['bg']['url']  ) ?>">
            <div class="testi-grid-icon">
                <?php  echo artraz_img_tag( array(
                    'url'	=> esc_url( $settings['quote']['url'] ),
                ) ); ?>
            </div>
            <div class="testi-grid-slide" id="testiSlide4">

                <?php foreach( $settings['slides'] as $data ) : ?>
                <div class="">
                    <div class="testi-grid">
                        <div class="testi-grid_profile">
                            <div class="testi-grid_avater">
                                <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['client_image']['url'] ),
                                ) ); ?>
                            </div>
                            <div class="media-body">
                            	<?php if( ! empty( $data['client_name'] ) ): ?>
                                	<h3 class="testi-grid_title"><?php echo esc_html( $data['client_name'] ); ?></h3>
                                <?php endif; ?>
                                <?php if( ! empty( $data['client_desig'] ) ): ?>
                                	<p class="testi-grid_desig"><?php echo esc_html( $data['client_desig'] ); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if( ! empty( $data['client_feedback'] ) ): ?>
                        <p class="testi-grid_text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                

            </div>
            <div class="slider-nav-wrap">
                <div class="slider-nav">
                    <button data-slick-prev="#testiSlide4" class="nav-btn"><i class="fal fa-long-arrow-left"></i></button>
                    <div class="custom-dots"></div>
                    <button data-slick-next="#testiSlide4" class="nav-btn"><i class="fal fa-long-arrow-right"></i></button>
                </div>
            </div>
        </div>





		<?php else: ?>
            <div class="row testi-box-slide th-carousel" data-slide-show="2" data-md-slide-show="1">
                <?php foreach( $settings['slides'] as $data ) : ?>
                <div class="col-lg-6">
                    <div class="testi-box">
                        <?php if( ! empty( $data['client_feedback'] ) ): ?>
			            	<p class="testi-box_text testi-text"><?php echo wp_kses_post( $data['client_feedback'] ); ?></p>
			            <?php endif; ?>

                        <div class="testi-box_profile">
                            <div class="testi-box_img">
                                <?php  echo artraz_img_tag( array(
                                    'url'	=> esc_url( $data['client_image']['url'] ),
                                ) ); ?>
                            </div>
                            <div class="testi-box_info">
                                <?php if( ! empty( $data['client_name'] ) ): ?>
			                    	<h3 class="testi-box_name"><?php echo esc_html( $data['client_name'] ); ?></h3>
			                    <?php endif; ?>
			                    <?php if( ! empty( $data['client_desig'] ) ): ?>
			                    	<span class="testi-box_desig"><?php echo esc_html( $data['client_desig'] ); ?></span>
			                    <?php endif; ?>
                            </div>
                        </div>
                        <div class="testi-box_icon">
                            <?php  echo artraz_img_tag( array(
								'url'	=> esc_url( $data['quote_image']['url'] ),
							) ); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>


		<?php
			endif;

	}

}