<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
/**
 *
 * Image Widget .
 *
 */
class Artraz_Image extends Widget_Base {

	public function get_name() {
		return 'artrazimage';
	}

	public function get_title() {
		return __( 'Image', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'image_section',
			[
				'label' 	=> __( 'Image', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
					'5' 		=> __( 'Style Five', 'artraz' ),
					'6' 		=> __( 'Style Six', 'artraz' ),
					'7' 		=> __( 'Style Seven', 'artraz' ),
					'8' 		=> __( 'Style Eight', 'artraz' ),
					'9' 		=> __( 'Style Nine', 'artraz' ),
					'10' 		=> __( 'Style Ten', 'artraz' ),
				],
			]
		);

        $this->add_control(
			'image',
			[
				'label' 		=> __( 'Choose Image', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
			]
		);   

		$this->add_control(
			'image2',
			[
				'label' 		=> __( 'Choose Image 2', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'layout_style' => ['4','6','9','10']
				]
			]
		); 
		$this->add_control(
			'image3',
			[
				'label' 		=> __( 'Choose Image 3', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'layout_style' => ['9','10']
				]
			]
		); 
		$this->add_control(
			'image4',
			[
				'label' 		=> __( 'Choose Image 4', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'default' 		=> [
					'url' 			=> Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'layout_style' => ['9']
				]
			]
		); 
		
		$this->add_control(
			'title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' 		=> 2,
				'condition' => [
				 	'layout_style' => ['3','8','9']
				 ]
			]
		);
		$this->add_control(
			'years',
            [
				'label'         => __( 'Years', 'artraz' ),
				'type'          => Controls_Manager::WYSIWYG,
				'default'       => __( 'Title' , 'artraz' ),
				'condition' => [
				 	'layout_style' => ['9']
				 ]
			]
		);

		$this->add_control(
			'phone_title',
            [
				'label'         => __( 'Phone Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Telephone Number:' , 'artraz' ),
				'label_block'   => true,
				'rows' 		=> 2,
				'condition' => [
				 	'layout_style' => ['2','7']
				 ]
			]
		);

		$this->add_control(
			'phone_icon',
            [
				'label'         => __( 'Phone Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="fal fa-phone"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
					'layout_style' => ['2','7']
				]
			]
		);		

		$this->add_control(
			'phone_number',
            [
				'label'         => __( 'Phone Number', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( '(+65) - 48596 - 5789' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['2','7']
				]

			]
		);
		$this->add_control(
			'phone_number2',
            [
				'label'         => __( 'Phone Number 2', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( '(+65) - 48596 - 5789' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['7']
				]

			]
		);
		
		$this->add_control(
			'email_title',
            [
				'label'         => __( 'Email Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Mail Address:' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
				 	'layout_style' => ['2','7']
				 ]
			]
		);
      
		$this->add_control(
			'email_icon',
            [
				'label'         => __( 'Email Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="far fa-envelope"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
					'layout_style' => ['2','7']
				]
			]
		);	

		$this->add_control(
			'email_address',
            [
				'label'         => __( 'Email Address', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'info@artraz.com' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['2','7']
				]
			]
		);
		$this->add_control(
			'email_address2',
            [
				'label'         => __( 'Email Address 2', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'info@artraz.com' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['7']
				]
			]
		);

		$this->add_control(
			'address_title',
            [
				'label'         => __( 'Address Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Address:' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
				 	'layout_style' => ['7']
				 ]
			]
		);
      
		$this->add_control(
			'address_icon',
            [
				'label'         => __( 'Address Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="far fa-envelope"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
					'layout_style' => ['7']
				]
			]
		);	

		$this->add_control(
			'address_address',
            [
				'label'         => __( 'Address', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'info@artraz.com' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['7']
				]
			]
		);

      
       $this->end_controls_section();

      	//---------------------------------------
			//Style Section Start
		//---------------------------------------

        $this->start_controls_section(
			'image_style_section',
			[
				'label' 	=> __( 'Image Style', 'artraz' ),
                'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_responsive_control(
			'width',
			[
				'label' 	=> __( 'Width', 'artraz' ),
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .e-img img' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'space',
			[
				'label' 	=> __( 'Max Width', 'artraz' ) . ' (%)',
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .e-img img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'height',
			[
				'label' 	=> __( 'Height', 'artraz' ),
				'type' 		=> Controls_Manager::SLIDER,
				'default' 	=> [
					'unit' 		=> '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'size_units' => [ '%', 'px', 'vw' ],
				'range' => [
					'%' => [
						'min' => 1,
						'max' => 100,
					],
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vw' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .e-img img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'separator_panel_style',
			[
				'type' 	=> Controls_Manager::DIVIDER,
				'style' => 'thick',
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'image_border',
				'selector' 	=> '{{WRAPPER}} .e-img img',
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' 		=> __( 'Border Radius', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'image_box_shadow',
				'exclude' 	=> [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} .e-img img',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

        ?>

		<?php if( $settings['layout_style'] == '2' ): 
			$email    	= $settings['email_address'];
			$phone    	= $settings['phone_number'];        
	
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$replace_phone  = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
	
			$emailurl       = str_replace( $replace, $with, $email );
			$phoneurl       = str_replace( $replace_phone, $with, $phone );	
		?>
			<div class="img-box5">
				<div class="img1 e-img">
					<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
				</div>
				<div class="info-card-wrap">
					<div class="info-card">
						<div class="info-card_icon">
							<?php echo wp_kses_post($settings['phone_icon']) ?>
						</div>
						<div class="info-card_content">
							<span class="info-card_text"><?php echo esc_html($settings['phone_title']); ?></span>
							<a  class="info-card_link" href="<?php echo esc_attr( 'tel:'.$phoneurl); ?>"><?php echo esc_html($phone); ?></a>
						</div>
					</div>
					<div class="info-card">
						<div class="info-card_icon">
							<?php echo wp_kses_post($settings['email_icon']) ?>
						</div>
						<div class="info-card_content">
							<span class="info-card_text"><?php echo esc_html($settings['email_title']); ?></span>
							<a class="info-card_link" href="<?php echo esc_attr( 'mailto:'.$emailurl); ?>"><?php echo esc_html($email); ?></a>
						</div>
					</div>
				</div>
			</div>

		<?php elseif( $settings['layout_style'] == '3' ): ?>
			<div class="img-box1">
				<div class="img1">
					<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
				</div>
				<h2 class="big-text"><?php echo wp_kses_post($settings['title']); ?></h2>
			</div>
		<?php elseif( $settings['layout_style'] == '10' ): ?>
			<div class="img-box9">
                <div class="img1 wow fadeInDown" data-wow-delay="0.2s">
                    <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
                </div>
                <div class="img2 wow fadeInLeft" data-wow-delay="0.2s">
                    <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image2']['url']  ),
						)); ?>
                </div>
                <div class="img3 wow fadeInUp" data-wow-delay="0.2s">
                    <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image3']['url']  ),
						)); ?>
                </div>
            </div>
		<?php elseif( $settings['layout_style'] == '8' ): ?>
			<div class="img-box7">
                <?php echo artraz_img_tag( array(
					'url'   => esc_url( $settings['image']['url']  ),
				)); ?>
                <div class="img-counter">
                    <?php echo wp_kses_post($settings['title']); ?>
                </div>
            </div>
		<?php elseif( $settings['layout_style'] == '4' ): ?>
			<div class="img-box3">
				<div class="img1">
					<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
				</div>
				<div class="img2">
					<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image2']['url']  ),
						)); ?>
				</div>
			</div>
		<?php elseif( $settings['layout_style'] == '5' ): ?>
			<div class="img-box3 style2">
                <div class="img1">
                    <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
                </div>
            </div>
        <?php elseif( $settings['layout_style'] == '9' ): ?>
        	<div class="img-box8">
                <div class="img-row">
                    <div class="experience-card wow fadeInLeft" data-wow-delay="0.2s">
                    	<span class="year" data-bg-src="assets/img/bg/text_bg_1.jpg">58</span>


                        <span class="year" data-bg-src="<?php echo esc_url( $settings['image']['url']  )?>"><?php echo esc_html($settings['title']) ?></span>
                        <?php if (!empty( $settings['years'] )){
                        	echo wp_kses_post( $settings['years'] );
                        } ?>
                    </div>
                    <div class="img1 wow fadeInDown" data-wow-delay="0.2s">
                        <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image2']['url']  ),
						)); ?>
                    </div>
                </div>
                <div class="img-row">
                    <div class="img2 wow fadeInUp" data-wow-delay="0.2s">
                        <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image3']['url']  ),
						)); ?>
                    </div>
                    <div class="img3 wow fadeInRight" data-wow-delay="0.2s">
                        <?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image4']['url']  ),
						)); ?>
                    </div>
                </div>
            </div>

        <?php elseif( $settings['layout_style'] == '6' ): ?>
        	<div class="ps-xxl-5">
                <div class="comparison-img-wrap">
                    <div class="comparison-img">
                        <p class="before">Before</p>
                        <p class="after">After</p>
                        <div class="img background-img" data-bg-src="<?php echo esc_url( $settings['image']['url']  ) ?>"></div>
                        <div class="img foreground-img" data-bg-src="<?php echo esc_url( $settings['image2']['url']  ) ?>"></div>
                        <input type="range" min="1" max="100" value="50" class="compslider" name="compslider" id="compslider">
                        <div class="slider-button" style="left: calc(50% - 28px);"></div>
                    </div>
                </div>
            </div>
        <?php elseif( $settings['layout_style'] == '7' ): 
        	$email    	= $settings['email_address'];
        	$email2    	= $settings['email_address2'];
			$phone    	= $settings['phone_number'];        
			$phone2    	= $settings['phone_number2'];        
	
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$replace_phone  = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
	
			$emailurl       = str_replace( $replace, $with, $email );
			$emailurl2       = str_replace( $replace, $with, $email2 );
			$phonneurl2       = str_replace( $replace_phone, $with, $phone2 );	

			?>
        	<div class="contact-img1">
                <div class="info-list-wrap">
                    <div class="info-list">
                        <div class="info-list_icon">
                            <?php echo wp_kses_post($settings['email_icon']) ?>
                        </div>
                        <div class="info-list_content">
                            <h4 class="info-list_title"><?php echo esc_html($settings['email_title']); ?></h4>
                            <p class="info-list_text">
                                <a href="<?php echo esc_attr( 'mailto:'.$emailurl); ?>"><?php echo esc_html($email); ?></a>
                                <a href="<?php echo esc_attr( 'mailto:'.$emailurl2); ?>"><?php echo esc_html($email2); ?></a>
                            </p>
                        </div>
                    </div>
                    <div class="info-list">
                        <div class="info-list_icon">
                            <?php echo wp_kses_post($settings['address_icon']) ?>
                        </div>
                        <div class="info-list_content">
                            <h4 class="info-list_title"><?php echo esc_html($settings['address_title']); ?></h4>
                            <p class="info-list_text"><?php echo esc_html($settings['address_address']); ?></p>
                        </div>
                    </div>
                    <div class="info-list">
                        <div class="info-list_icon">
                            <?php echo wp_kses_post($settings['phone_icon']) ?>
                        </div>
                        <div class="info-list_content">
                            <h4 class="info-list_title"><?php echo esc_html($settings['phone_title']); ?></h4>
                            <p class="info-list_text">
                                <a href="<?php echo esc_attr( 'tel:'.$phoneurl); ?>"><?php echo esc_html($phone); ?></a>
                                <a href="<?php echo esc_attr( 'tel:'.$phoneurl2); ?>"><?php echo esc_html($phone2); ?></a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="img1">
                   	<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
                </div>
            </div>
		<?php else: ?>
			<div class="img-box1">
				<div class="img1 e-img">
					<?php echo artraz_img_tag( array(
							'url'   => esc_url( $settings['image']['url']  ),
						)); ?>
				</div>
			</div>
      
      <?php endif;
	}

}