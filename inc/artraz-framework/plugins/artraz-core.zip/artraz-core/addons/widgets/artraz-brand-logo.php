<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
/**
 *
 * Brand Logo Widget .
 *
 */
class Artraz_Brand_Logo extends Widget_Base {

	public function get_name() {
		return 'artrazbrandlogo';
	}

	public function get_title() {
		return __( 'Brand Logo', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'client_logo_section',
			[
				'label' 	=> __( 'Brand Logo', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );


		$this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
				],
			]
		);

		$this->add_control(
			'arrow_id', [
				'label' 		=> __( 'Arrow ID', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'brandSlide1' , 'artraz' ),
				'rows' 			=> 2,
				'label_block' 	=> true,
				'condition' => [
					'layout_style' => '1',
				]
			]
        );

        $repeater = new Repeater();

		$repeater->add_control(
			'client_logo',
			[
				'label' 	=> __( 'Client Logo', 'artraz' ),
				'type' 		=> Controls_Manager::MEDIA,
				'default' => [
					'url' 	=> Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'client_title', [
				'label' 		=> __( 'Title', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'rows' 			=> 2,
				'default' 		=> __( 'Title 1 here' , 'artraz' ),
				'label_block' 	=> true,
			]
        );	

		$this->add_control(
			'logos',
			[
				'label' 		=> __( 'Client Logos', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'client_logo' => Utils::get_placeholder_image_src(),
					],
					[
						'client_logo' => Utils::get_placeholder_image_src(),
					],
					[
						'client_logo' => Utils::get_placeholder_image_src(),
					],
				]
			]
		);

        $this->end_controls_section();

		  //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------Genearl styling-------------------------------------//

        $this->start_controls_section(
			'general_section',
			[
				'label' => __( ' General Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			
			]
		);

		 $this->add_control(
			'general_color',
			[
				'label' 	=> __( 'Background', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .e-brand-wrap' => 'background-color: {{VALUE}}!important;',
                ],
			]
        );	

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'general_border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-brand-wrap',
			]
		);

		 $this->add_responsive_control(
			'general_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-brand-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

	    $settings = $this->get_settings_for_display();
	    ?>
	    
	    <?php if( $settings['layout_style'] == '2' ): ?>
			<div class="row th-carousel e-brand-wrap" data-slide-show="4" data-lg-slide-show="3" data-md-slide-show="2" data-sm-slide-show="2">
				<?php foreach( $settings['logos'] as $data ): ?>
                <div class="col-sm-6 col-lg-auto brand-img">
					<?php echo artraz_img_tag( array(
			                'url'   => esc_url( $data['client_logo']['url'] ),
			            ) ); ?>
                </div>
				<?php endforeach; ?>
            </div>
        <?php elseif( $settings['layout_style'] == '3' ): ?>
        	<div class="marque-sec1">
		        <div class="slick-marquee">
		        	<?php foreach( $settings['logos'] as $data ): ?>
			            <div class="">
			                <div class="marque-text">
			                    <?php echo artraz_img_tag( array(
									'url'   => esc_url( $data['client_logo']['url'] ),
								) );
			                    echo esc_html( $data['client_title'] );

								 ?>
			                </div>
			            </div>
		            <?php endforeach; ?>
		        </div>
		    </div>
		<?php elseif( $settings['layout_style'] == '4' ): ?>

			<div class="brand-grid-wrap wow fadeInUp" data-wow-delay="0.2s">
                <?php foreach( $settings['logos'] as $data ): ?>
	                <div class="brand-grid">
	                    <?php echo artraz_img_tag( array(
							'url'   => esc_url( $data['client_logo']['url'] ),
						) ); ?>
	                </div>
                <?php endforeach; ?>
            </div>

	    <?php else: ?>
			<div class="brand-img-wrap e-brand-wrap">
                <div class="row th-carousel" id="<?php echo esc_attr($settings['arrow_id']);?>" data-slide-show="4" data-lg-slide-show="3" data-md-slide-show="2" data-sm-slide-show="2">
					<?php foreach( $settings['logos'] as $data ): ?>
                    <div class="col-sm-6 col-lg-auto">
                        <div class="brand-img">
							<?php echo artraz_img_tag( array(
								'url'   => esc_url( $data['client_logo']['url'] ),
							) ); ?>
                        </div>
                    </div>
					<?php endforeach; ?>
                </div>
            </div>

    <?php endif;

	}
}