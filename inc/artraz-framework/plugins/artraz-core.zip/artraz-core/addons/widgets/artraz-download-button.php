<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Download Button Widget .
 *
 */
class artraz_Download_Button extends Widget_Base {

	public function get_name() {
		return 'artrazdownloadbutton';
	}

	public function get_title() {
		return __( 'Download Button', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'feature_section',
			[
				'label' 	=> __( 'Download Button', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );
        
		$this->add_control(
			'title',
			[
				'label'     => __( 'Title', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
			]
        );

        $repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'     => __( 'Title', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                  'default'  	=> __( 'Our Brochures', 'artraz' ),
			]
        );	

        $repeater->add_control(
			'subtitle',
			[
				'label'     => __( 'Subtitle', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                  'default'  	=> __( 'Download', 'artraz' ),
			]
        );	

        $repeater->add_control(
			'icon',
			[
				'label'     => __( 'Icon', 'artraz' ),
                'type'      => Controls_Manager::TEXTAREA,
                'rows' 		=> 2,
                 'default'  	=> __( '<i class="fal fa-file-pdf"></i>', 'artraz' ),
			]
        );        

 		$repeater->add_control(
			'button_url',
			[
				'label' => esc_html__( 'Link', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'textdomain' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
					// 'custom_attributes' => '',
				],
				'label_block' => true,
			]
		);
        $this->add_control(
			'files',
			[
				'label' 		=> __( 'Files', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'title' => __( 'Our Brochures', 'artraz' ),
					],
				]
			]
		);
		
		
        
        $this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <div class="widget widget_download  ">
            <h4 class="widget_title"><?php echo esc_html( $settings['title']) ; ?></h4>
            <div class="donwload-media-wrap">
                <?php foreach( $settings['files'] as $data ): ?>
                <div class="download-media">
                    <div class="download-media_icon">
                        <?php echo  wp_kses_post( $data['icon'] ); ?>
                    </div>
                    <div class="download-media_info">
                        <h5 class="download-media_title"><?php echo esc_html( $data['title'] ); ?></h5>
                        <span class="download-media_text"><?php echo esc_html( $data['subtitle'] ); ?></span>
                    </div>
                    <a href="<?php echo esc_url($data['button_url']['url']); ?>" class="download-media_btn"><i class="far fa-arrow-right"></i></a>
                </div>
                <?php endforeach; ?>
        </div>

        <?php

	}

}