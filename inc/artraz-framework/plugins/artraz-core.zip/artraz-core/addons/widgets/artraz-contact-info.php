<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Contact Info Widget .
 *
 */
class Artraz_Contact_Info extends Widget_Base {

	public function get_name() {
		return 'artrazcontactinfo';
	}

	public function get_title() {
		return __( 'Contact Info', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }


	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'title_section',
			[
				'label' 	=> __( 'Contact Info', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
				],
			]
		);

		$this->add_control(
			'title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2',
                'condition' => [
					'layout_style' => ['2', '4']
				]
			]
		);
		$this->add_control(
			'image',
			[
				'label' 		=> __( 'Choose Logo', 'artraz' ),
				'type' 			=> Controls_Manager::MEDIA,
				'dynamic' 		=> [
					'active' 		=> true,
				],
				'condition' => [
					'layout_style' => ['4']
				]
			]
		);  
		$this->add_control(
			'logo_link',
			[
				'label' 		=> __( 'Logo Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				'condition' => [
					'layout_style' => ['4']
				]
			]
		); 

        $this->end_controls_section();

		$this->start_controls_section(
			'phone_section',
			[
				'label' 	=> __( 'Phone Info', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition' => [
					'layout_style' => ['2', '3', '4']
				]
			]
        );

        $this->add_control(
			'phone_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Telephone Number:' , 'artraz' ),
				'label_block'   => true,
				'rows' 		=> 2,
			]
		);

		$this->add_control(
			'phone_icon',
            [
				'label'         => __( 'Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="fa fa-phone"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
			]
		);		

		$this->add_control(
			'phone_number',
            [
				'label'         => __( 'Phone Number', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( '(+65) - 48596 - 5789' , 'artraz' ),
				'label_block'   => true,

			]
		);

		$this->add_control(
			'phone_number2',
            [
				'label'         => __( 'Phone Number 2', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( '(+65) - 48596 - 5789' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['3', '4']
				]

			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'email_section',
			[
				'label' 	=> __( 'Email Info', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'email_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Mail Address:' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
				 	'layout_style' => ['2', '4']
				 ]
			]
		);
      
		$this->add_control(
			'email_icon',
            [
				'label'         => __( 'Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="far fa-envelope"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
			]
		);	

		$this->add_control(
			'email_address',
            [
				'label'         => __( 'Email Address', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'info@artraz.com' , 'artraz' ),
				'label_block'   => true,

			]
		);

		$this->add_control(
			'email_address2',
            [
				'label'         => __( 'Email Address 2', 'artraz' ),
				'type'          => Controls_Manager::TEXT,
				'default'       => __( 'info@artraz.com' , 'artraz' ),
				'label_block'   => true,
				'condition' => [
					'layout_style' => ['1', '3', '4']
				]
			]
		);
	
        $this->end_controls_section();

        $this->start_controls_section(
			'address_section',
			[
				'label' 	=> __( 'Address Info', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'address_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Office Address:' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
				 'condition' => [
				 	'layout_style' => ['2', '4']
				 ]
			]
		);

		$this->add_control(
			'address_icon',
            [
				'label'         => __( 'Icon', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '<i class="far fa-location-dot"></i>' , 'artraz' ),
				'label_block'   => true,
				 'rows' 		=> 2,
			]
		);	

		$this->add_control(
			'address_name',
            [
				'label'         => __( 'Address Name', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Burnsville, MN 55337 Streat, <br> United States' , 'artraz' ),
				'rows' 		=> 3,
			]
		);

		$this->add_control(
			'address_link',
			[
				'label' 		=> __( 'Address Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				'condition' => [
					'layout_style' => ['1', '3', '4']
				]
			]
		);
	
        $this->end_controls_section();

		$this->start_controls_section(
			'social_section',
			[
				'label' 	=> __( 'Social Profile', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
				'condition' => [
				 	'layout_style' => ['1']
				 ]
			]
        );

		$repeater = new Repeater();

        $repeater->add_control(
			'social_icon',
            [
				'label'         => __( 'Social Icon', 'artraz' ),
				'description'         => __( 'Set socail icon class with tag', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

		$repeater->add_control(
			'social_link',
			[
				'label' 		=> esc_html__( 'Social Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		
		$this->add_control(
			'social_lists',
			[
				'label' 		=> __( 'Social Lists', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' 		=> __( '<i class="fab fa-facebook-f"></i>', 'artraz' ),
					],
					[
						'social_icon' 		=> __( '<i class="fab fa-skype"></i>', 'artraz' ),
					],
				],
			]
		);

        $this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

        //-------------------------------------General styling-------------------------------------//

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'General Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'bg_color',
			[
				'label' 		=> __( 'Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .contact-info-wrap' => 'background-color: {{VALUE}}!important',
                ],
			]
        );

       $this->add_responsive_control(
			'contact_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .contact-info-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

       	$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'contact_box_shadow',
				'label' => esc_html__( 'Box Shadow', 'artraz' ),
				'selector' => '{{WRAPPER}} .contact-info-wrap',
			]
		);
		
        $this->end_controls_section();

        /*-----------------------------------------Content styling------------------------------------*/

		$this->start_controls_section(
			'overview_con_styling',
			[
				'label' 	=> __( 'Content Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->start_controls_tabs(
			'style_tabs2'
		);

			$this->start_controls_tab(
				'style_normal_tab2',
				[
					'label' => esc_html__( 'Label', 'artraz' ),
				]
			);

	        $this->add_control(
				'overview_title_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_title'	=> 'color: {{VALUE}}!important;'
					],
				]
	        );

	        $this->add_group_control(
			Group_Control_Typography::get_type(),
			 	[
					'name' 			=> 'overview_title_typography',
			 		'label' 		=> __( 'Typography', 'artraz' ),
			 		'selector' 	=> '{{WRAPPER}} .contact-info_title',
				]
			);

	        $this->add_responsive_control(
				'overview_title_margin',
				[
					'label' 		=> __( 'Margin', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
				]
	        );

			$this->end_controls_tab();

			//--------------------secound--------------------//

			$this->start_controls_tab(
				'style_hover_tab2',
				[
					'label' => esc_html__( 'Content', 'artraz' ),
				]
			);

			$this->add_control(
				'overview_content_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_text, {{WRAPPER}} .contact-info_text a'	=> 'color: {{VALUE}}!important;',
					],
				]
	        );

	        $this->add_group_control(
			Group_Control_Typography::get_type(),
			 	[
					'name' 			=> 'overview_content_typography',
			 		'label' 		=> __( 'Typography', 'artraz' ),
			 		'selector' 	=> '{{WRAPPER}} .contact-info_text',
				]
			);

	        $this->add_responsive_control(
				'overview_content_margin',
				[
					'label' 		=> __( 'Margin', 'artraz' ),
					'type' 			=> Controls_Manager::DIMENSIONS,
					'size_units' 	=> [ 'px', '%', 'em' ],
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
				]
	        );

			$this->end_controls_tab();

			//--------------------third--------------------//

			$this->start_controls_tab(
				'style_hover_tab3',
				[
					'label' => esc_html__( 'Icon', 'artraz' ),
				]
			);
			$this->add_control(
				'overview_icon_color',
				[
					'label' 		=> __( 'Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_icon'	=> 'color: {{VALUE}}!important;',
					],
				]
	        );		
	        $this->add_control(
				'overview_bg_color',
				[
					'label' 		=> __( 'Background Color', 'artraz' ),
					'type' 			=> Controls_Manager::COLOR,
					'selectors' 	=> [
						'{{WRAPPER}} .contact-info_icon'	=> 'background-color: {{VALUE}}!important;',
					],
				]
	        );
	        $this->add_group_control(
			Group_Control_Typography::get_type(),
			 	[
					'name' 			=> 'overview_icon_typography',
			 		'label' 		=> __( 'Typography', 'artraz' ),
			 		'selector' 	=> '{{WRAPPER}} .contact-info_icon',
				]
			);

			$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();
	
        ?>
        <?php if( $settings['layout_style'] == '2' ): 
			$email    	= $settings['email_address'];
			$phone    	= $settings['phone_number'];        
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$emailurl       = str_replace( $replace, $with, $email );
			$phoneurl       = str_replace( $replace_phone, $with, $phone );	
		?>
			<?php 
				if( !empty($settings['title']) ){
					echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
				}
			?>
			<div class="th-widget-contact">
				<div class="info-box">
					<div class="info-box_icon">
						<?php echo wp_kses_post($settings['address_icon']) ?>
					</div>
					<div class="media-body">
						<span class="info-box_label"><?php echo esc_html($settings['address_title']); ?></span>
						<p class="info-box_text"><?php echo wp_kses_post($settings['address_name']); ?></p>
					</div>
				</div>
				<div class="info-box">
					<div class="info-box_icon">
						<?php echo wp_kses_post($settings['phone_icon']) ?>
					</div>
					<div class="media-body">
						<span class="info-box_label"><?php echo esc_html($settings['phone_title']); ?></span>
						<a class="info-box_link" href="<?php echo esc_attr( 'tel:'.$phoneurl); ?>"><?php echo esc_html($phone); ?></a>
					</div>
				</div>
				<div class="info-box">
					<div class="info-box_icon">
						<?php echo wp_kses_post($settings['email_icon']) ?>
					</div>
					<div class="media-body">
						<span class="info-box_label"><?php echo esc_html($settings['email_title']); ?></span>
						<a class="info-box_link" href="<?php echo esc_attr( 'mailto:'.$emailurl); ?>"><?php echo esc_html($email); ?></a>
					</div>
				</div>
			</div>

    	<?php elseif( $settings['layout_style'] == '3' ): 
			$email    	= $settings['email_address'];
			$email2    	= $settings['email_address2'];
			$phone    	= $settings['phone_number'];        
			$phone2    	= $settings['phone_number2'];
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$emailurl       = str_replace( $replace, $with, $email );
			$email2url       = str_replace( $replace, $with, $email2 );
			$phoneurl       = str_replace( $replace_phone, $with, $phone );	
			$phone2url       = str_replace( $replace_phone, $with, $phone2 );
		?>
			<div class="footer-info-box">
				<div class="row gx-0 justify-content-between">
					<div class="col-lg-4 col-sm-auto">
						<div class="footer-box">
							<h6 class="footer-info has-icon">
								<?php echo wp_kses_post($settings['email_icon']) ?>
								<a class="link" href="<?php echo esc_attr( 'mailto:'.$emailurl); ?>"><?php echo esc_html($email); ?></a>
								<a class="link" href="<?php echo esc_attr( 'mailto:'.$email2url); ?>"><?php echo esc_html($email2); ?></a>
							</h6>
						</div>
					</div>
					<div class="col-lg-4 col-md order-3 order-md-0">
						<div class="footer-box">
							<h6 class="footer-info has-icon">
								<?php echo wp_kses_post($settings['phone_icon']) ?>
								<a class="link" href="<?php echo esc_attr( 'tel:'.$phoneurl); ?>"><?php echo esc_html($phone); ?></a>
								<a class="link" href="<?php echo esc_attr( 'tel:'.$phone2url); ?>"><?php echo esc_html($phone2); ?></a>
							</h6>
						</div>
					</div>
					<div class="col-lg-4 col-sm-auto">
						<div class="footer-box">
							<h6 class="footer-info has-icon">
								<?php echo wp_kses_post($settings['address_icon']) ?>
								<a class="link" href="<?php echo esc_url($settings['address_link']['url']) ?>"><?php echo wp_kses_post($settings['address_name']); ?></a>
							</h6>
						</div>
					</div>
				</div>
			</div>

		<?php elseif( $settings['layout_style'] == '4' ): 
			$email    	= $settings['email_address'];
			$email2    	= $settings['email_address2'];
			$phone    	= $settings['phone_number'];        
			$phone2    	= $settings['phone_number2'];
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$replace_phone        = array(' ','-',' - ', '(', ')');
			$with           = array('','','');
			$emailurl       = str_replace( $replace, $with, $email );
			$email2url       = str_replace( $replace, $with, $email2 );
			$phoneurl       = str_replace( $replace_phone, $with, $phone );	
			$phone2url       = str_replace( $replace_phone, $with, $phone2 );

			echo '<div class="row justify-content-between">';
				echo '<div class="col-sm-6 col-lg-auto">';
					echo '<div class="widget footer-widget">';
						if( !empty($settings['title']) ){
							echo '<h4 class="widget_title">'.esc_html($settings['title']).'</h4>';
						}
						echo '<div class="logo">';
							echo '<a href="'.esc_url( $settings['logo_link']['url'] ).'">';
								echo artraz_img_tag( array(
									'url'   => esc_url( $settings['image']['url']  ),
								));
							echo '</a>';
							
						echo '</div>';
					echo '</div>';
				echo '</div>';
				echo '<div class="col-sm-6 col-lg-auto">';
					echo '<div class="widget footer-widget">';
						if( !empty($settings['phone_title']) ){
							echo '<h4 class="widget_title">'.esc_html($settings['phone_title']).'</h4>';
						}
						echo '<h6 class="footer-info">';
							echo '<a class="link" href="'.esc_attr( 'tel:'.$phoneurl).'">'.esc_html($phone).'</a>';
							echo '<a class="link" href="'.esc_attr( 'tel:'.$phone2url).'">'.esc_html($phone2).'</a>';
						echo '</h6>';
					echo '</div>';
				echo '</div>';
				echo '<div class="col-sm-6 col-lg-auto">';
					echo '<div class="widget footer-widget">';
						if( !empty($settings['email_title']) ){
							echo '<h4 class="widget_title">'.esc_html($settings['email_title']).'</h4>';
						}
						echo '<h6 class="footer-info">';
							echo '<a class="link" href="'.esc_attr( 'mailto:'.$emailurl).'">'.esc_html($email).'</a>';
							echo '<a class="link" href="'.esc_attr( 'mailto:'.$email2url).'">'.esc_html($email2).'</a>';
						echo '</h6>';
					echo '</div>';
				echo '</div>';
				echo '<div class="col-sm-6 col-lg-auto">';
					echo '<div class="widget footer-widget">';
						if( !empty($settings['address_title']) ){
							echo '<h4 class="widget_title">'.esc_html($settings['address_title']).'</h4>';
						}
						echo '<h6 class="footer-info">';
							echo '<a class="link" href="'.esc_url($settings['address_link']['url']).'">'.wp_kses_post($settings['address_name']).'</a>';
						echo '</h6>';
					echo '</div>';
				echo '</div>';
			echo '</div>';
		?>
        <?php else: 
			$email    	= $settings['email_address'];
			$email2    	= $settings['email_address2'];
			$email          = is_email( $email );
			$replace        = array(' ','-',' - ');
			$with           = array('','','');
			$emailurl       = str_replace( $replace, $with, $email );
			$email2url       = str_replace( $replace, $with, $email2 );
		?>
			<div class="footer-info-box">
				<div class="row gx-0 justify-content-between">
					<div class="col-lg-4 col-sm-auto">
						<div class="footer-box">
							<h6 class="footer-info has-icon">
								<?php echo wp_kses_post($settings['email_icon']) ?>
								<a class="link" href="<?php echo esc_attr( 'mailto:'.$emailurl); ?>"><?php echo esc_html($email); ?></a>
								<a class="link" href="<?php echo esc_attr( 'mailto:'.$email2url); ?>"><?php echo esc_html($email2); ?></a>
							</h6>
						</div>
					</div>
					<div class="col-lg-4 col-md order-3 order-md-0">
						<div class="footer-box">
							<div class="th-social">
							<?php  foreach( $settings['social_lists'] as $data ): ?>
								<a target="_blank" href="<?php echo esc_url( $data['social_link']['url'] ); ?>"><?php echo wp_kses_post($data['social_icon']); ?></a>
							<?php endforeach; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-auto">
						<div class="footer-box">
							<h6 class="footer-info has-icon">
								<?php echo wp_kses_post($settings['address_icon']) ?>
								<a class="link" href="<?php echo esc_url($settings['address_link']['url']); ?>"><?php echo wp_kses_post($settings['address_name']); ?></a>
							</h6>
						</div>
					</div>
				</div>
			</div>

        <?php  endif;

	}

}