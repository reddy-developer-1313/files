<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Background;
/**
 * 
 * Newsletter Widget .
 *
 */
class Artraz_Newsletter_Widgets extends Widget_Base {

	public function get_name() {
		return 'artraznewsletter2';
	}

	public function get_title() {
		return __( 'Newsletter', 'artraz' );
	}


	public function get_icon() {
		return 'th-icon';
    }
    

	public function get_categories() {
		return [ 'artraz' ];
	}

	
	protected function register_controls() {


		$this->start_controls_section(
			'newsletter_content',
			[
				'label' 	=> __( 'Newsletter', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Newsletter Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
				],
			]
		);

		$this->add_control(
			'newsletter_placeholder',
			[
				'label' 		=> __( 'Newsletter Placeholder Text', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Enter Your Email', 'artraz' ),
			]
		);

		$this->add_control(
			'newsletter_button',
			[
				'label' 		=> __( 'Newsletter Button Text', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'Subscribe', 'artraz' ),
				'condition' => [
					'layout_style' => ['1']
				]
			]
		);
		$this->add_control(
			'newsletter_icon',
			[
				'label'     => __( 'Icon Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'condition' => [
					'layout_style' => ['2']
				]
			]
		);


       $this->end_controls_section();

        //-------------------------------button styling--------------------------------//
		
		$this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1']
				]
			]
        );
        $this->add_control(
			'button_txt_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn' => 'color: {{VALUE}}',
                ],
			]
        );
        $this->add_control(
			'button_txt_hvr_color',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn:hover' => 'color: {{VALUE}}',
                ],
			]
        );

        $this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn' => 'background-color: {{VALUE}}',
                ],
			]
        );
        $this->add_control(
			'button_hvr_color',
			[
				'label' 		=> __( 'Background Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn:before, {{WRAPPER}}  .th-btn:after' => 'background-color: {{VALUE}}',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border2',
				'label' 	=> __( 'Border Hover', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn:hover',
			]
		);

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn',
			]
        );

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( ' Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);
        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( ' Border Radius', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);
        $this->end_controls_section();
	}

	protected function render() {

        $settings = $this->get_settings_for_display();
?>
        <?php if( $settings['layout_style'] == '2' ): ?>
			<div class="footer-search-contact">
            <form>
                <input class="form-control input-style-1" type="email"
                    placeholder="<?php echo esc_attr( $settings['newsletter_placeholder'] ); ?>">
                <button type="submit" class="btn-sub">
                   <?php echo artraz_img_tag( array(
									'url'   => esc_url( $settings['newsletter_icon']['url']  ),
								)); ?>
                </button>
            </form>
        </div>
    	<?php else: ?>
             <form class="newsletter-form">
                <input class="form-control" type="email" placeholder="<?php echo esc_attr( $settings['newsletter_placeholder'] ); ?>" required="">
                <button type="submit" class="th-btn shadow-none"><?php echo esc_html( $settings['newsletter_button'] ); ?></button>
            </form>

	<?php
	endif;
	}
}
						