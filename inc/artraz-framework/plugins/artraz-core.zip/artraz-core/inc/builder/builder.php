<?php
    /**
     * Class For Builder
     */
    class ArtrazBuilder{

        function __construct(){
            // register admin menus
        	add_action( 'admin_menu', [$this, 'register_settings_menus'] );

            // Custom Footer Builder With Post Type
			add_action( 'init',[ $this,'post_type' ],0 );

 		    add_action( 'elementor/frontend/after_enqueue_scripts', [ $this,'widget_scripts'] );

			add_filter( 'single_template', [ $this, 'load_canvas_template' ] );

            add_action( 'elementor/element/wp-page/document_settings/after_section_end', [ $this,'artraz_add_elementor_page_settings_controls' ],10,2 );

		}

		public function widget_scripts( ) {
			wp_enqueue_script( 'artraz-core',ARTRAZ_PLUGDIRURI.'assets/js/artraz-core.js',array( 'jquery' ),'1.0',true );
		}


        public function artraz_add_elementor_page_settings_controls( \Elementor\Core\DocumentTypes\Page $page ){

			$page->start_controls_section(
                'artraz_header_option',
                [
                    'label'     => __( 'Header Option', 'artraz' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );


            $page->add_control(
                'artraz_header_style',
                [
                    'label'     => __( 'Header Option', 'artraz' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'artraz' ),
    					'header_builder'       => __( 'Header Builder', 'artraz' ),
    				],
                    'default'   => 'prebuilt',
                ]
			);

            $page->add_control(
                'artraz_header_builder_option',
                [
                    'label'     => __( 'Header Name', 'artraz' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->artraz_header_choose_option(),
                    'condition' => [ 'artraz_header_style' => 'header_builder'],
                    'default'	=> ''
                ]
            );

            $page->end_controls_section();

            $page->start_controls_section(
                'artraz_footer_option',
                [
                    'label'     => __( 'Footer Option', 'artraz' ),
                    'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
                ]
            );
            $page->add_control(
    			'artraz_footer_choice',
    			[
    				'label'         => __( 'Enable Footer?', 'artraz' ),
    				'type'          => \Elementor\Controls_Manager::SWITCHER,
    				'label_on'      => __( 'Yes', 'artraz' ),
    				'label_off'     => __( 'No', 'artraz' ),
    				'return_value'  => 'yes',
    				'default'       => 'yes',
    			]
    		);
            $page->add_control(
                'artraz_footer_style',
                [
                    'label'     => __( 'Footer Style', 'artraz' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => [
    					'prebuilt'             => __( 'Pre Built', 'artraz' ),
    					'footer_builder'       => __( 'Footer Builder', 'artraz' ),
    				],
                    'default'   => 'prebuilt',
                    'condition' => [ 'artraz_footer_choice' => 'yes' ],
                ]
            );
            $page->add_control(
                'artraz_footer_builder_option',
                [
                    'label'     => __( 'Footer Name', 'artraz' ),
                    'type'      => \Elementor\Controls_Manager::SELECT,
                    'options'   => $this->artraz_footer_build_choose_option(),
                    'condition' => [ 'artraz_footer_style' => 'footer_builder','artraz_footer_choice' => 'yes' ],
                    'default'	=> ''
                ]
            );

			$page->end_controls_section();

        }

		public function register_settings_menus(){
			add_menu_page(
				esc_html__( 'Artraz Builder', 'artraz' ),
            	esc_html__( 'Artraz Builder', 'artraz' ),
				'manage_options',
				'artraz',
				[$this,'register_settings_contents__settings'],
				'dashicons-admin-site',
				2
			);

			add_submenu_page('artraz', esc_html__('Footer Builder', 'artraz'), esc_html__('Footer Builder', 'artraz'), 'manage_options', 'edit.php?post_type=artraz_footer_build');
			add_submenu_page('artraz', esc_html__('Header Builder', 'artraz'), esc_html__('Header Builder', 'artraz'), 'manage_options', 'edit.php?post_type=artraz_header');
			add_submenu_page('artraz', esc_html__('Tab Builder', 'artraz'), esc_html__('Tab Builder', 'artraz'), 'manage_options', 'edit.php?post_type=artraz_tab_builder');
		}

		// Callback Function
		public function register_settings_contents__settings(){
            echo '<h2>';
			    echo esc_html__( 'Welcome To Header And Footer Builder Of This Theme','artraz' );
            echo '</h2>';
		}

		public function post_type() {

			$labels = array(
				'name'               => __( 'Footer', 'artraz' ),
				'singular_name'      => __( 'Footer', 'artraz' ),
				'menu_name'          => __( 'Artraz Footer Builder', 'artraz' ),
				'name_admin_bar'     => __( 'Footer', 'artraz' ),
				'add_new'            => __( 'Add New', 'artraz' ),
				'add_new_item'       => __( 'Add New Footer', 'artraz' ),
				'new_item'           => __( 'New Footer', 'artraz' ),
				'edit_item'          => __( 'Edit Footer', 'artraz' ),
				'view_item'          => __( 'View Footer', 'artraz' ),
				'all_items'          => __( 'All Footer', 'artraz' ),
				'search_items'       => __( 'Search Footer', 'artraz' ),
				'parent_item_colon'  => __( 'Parent Footer:', 'artraz' ),
				'not_found'          => __( 'No Footer found.', 'artraz' ),
				'not_found_in_trash' => __( 'No Footer found in Trash.', 'artraz' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'artraz_footer_build', $args );

			$labels = array(
				'name'               => __( 'Header', 'artraz' ),
				'singular_name'      => __( 'Header', 'artraz' ),
				'menu_name'          => __( 'Artraz Header Builder', 'artraz' ),
				'name_admin_bar'     => __( 'Header', 'artraz' ),
				'add_new'            => __( 'Add New', 'artraz' ),
				'add_new_item'       => __( 'Add New Header', 'artraz' ),
				'new_item'           => __( 'New Header', 'artraz' ),
				'edit_item'          => __( 'Edit Header', 'artraz' ),
				'view_item'          => __( 'View Header', 'artraz' ),
				'all_items'          => __( 'All Header', 'artraz' ),
				'search_items'       => __( 'Search Header', 'artraz' ),
				'parent_item_colon'  => __( 'Parent Header:', 'artraz' ),
				'not_found'          => __( 'No Header found.', 'artraz' ),
				'not_found_in_trash' => __( 'No Header found in Trash.', 'artraz' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'artraz_header', $args );

			$labels = array(
				'name'               => __( 'Tab Builder', 'artraz' ),
				'singular_name'      => __( 'Tab Builder', 'artraz' ),
				'menu_name'          => __( 'Gesund Tab Builder', 'artraz' ),
				'name_admin_bar'     => __( 'Tab Builder', 'artraz' ),
				'add_new'            => __( 'Add New', 'artraz' ),
				'add_new_item'       => __( 'Add New Tab Builder', 'artraz' ),
				'new_item'           => __( 'New Tab Builder', 'artraz' ),
				'edit_item'          => __( 'Edit Tab Builder', 'artraz' ),
				'view_item'          => __( 'View Tab Builder', 'artraz' ),
				'all_items'          => __( 'All Tab Builder', 'artraz' ),
				'search_items'       => __( 'Search Tab Builder', 'artraz' ),
				'parent_item_colon'  => __( 'Parent Tab Builder:', 'artraz' ),
				'not_found'          => __( 'No Tab Builder found.', 'artraz' ),
				'not_found_in_trash' => __( 'No Tab Builder found in Trash.', 'artraz' ),
			);

			$args = array(
				'labels'              => $labels,
				'public'              => true,
				'rewrite'             => false,
				'show_ui'             => true,
				'show_in_menu'        => false,
				'show_in_nav_menus'   => false,
				'exclude_from_search' => true,
				'capability_type'     => 'post',
				'hierarchical'        => false,
				'supports'            => array( 'title', 'elementor' ),
			);

			register_post_type( 'artraz_tab_builder', $args );
		}

		function load_canvas_template( $single_template ) {

			global $post;

			if ( 'artraz_footer_build' == $post->post_type || 'artraz_header' == $post->post_type || 'artraz_tab_build' == $post->post_type ) {

				$elementor_2_0_canvas = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

				if ( file_exists( $elementor_2_0_canvas ) ) {
					return $elementor_2_0_canvas;
				} else {
					return ELEMENTOR_PATH . '/includes/page-templates/canvas.php';
				}
			}

			return $single_template;
		}

        public function artraz_footer_build_choose_option(){

			$artraz_post_query = new WP_Query( array(
				'post_type'			=> 'artraz_footer_build',
				'posts_per_page'	    => -1,
			) );

			$artraz_builder_post_title = array();
			$artraz_builder_post_title[''] = __('Select a Footer','Artraz');

			while( $artraz_post_query->have_posts() ) {
				$artraz_post_query->the_post();
				$artraz_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $artraz_builder_post_title;

		}

		public function artraz_header_choose_option(){

			$artraz_post_query = new WP_Query( array(
				'post_type'			=> 'artraz_header',
				'posts_per_page'	    => -1,
			) );

			$artraz_builder_post_title = array();
			$artraz_builder_post_title[''] = __('Select a Header','Artraz');

			while( $artraz_post_query->have_posts() ) {
				$artraz_post_query->the_post();
				$artraz_builder_post_title[ get_the_ID() ] =  get_the_title();
			}
			wp_reset_postdata();

			return $artraz_builder_post_title;

        }

    }

    $builder_execute = new ArtrazBuilder();