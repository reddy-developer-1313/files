<?php
/**
* @version  1.0
* @package  artraz
* @author   Artraz <support@themeholy.com>
*
* Websites: https://themeholy.com/
*
*/

/**************************************
* Creating Offer Banner Widget
***************************************/

class artraz_offer_banner_widget extends WP_Widget {

        function __construct() {

            parent::__construct(
                // Base ID of your widget
                'artraz_offer_banner_widget',

                // Widget name will appear in UI
                esc_html__( 'Artraz :: Offer Banner Widget', 'artraz' ),

                // Widget description
                array(
                    'customize_selective_refresh'   => true,
                    'description'                   => esc_html__( 'Add Offer Banner Widget', 'artraz' ),
                    'classname'                     => 'no-banner-widget',
                )
            );

        }

        // This is where the action happens
        public function widget( $args, $instance ) {
            $banner_number   = apply_filters( 'widget_banner_number', $instance['banner_number'] );
            $banner_title   = apply_filters( 'widget_banner_title', $instance['banner_title'] );
            $banner_title2   = apply_filters( 'widget_banner_title2', $instance['banner_title2'] );
            $banner_desc   = apply_filters( 'widget_banner_desc', $instance['banner_desc'] );
            $button_text   = apply_filters( 'widget_button_text', $instance['button_text'] );

            $replace    = array(' ','-',' - ');
            $with       = array('','','');

            $number_url  = str_replace( $replace, $with, $banner_number );

            if ( isset( $instance[ 'banner_img_url' ] ) ) {
                $banner_img_url = $instance[ 'banner_img_url' ];
            }else {
                $banner_img_url = '#';
            }            

            if ( isset( $instance[ 'button_url' ] ) ) {
                $button_url = $instance[ 'button_url' ];
            }else {
                $button_url = '#';
            }

        	echo $args['before_widget'];
        	?>
                <div class="widget-banner">
                    <h4 class="title" data-bg-src="<?php echo esc_url($banner_img_url ); ?>"><?php echo esc_html( $banner_title ); ?> <br> <span class="text-transparent"><?php echo esc_html( $banner_title2 ); ?></span></h4>
                    <div class="content">
                        <div>
                            <a href="<?php echo esc_attr( 'tel:'.$number_url ) ?>" class="link"><i class="fas fa-phone"></i><?php echo esc_html( $banner_number ); ?></a>
                        </div>
                        <p class="text"><?php echo esc_html( $banner_desc ); ?></p>
                        <?php if( !empty( $button_text )): ?>
                            <a href="<?php echo esc_url( $button_url ); ?>" class="th-btn"><span class="line left"></span> <?php echo esc_html( $button_text ); ?> <span class="line"></span></a>
                        <?php endif; ?>
                    </div>
                </div>

        	<?php
           echo $args['after_widget'];
        }

        // Widget Backend
        public function form( $instance ) {

             //Image Url
            if ( isset( $instance[ 'banner_img_url' ] ) ) {
                $banner_img_url = $instance[ 'banner_img_url' ];
            }else {
                $banner_img_url = '';
            }
            
            if ( isset( $instance[ 'banner_number' ] ) ) {
                $banner_number = $instance[ 'banner_number' ];
            }else {
                $banner_number = '';
            }

            if ( isset( $instance[ 'banner_title' ] ) ) {
                $banner_title = $instance[ 'banner_title' ];
            }else {
                $banner_title = '';
            }   
            
            if ( isset( $instance[ 'banner_title2' ] ) ) {
                $banner_title2 = $instance[ 'banner_title2' ];
            }else {
                $banner_title2 = '';
            }  

            if ( isset( $instance[ 'banner_desc' ] ) ) {
                $banner_desc = $instance[ 'banner_desc' ];
            }else {
                $banner_desc = '';
            } 

            if ( isset( $instance[ 'button_text' ] ) ) {
                $button_text = $instance[ 'button_text' ];
            }else {
                $button_text = '';
            }            

            if ( isset( $instance[ 'button_url' ] ) ) {
                $button_url = $instance[ 'button_url' ];
            }else {
                $button_url = '';
            }

        	?>
            <p>
                <label for="<?php echo $this->get_field_id( 'banner_img_url' ); ?>"><?php _e( 'Image URL:' ,'artraz'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'banner_img_url' ); ?>" name="<?php echo $this->get_field_name( 'banner_img_url' ); ?>" type="text" value="<?php echo esc_attr( $banner_img_url ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'banner_title' ); ?>"><?php _e( 'Banner Title:' ,'artraz'); ?></label>
                <textarea class="widefat" id="<?php echo $this->get_field_id( 'banner_title' ); ?>" name="<?php echo $this->get_field_name( 'banner_title' ); ?>" rows="2" cols="80"><?php echo esc_html( $banner_title ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'banner_title2' ); ?>"><?php _e( 'Banner Title 2:' ,'artraz'); ?></label>
                <textarea class="widefat" id="<?php echo $this->get_field_id( 'banner_title2' ); ?>" name="<?php echo $this->get_field_name( 'banner_title2' ); ?>" rows="2" cols="80"><?php echo esc_html( $banner_title2 ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'banner_number' ); ?>"><?php _e( 'Banner Number:' ,'artraz'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'banner_number' ); ?>" name="<?php echo $this->get_field_name( 'banner_number' ); ?>" type="text" value="<?php echo esc_attr( $banner_number ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'banner_desc' ); ?>"><?php _e( 'Banner Description:' ,'artraz'); ?></label>
                <textarea class="widefat" id="<?php echo $this->get_field_id( 'banner_desc' ); ?>" name="<?php echo $this->get_field_name( 'banner_desc' ); ?>" rows="2" cols="80"><?php echo esc_html( $banner_desc ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'button_text' ); ?>"><?php _e( 'Button Text:' ,'artraz'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'button_text' ); ?>" name="<?php echo $this->get_field_name( 'button_text' ); ?>" type="text" value="<?php echo esc_attr( $button_text ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id( 'button_url' ); ?>"><?php _e( 'Button URL:' ,'artraz'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'button_url' ); ?>" name="<?php echo $this->get_field_name( 'button_url' ); ?>" type="text" value="<?php echo esc_attr( $button_url ); ?>" />
            </p>

        	<?php
           
        }


         // Updating widget replacing old instances with new
         public function update( $new_instance, $old_instance ) {
                $instance = array();

                $instance['banner_img_url']    = ( ! empty( $new_instance['banner_img_url'] ) ) ? strip_tags( $new_instance['banner_img_url'] ) : '';
                $instance['banner_title']       = ( ! empty( $new_instance['banner_title'] ) ) ? strip_tags( $new_instance['banner_title'] ) : '';  
                $instance['banner_title2']       = ( ! empty( $new_instance['banner_title2'] ) ) ? strip_tags( $new_instance['banner_title2'] ) : '';  
                $instance['banner_number']    = ( ! empty( $new_instance['banner_number'] ) ) ? strip_tags( $new_instance['banner_number'] ) : '';
                $instance['banner_desc']       = ( ! empty( $new_instance['banner_desc'] ) ) ? strip_tags( $new_instance['banner_desc'] ) : ''; 
                $instance['button_text']      = ( ! empty( $new_instance['button_text'] ) ) ? strip_tags( $new_instance['button_text'] ) : '';  
                $instance['button_url']     = ( ! empty( $new_instance['button_url'] ) ) ? strip_tags( $new_instance['button_url'] ) : '';
                return $instance;
           
        }

    } // Class artraz_offer_banner_widget ends here


    // Register and load the widget
    function artraz_offer_banner_load_widget() {
        register_widget( 'artraz_offer_banner_widget' );
    }
    add_action( 'widgets_init', 'artraz_offer_banner_load_widget' );