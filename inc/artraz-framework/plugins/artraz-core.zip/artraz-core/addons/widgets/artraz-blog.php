<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
/**
 *
 * Blog Post Widget .
 *
 */
class Artraz_Blog extends Widget_Base {

	public function get_name() {
		return 'artrazblog';
	}

	public function get_title() {
		return __( 'Blog Post', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'blog_post_section',
			[
				'label' => __( 'Blog Post', 'artraz' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
				],
				'separator' => 'after'
			]
		);

        $this->add_control(
			'blog_post_count',
			[
				'label' 	=> __( 'No of Post to show', 'artraz' ),
                'type' 		=> Controls_Manager::NUMBER,
                'min'       => 1,
                'max'       => count( get_posts( array('post_type' => 'post', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => '-1') ) ),
                'default'  	=> __( '4', 'artraz' )
			]
        );

		$this->add_control(
			'title_count',
			[
				'label' 	=> __( 'Title Length', 'artraz' ),
				'type' 		=> Controls_Manager::TEXT,
				'default'  	=> __( '5', 'artraz' ),
			]
		);

		$this->add_control(
			'excerpt_count',
			[
				'label' 	=> __( 'Excerpt Length', 'artraz' ),
				'type' 		=> Controls_Manager::TEXT,
				'default'  	=> __( '16', 'artraz' ),
			]
		);

        $this->add_control(
			'blog_post_order',
			[
				'label' 	=> __( 'Order', 'artraz' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ASC'   	=> __('ASC','artraz'),
                    'DESC'   	=> __('DESC','artraz'),
                ],
                'default'  	=> 'DESC'
			]
        );

        $this->add_control(
			'blog_post_order_by',
			[
				'label' 	=> __( 'Order By', 'artraz' ),
                'type' 		=> Controls_Manager::SELECT,
                'options'   => [
                    'ID'    	=> __( 'ID', 'artraz' ),
                    'author'    => __( 'Author', 'artraz' ),
                    'title'    	=> __( 'Title', 'artraz' ),
                    'date'    	=> __( 'Date', 'artraz' ),
                    'rand'    	=> __( 'Random', 'artraz' ),
                ],
                'default'  	=> 'ID'
			]
        );

        $this->add_control(
			'exclude_cats',
			[
				'label' 		=> __( 'Exclude Categories', 'artraz' ),
                'type' 			=> Controls_Manager::SELECT2,
                'multiple' 		=> true,
				'options' 		=> $this->artraz_get_categories(),
			]
        );

        $this->add_control(
			'exclude_tags',
			[
				'label' 		=> __( 'Exclude Tags', 'artraz' ),
                'type' 			=> Controls_Manager::SELECT2,
                'multiple' 		=> true,
				'options' 		=> $this->artraz_get_tags(),
			]
        );

        $this->add_control(
			'exclude_post_id',
			[
				'label'         => __( 'Exclude Post', 'artraz' ),
                'type'          => Controls_Manager::SELECT2,
                'multiple'      => true,
				'options'       => $this->artraz_post_id(),
			]
        );

        $this->add_control(
			'read_more',
			[
				'label' 	=> __( 'Read More Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> __( 'Read More', 'artraz' ),
			]
        );

		$this->add_control(
			'blog_number_show',
			[
				'label' => esc_html__( 'Blog Number Show?', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'artraz' ),
				'label_off' => esc_html__( 'Hide', 'artraz' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//---------------------------------------

        /*-----------------------------------------title styling------------------------------------*/
        $this->start_controls_section(
			'blog_title_styling',
			[
				'label' 	=> __( 'Title Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'blog_title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-title a'	=> 'color: {{VALUE}}!important;',
				]
			]
        );

        $this->add_control(
			'blog_title_hvr_color',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-title a:hover'	=> 'color: {{VALUE}}!important;',
				]
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'blog_title_typography',
		 		'label' 		=> esc_html__( 'Typography', 'artraz' ),
		 		'selector' 		=> '{{WRAPPER}} .blog-title a',
		 	]
		);

        $this->add_responsive_control(
			'blog_title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .blog-title a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'blog_title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .blog-title a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();

        /*-----------------------------------------content styling------------------------------------*/
        $this->start_controls_section(
			'blog_content_styling',
			[
				'label' 	=> __( 'Content Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_control(
			'blog_content_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-text'	=> 'color: {{VALUE}}!important;',
				]
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'blog_content_typography',
		 		'label' 		=> esc_html__( 'Typography', 'artraz' ),
		 		'selector' 		=> '{{WRAPPER}} .blog-text',
		 	]
		);

        $this->add_responsive_control(
			'blog_content_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .blog-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'blog_content_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .blog-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();

        /*-----------------------------------------meta styling------------------------------------*/
		$this->start_controls_section(
			'meta_style',
			[
				'label' 	=> __( 'Meta Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'meta_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-meta a' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_hvr_color',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .blog-meta a:hover' => 'color: {{VALUE}}',
				],
			]
		);	

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'meta_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
				'selector' 	=> '{{WRAPPER}} .blog-meta a',
			]
		);			

		$this->end_controls_section();

		/*-----------------------------------------Button styling------------------------------------*/
		$this->start_controls_section(
			'button_style',
			[
				'label' 	=> __( 'Button Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .link-btn' => '--theme-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'button_hvr_color',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .link-btn:hover' => '--title-color: {{VALUE}}',
				],
			]
		);	

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
				'selector' 	=> '{{WRAPPER}} .link-btn',
			]
		);	


		$this->end_controls_section();

    }

    public function artraz_get_categories() {
        $cats = get_terms(array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        ));

        $catarr = [];

        foreach( $cats as $singlecat ) {
            $catarr[$singlecat->term_id] = __($singlecat->name,'artraz');
        }

        return $catarr;
    }

    public function artraz_get_tags() {
        $cats = get_terms(array(
            'taxonomy' => 'post_tag',
            'hide_empty' => true,
        ));

        $catarr = [];

        foreach( $cats as $singlecat ) {
            $catarr[$singlecat->term_id] = __($singlecat->name,'artraz');
        }

        return $catarr;
    }

    // Get Specific Post
    public function artraz_post_id(){
        $args = array(
            'post_type'         => 'post',
            'posts_per_page'    => -1,
        );

        $artraz_post = new WP_Query( $args );

        $postarray = [];

        while( $artraz_post->have_posts() ){
            $artraz_post->the_post();
            $postarray[get_the_Id()] = get_the_title();
        }
        wp_reset_postdata();
        return $postarray;
    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        $exclude_post = $settings['exclude_post_id'];

        if( !empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats']
            );
        } elseif( !empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'tag__not_in'           => $settings['exclude_tags']
            );
        }elseif( !empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'tag__not_in'           => $settings['exclude_tags'],
                'post__not_in'          => $exclude_post
            );
        } elseif( !empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'category__not_in'      => $settings['exclude_cats'],
                'post__not_in'          => $exclude_post
            );
        } elseif( empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'tag__not_in'           => $settings['exclude_tags'],
                'post__not_in'          => $exclude_post
            );
        } elseif( empty( $settings['exclude_cats'] ) && !empty( $settings['exclude_tags'] ) && empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'tag__not_in'           => $settings['exclude_tags'],
            );
        } elseif( empty( $settings['exclude_cats'] ) && empty( $settings['exclude_tags'] ) && !empty( $settings['exclude_post_id'] ) ) {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true,
                'post__not_in'          => $exclude_post
            );
        } else {
            $args = array(
                'post_type'             => 'post',
                'posts_per_page'        => esc_attr( $settings['blog_post_count'] ),
                'order'                 => esc_attr( $settings['blog_post_order'] ),
                'orderby'               => esc_attr( $settings['blog_post_order_by'] ),
                'ignore_sticky_posts'   => true
            );
        }


    $blogpost = new WP_Query( $args );
?>
	<?php if( $settings['layout_style'] == '2' ): ?>
		<div class="blog-card-wrap">
			<?php  
				$x = 0;
				while( $blogpost->have_posts() ): 
				$blogpost->the_post(); 
				$categories = get_the_category();
				$x++;
			?>
			<div class="blog-card">
				<div class="blog-img">
					<?php the_post_thumbnail( 'artraz_352X513' ); ?>
				</div>
				<?php if( ! empty( $settings['blog_number_show'])): ?>
					<span class="blog-count h2"><?php echo esc_html__('0', 'artraz').$x; ?></span>
				<?php endif; ?>
				<h4 class="blog-title box-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ); ?></a></h4>
				<div class="blog-meta style2">
					<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
					<a href="<?php echo esc_url( artraz_blog_date_permalink() ); ?>"><?php echo esc_html( get_the_date( 'M d, Y' ) ) ?></a>
				</div>
				<p class="blog-text"><?php echo esc_html( wp_trim_words( get_the_content( ), $settings['excerpt_count'], '' ) ) ?></p>
				<?php  if(!empty($settings['read_more'])): ?>
					<a href="<?php echo esc_url( get_permalink() ); ?>" class="link-btn"><?php echo esc_html($settings['read_more']); ?></a>
				<?php endif; ?>
			</div>
			<?php endwhile; wp_reset_postdata();  ?>
		</div>

	<?php elseif( $settings['layout_style'] == '3' ): ?>
		<div class="row th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2" data-sm-slide-show="1">
			<?php  
				$x = 0;
				while( $blogpost->have_posts() ): 
				$blogpost->the_post(); 
				$categories = get_the_category();
				$x++;
			?>
			<div class="col-md-6 col-lg-4">
				<div class="blog-box">
					<div class="blog-content">
						<?php if( ! empty( $settings['blog_number_show'])): ?>
							<span class="blog-count h2"><?php echo esc_html__('0', 'artraz').$x; ?></span>
						<?php endif; ?>
						<h4 class="blog-title box-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ); ?></a></h4>
						<div class="blog-meta style2">
							<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
							<a href="<?php echo esc_url( artraz_blog_date_permalink() ); ?>"><?php echo esc_html( get_the_date( 'M d, Y' ) ) ?></a>
						</div>
						<p class="blog-text"><?php echo esc_html( wp_trim_words( get_the_content( ), $settings['excerpt_count'], '' ) ) ?></p>
						<?php  if(!empty($settings['read_more'])): ?>
							<a href="<?php echo esc_url( get_permalink() ); ?>" class="link-btn"><?php echo esc_html($settings['read_more']); ?></a>
						<?php endif; ?>
					</div>
					<div class="blog-img">
						<?php the_post_thumbnail( 'artraz_312X133' ); ?>
					</div>
				</div>
			</div>
			<?php endwhile; wp_reset_postdata();  ?>
		</div>
	<?php elseif( $settings['layout_style'] == '4' ): ?>
		<div class="row th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2" data-sm-slide-show="1">
			<?php  
				$x = 0;
				while( $blogpost->have_posts() ): 
				$blogpost->the_post(); 
				$categories = get_the_category();
				$x++;
			?>
                
            <div class="col-md-6 col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                <div class="blog-block">
                    <div class="blog-content">
                        <div class="blog-meta style2">
                            <a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
                            <a href="<?php echo esc_url( artraz_blog_date_permalink() ); ?>"><?php echo esc_html( get_the_date( 'M d, Y' ) ) ?></a>
                        </div>
                        <h3 class="blog-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ); ?></a></h3>
                        <div class="blog-img">
                            <?php the_post_thumbnail( 'artraz_450X270' ); ?>
                        </div>
                        <?php  if(!empty($settings['read_more'])): ?>
							<a href="<?php echo esc_url( get_permalink() ); ?>" class="link-btn"><?php echo esc_html($settings['read_more']); ?></a>
						<?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata();  ?>
            

        </div>
	<?php else: ?>
		<div class="row th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2" data-sm-slide-show="1">
			<?php  
				$x = 0;
				while( $blogpost->have_posts() ): 
				$blogpost->the_post(); 
				$categories = get_the_category();
				$x++;
			?>
			<div class="col-md-6 col-lg-4">
				<div class="blog-grid">
					<div class="blog-img">
						<?php the_post_thumbnail( 'artraz_352X188' ); ?>
					</div>
					<div class="blog-content">
						<h4 class="blog-title box-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( wp_trim_words( get_the_title( ), $settings['title_count'], '' ) ); ?></a></h4>
						<div class="blog-meta style2">
							<a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>"><?php echo esc_html( $categories[0]->name ); ?></a>
							<a href="<?php echo esc_url( artraz_blog_date_permalink() ); ?>"><?php echo esc_html( get_the_date( 'M d, Y' ) ) ?></a>
						</div>
						<p class="blog-text"><?php echo esc_html( wp_trim_words( get_the_content( ), $settings['excerpt_count'], '' ) ) ?></p>
						<?php  if(!empty($settings['read_more'])): ?>
							<a href="<?php echo esc_url( get_permalink() ); ?>" class="link-btn"><?php echo esc_html($settings['read_more']); ?></a>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php endwhile; wp_reset_postdata();  ?>
		</div>
        
	<?php endif; 
      
	}
}