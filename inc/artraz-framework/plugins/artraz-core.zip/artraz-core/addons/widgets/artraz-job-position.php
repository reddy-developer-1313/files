<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Job Position Widget .
 *
 */
class Artraz_job_Position extends Widget_Base {

	public function get_name() {
		return 'artrazjobposition';
	}

	public function get_title() {
		return __( 'Job positions', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		 $this->start_controls_section(
			'job_position_section',
			[
				'label'     => __( 'Job Positions', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
				],
			]
		);

		$repeater = new Repeater();

        $repeater->add_control(
			'job_number_show',
			[
				'label' => esc_html__( 'Job Number Show?', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'artraz' ),
				'label_off' => esc_html__( 'Hide', 'artraz' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $repeater->add_control(
			'job_title',
            [
				'label'         => __( 'Job Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Senior Engineer' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'job_position',
            [
				'label'         => __( 'Job Position', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Civil engineer' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'job_time',
            [
				'label'         => __( 'Job Time', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Full-time' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'job_link',
			[
				'label' 		=> __( 'Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'job_position_list',
			[
				'label' 		=> __( 'Job Position Lists', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'job_post'	=> __( 'Senior Engineer', 'artraz' ),
					],
				],
			]
		);
		
        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		/*-----------------------------------------Title styling------------------------------------*/
		$this->start_controls_section(
			'job_position_title_style',
			[
				'label' 	=> __( 'Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_title'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'title_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .job-list_title',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();

		/*-----------------------------------------Position styling------------------------------------*/
		$this->start_controls_section(
			'job_position_desc_style',
			[
				'label' 	=> __( 'Position Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_post'	=> 'color: {{VALUE}}!important;',
				],
			]
        );					
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'desc_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .job-list_post',
			]
		);

        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_post' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job position-card_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();

        /*-----------------------------------------Time styling------------------------------------*/
		$this->start_controls_section(
			'job_position_time_style',
			[
				'label' 	=> __( 'Time Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'time_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_time'	=> 'color: {{VALUE}}!important;',
				],
			]
        );					
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'time_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .job-list_time',
			]
		);

        $this->add_responsive_control(
			'time_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_time' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'time_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .job-list_time' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <?php if( $settings['layout_style'] == '2' ): ?>

    	<?php else: ?>
        <!-- <div class="row gy-40"> -->
            <?php 
                $num = 0;
                foreach( $settings['job_position_list'] as $data ):  
                $num = $num + 1;
            ?>
            <div class="job-list">
                <h3 class="job-list_title">
                    <?php if( ! empty( $data['job_number_show'])): ?>
                        <span class="job-list_num"><?php echo esc_html__('0', 'artraz').$num; ?></span>
                    <?php endif; ?>
                    <a href="<?php echo esc_url( $data['job_link']['url'] ); ?>"><?php echo esc_html( $data['job_title'] ); ?></a></h3>
                <span class="job-list_post"><?php echo esc_html( $data['job_position'] ); ?></span>
                <span class="job-list_time"><?php echo esc_html( $data['job_time'] ); ?></span>
                <a class="job-list_btn" href="<?php echo esc_url( $data['job_link']['url'] ); ?>"><i class="fa-regular fa-up-right-from-square"></i></a>
            </div>

            <?php endforeach; ?>
        <!-- </div> -->

      <?php endif; 

	}

}