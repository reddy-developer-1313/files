<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Menu Select Widget .
 *
 */
class Artraz_Menu extends Widget_Base {

	public function get_name() {
		return 'artrazmenuselect';
	}
	public function get_title() {
		return __( 'Menu Select', 'artraz' );
	}
	public function get_icon() {
		return 'th-icon';
    }
	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Navigation Menu', 'artraz' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Layout Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Normal Menu', 'artraz' ),
					'2' 		=> __( 'Footer menu', 'artraz' ),
				],
			]
		);

        $this->add_control(
			'title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2',
                'condition' => [
					'layout_style' => ['2']
				]
			]
		);


		$menus = $this->artraz_menu_select();

		if( !empty( $menus ) ){
	        $this->add_control(
				'artraz_menu_select',
				[
					'label'     	=> __( 'Select artraz Menu', 'artraz' ),
					'type'      	=> Controls_Manager::SELECT,
					'options'   	=> $menus,
					'description' 	=> sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'artraz' ), admin_url( 'nav-menus.php' ) ),
				]
			);
		}else {
			$this->add_control(
				'no_menu',
				[
					'type' 				=> Controls_Manager::RAW_HTML,
					'raw' 				=> '<strong>' . __( 'There are no menus in your site.', 'artraz' ) . '</strong><br>' . sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to create one.', 'artraz' ), admin_url( 'nav-menus.php?action=edit&menu=0' ) ),
					'separator' 		=> 'after',
					'content_classes' 	=> 'elementor-panel-alert elementor-panel-alert-info',
				]
			);
		}

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------


	}

    public function artraz_menu_select(){ 
	    $artraz_menu = wp_get_nav_menus();
	    $menu_array  = array();
		$menu_array[''] = __( 'Select A Menu', 'artraz' );
	    foreach( $artraz_menu as $menu ){
	        $menu_array[ $menu->slug ] = $menu->name;
	    }
	    return $menu_array;
	}

	protected function render() {

	$settings = $this->get_settings_for_display();

        //Menu by menu select
        $artraz_avaiable_menu   = $this->artraz_menu_select();

        if( ! $artraz_avaiable_menu ){
            return;
        }
        $args = [
            'menu' 		=> $settings['artraz_menu_select'],
            'menu_class' 	=> 'artraz-menu',
            'container' 	=> '',
        ];

        if( $settings['layout_style'] == '2' ){
            if( !empty($settings['title']) ){
                echo '<h3 class="widget_title">'.esc_html($settings['title']).'</h3>';
            }
            echo '<div class="menu-all-pages-container">';
                echo '<div class="list-two-column">';
                    if( ! empty( $settings['artraz_menu_select'] ) ){
                        wp_nav_menu( $args );
                    } 
                echo '</div>';
            echo '</div>';
            
        }else{
            if( ! empty( $settings['artraz_menu_select'] ) ){
                wp_nav_menu( $args );
            } 
        }
        


	}

}