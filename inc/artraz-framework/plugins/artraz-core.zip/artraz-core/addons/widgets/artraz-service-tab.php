<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Service Tab Widget.
 *
 */
class Artraz_Service_Tab extends Widget_Base {

	public function get_name() {
		return 'artrazservicetab';
	}

	public function get_title() {
		return __( 'Service Tab', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		 $this->start_controls_section(
			'service_section',
			[
				'label'     => __( 'Services', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		$repeater = new Repeater();

		$repeater->add_control(
			'service_number_show',
			[
				'label' => esc_html__( 'Service Number Show?', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'artraz' ),
				'label_off' => esc_html__( 'Hide', 'artraz' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $repeater->add_control(
			'tab_title',
            [
				'label'         => __( 'Tab Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Tab title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

		$repeater->add_control(
			'service_icon',
			[
				'label'     => __( 'Icon', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'service_image',
			[
				'label'     => __( 'Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'service_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'service_content',
            [
				'label'         => __( 'Content', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4'
			]
		);

        $repeater->add_control(
			'button_text',
			[
				'label' 	=> esc_html__( 'Button Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> esc_html__( 'Read More', 'artraz' ),
				'separator' => 'before'
			]
        );

        $repeater->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'servicelist',
			[
				'label' 		=> __( 'Service List', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'service_title' 		=> __( 'Find Your Wedding Vendors', 'artraz' ),
					],
					[
						'service_title' 		=> __( 'Organize Your Guest List', 'artraz' ),
					],
				],
			]
		);

        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

        /*-----------------------------------------Tab title styling------------------------------------*/
		$this->start_controls_section(
			'tab_title_style',
			[
				'label' 	=> __( 'Tab Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'tab_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-list_title'	=> 'color: {{VALUE}}!important;',
				],
			]
        );
		$this->add_control(
			'tab_active_color',
			[
				'label' 		=> __( 'Active Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .slick-current .service-list_title'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'tab_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .service-list_title',
			]
		);

        $this->add_responsive_control(
			'tab_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-list_title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'tab_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-list_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

		/*-----------------------------------------Title styling------------------------------------*/
		$this->start_controls_section(
			'service_title_style',
			[
				'label' 	=> __( 'Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'title_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .service-card_title',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

		/*-----------------------------------------Content styling------------------------------------*/

		$this->start_controls_section(
			'service_desc_style',
			[
				'label' 	=> __( 'Content Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text'	=> 'color: {{VALUE}}!important;',
				],
			]
        );					
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'desc_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .service-card_text',
			]
		);

        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();

		/*-----------------------------------------Button styling------------------------------------*/

		$this->start_controls_section(
			'service_button_style',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .link-btn.e-btn'	=> '--theme-color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_control(
			'button_h_color',
			[
				'label' 		=> __( 'Hover Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .link-btn.e-btn:hover'	=> '--title-color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'button_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .link-btn.e-btn',
			]
		);

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .link-btn.e-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();

	}

	protected function render() {

    $settings = $this->get_settings_for_display();
    ?>
        <div class="service-grid-area">
            <div class="service-list-slide">
                <button data-slick-prev="#sr-list" class="slick-btn top"><i class="fal fa-chevron-up"></i></button>
                <div class="th-carousel" id="sr-list" data-slide-show="4" data-lg-slide-show="4" data-md-slide-show="4" data-sm-slide-show="4" data-xs-slide-show="4" data-vertical="true" data-verticalSwiping="true" data-asnavfor="#sr-grid, #sr-img">
                    <?php foreach( $settings['servicelist'] as $key => $data ):  
                        $num = $key + 1;
                    ?>
                    <div>
                        <div class="service-list">
                            <?php if( ! empty( $data['service_number_show'])): ?>
                                <span class="service-list_number"><?php echo esc_html__('0', 'artraz').$num; ?></span>
                            <?php endif; ?>
                            <h4 class="service-list_title"><?php echo esc_html( $data['tab_title'] );  ?></h4>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button data-slick-next="#sr-list" class="slick-btn bottom"><i class="fal fa-chevron-down"></i></button>
            </div>
            <div class="service-grid-slide">
                <div class="th-carousel" id="sr-grid" data-slide-show="1" data-md-slide-show="1" data-asnavfor="#sr-list, #sr-img">
                    <?php foreach( $settings['servicelist'] as $key => $data ):  
                        $num = $key + 1;
                    ?>
                    <div>
                        <div class="service-card style2">
                            <div class="service-card_icon">
                                <?php echo artraz_img_tag( array(
									'url'   => esc_url( $data['service_icon']['url']  ),
									'class' => 'svg-img',
								)); ?>
                            </div>
                            <?php if( ! empty( $data['service_number_show'])): ?>
                                <p class="service-card_num text-transparent"><?php echo esc_html__('0', 'artraz').$num; ?></p>
                            <?php endif; ?>
                            <h3 class="service-card_title"><?php echo esc_html( $data['service_title'] ); ?></h3>
                            <p class="service-card_text"><?php echo esc_html( $data['service_content'] ); ?></p>
                            <?php if( ! empty( $data['button_text'])): ?>
                                <a href="<?php echo esc_url( $data['button_link']['url'] ); ?>" class="link-btn e-btn"><?php echo esc_html( $data['button_text'] );  ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="service-grid-img">
                <div class="th-carousel" id="sr-img" data-slide-show="1" data-md-slide-show="1" data-asnavfor="#sr-grid, #sr-list">
                    <?php foreach( $settings['servicelist'] as $data ):  ?>
                    <div>
                        <div class="img">
                            <?php echo artraz_img_tag( array(
									'url'   => esc_url( $data['service_image']['url']  ),
								)); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php

	}

}