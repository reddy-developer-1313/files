<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Projects Widget .
 *
 */
class Artraz_Projects extends Widget_Base {

	public function get_name() {
		return 'artrazprojects';
	}

	public function get_title() {
		return __( 'Projects', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'arrow_section',
			[
				'label'     => __( 'Projects', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
					'4' 		=> __( 'Style Four', 'artraz' ),
                    '5'         => __( 'Style Five', 'artraz' ),
					'6' 		=> __( 'Style Six', 'artraz' ),
				],
			]
		);

        $this->add_control(
			'arrow_id', [
				'label' 		=> __( 'Arrow ID', 'artraz' ),
				'type' 			=> Controls_Manager::TEXTAREA,
				'default' 		=> __( 'teamSlide1' , 'artraz' ),
				'rows' 			=> 2,
				'label_block' 	=> true,
                'condition' => [
					'layout_style' => ['3', '5']
				]
			]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'project_img',
            [
                'label'     => __( 'Image', 'artraz' ),
                'type'      => Controls_Manager::MEDIA,
                'dynamic'   => [
                    'active' => true,
                ],
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'project_title',
            [
                'label'         => __( 'Title', 'artraz' ),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => __( 'Title' , 'artraz' ),
                'label_block'   => true,
                'rows' => '2'
            ]
        );

        $repeater->add_control(
            'project_link',
            [
                'label'         => esc_html__( 'Project Link', 'artraz' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => esc_html__( 'https://your-link.com', 'artraz' ),
                'show_external' => true,
                'default'       => [
                    'url'           => '#',
                    'is_external'   => false,
                    'nofollow'      => false,
                ],
            ]
        );

        $repeater->add_control(
            'project_content',
            [
                'label'         => __( 'Content', 'artraz' ),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => __( 'Content' , 'artraz' ),
                'label_block'   => true,
                'rows' => '4'
            ]
        );

        $repeater->add_control(
            'project_number_show',
            [
                'label' => esc_html__( 'Number Show?', 'artraz' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'artraz' ),
                'label_off' => esc_html__( 'Hide', 'artraz' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'project_list',
            [
                'label'         => __( 'project List', 'artraz' ),
                'type'          => Controls_Manager::REPEATER,
                'fields'        => $repeater->get_controls(),
                'default'       => [
                    [
                        'project_title'         => __( 'CLASSIC HOTEL PROJECT', 'artraz' ),
                    ],
                ],
                'condition' => [
                    'layout_style' => ['1', '2', '3', '4', '5']
                ]
            ]
        );

        $repeater2 = new Repeater();

		$repeater2->add_control(
			'project_img',
			[
				'label'     => __( 'Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater2->add_control(
			'project_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater2->add_control(
            'url',
            [
                'label'         => __( 'Details Page', 'artraz' ),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => __( '#' , 'artraz' ),
                'label_block'   => true,
                'rows' => '2'
            ]
        );
        $repeater2->add_control(
			'location',
            [
                'label'         => __( 'Location', 'artraz' ),
                'type'          => Controls_Manager::TEXTAREA,
                'default'       => __( '#' , 'artraz' ),
                'label_block'   => true,
                'rows' => '2'
            ]
		);
		$this->add_control(
			'project_list2',
			[
				'label' 		=> __( 'project List', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater2->get_controls(),
				'default' 		=> [
					[
						'project_title' 		=> __( 'CLASSIC HOTEL PROJECT', 'artraz' ),
					],
				],
                'condition' => [
                    'layout_style' => ['6']
                ]
			]
		);

        $this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

        //-------------------------------------title styling-------------------------------------//
        $this->start_controls_section(
            'project_title_style_section',
            [
                'label' => __( 'Title Style', 'artraz' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'project_title_color',
            [
                'label' 	=> __( 'Color', 'artraz' ),
                'type' 		=> Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'project_title_typography',
                'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .project-title',
            ]
        );

        $this->add_responsive_control(
            'project_title_margin',
            [
                'label' 		=> __( 'Margin', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'project_title_padding',
            [
                'label' 		=> __( 'Padding', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();	

        //-------------------------------------Location styling-------------------------------------//
        $this->start_controls_section(
            'project_location_style_section',
            [
                'label' => __( 'Location Style', 'artraz' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'project_map_color',
            [
                'label' 	=> __( 'Color', 'artraz' ),
                'type' 		=> Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-map' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'project_map_typography',
                'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .project-map',
            ]
        );

        $this->add_responsive_control(
            'project_map_margin',
            [
                'label' 		=> __( 'Margin', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-map' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'project_map_padding',
            [
                'label' 		=> __( 'Padding', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-map' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();	

	}

	protected function render() {

    $settings = $this->get_settings_for_display();
    ?>
        <?php if( $settings['layout_style'] == '2' ): ?>
            <div class="row variable-width" id="projectSlide1">
                <?php foreach( $settings['project_list'] as $key => $data ):  
                    $num = $key + 1;
                ?>
                <div class="col-auto">
                    <div class="project-card">
                        <div class="project-img">
                            <?php echo artraz_img_tag( array(
                                'url'   => esc_url( $data['project_img']['url']  ),
                            )); ?>
                        </div>
                        <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['project_link']['url'] ); ?>"><?php echo esc_html( $data['project_title'] ); ?></a></h3>
                        <p class="project-map"><?php echo wp_kses_post( $data['project_content'] ); ?></p>
                        <?php if( ! empty( $data['project_number_show'])): ?>
                            <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="slider-nav-wrap">
                <div class="slider-nav">
                    <button data-slick-prev="#projectSlide1" class="nav-btn"><i class="fal fa-long-arrow-left"></i></button>
                    <div class="custom-dots"></div>
                    <button data-slick-next="#projectSlide1" class="nav-btn"><i class="fal fa-long-arrow-right"></i></button>
                </div>
            </div>

        <?php elseif( $settings['layout_style'] == '3' ): ?>
            <div class="row project-slide2 th-carousel" data-slide-show="2" id="<?php echo esc_attr($settings['arrow_id']) ?>">
                <?php foreach( $settings['project_list'] as $key => $data ):  
                    $num = $key + 1;
                ?>
                <div class="col-xxl-auto col-md-6">
                    <div class="project-box">
                        <div class="project-img">
                            <?php echo artraz_img_tag( array(
                                'url'   => esc_url( $data['project_img']['url']  ),
                            )); ?>
                        </div>
                        <div class="project-content">
                            <?php if( ! empty( $data['project_number_show'])): ?>
                                <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                            <?php endif; ?>
                            <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['project_link']['url'] ); ?>"><?php echo esc_html( $data['project_title'] ); ?></a></h3>
                            <p class="project-map"><?php echo wp_kses_post( $data['project_content'] ); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

        <?php elseif( $settings['layout_style'] == '4' ): ?>
            <div class="row gy-30">
                <?php foreach( $settings['project_list'] as $key => $data ):  
                    $num = $key + 1;
                ?>
                <div class="col-xxl-auto col-md-6">
                    <div class="project-box">
                        <div class="project-img">
                            <?php echo artraz_img_tag( array(
                                'url'   => esc_url( $data['project_img']['url']  ),
                            )); ?>
                        </div>
                        <div class="project-content">
                            <?php if( ! empty( $data['project_number_show'])): ?>
                                <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                            <?php endif; ?>
                            <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['project_link']['url'] ); ?>"><?php echo esc_html( $data['project_title'] ); ?></a></h3>
                            <p class="project-map"><?php echo wp_kses_post( $data['project_content'] ); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        
        <?php elseif( $settings['layout_style'] == '5' ): ?>
            <div class="row project-slide2 th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2" id="<?php echo esc_attr($settings['arrow_id']) ?>">
                <?php foreach( $settings['project_list'] as $key => $data ):  
                    $num = $key + 1;
                ?>
                <div class="col-xxl-auto col-md-6">
                    <div class="project-box">
                        <div class="project-img">
                            <?php echo artraz_img_tag( array(
                                'url'   => esc_url( $data['project_img']['url']  ),
                            )); ?>
                        </div>
                        <div class="project-content">
                            <?php if( ! empty( $data['project_number_show'])): ?>
                                <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                            <?php endif; ?>
                            <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['project_link']['url'] ); ?>"><?php echo esc_html( $data['project_title'] ); ?></a></h3>
                            <p class="project-map"><?php echo wp_kses_post( $data['project_content'] ); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

        <?php 
            elseif( $settings['layout_style'] == '6' ):
                echo '<div class="row project-slide6 th-carousel" data-slide-show="3" data-lg-slide-show="2" data-md-slide-show="2">';
                    $x = 0;
                    foreach( $settings['project_list2'] as  $data ){ 
                        $x++;
                        $k = str_pad($x, 2, '0', STR_PAD_LEFT);

                        echo '<div class="col-xxl-auto col-md-6">';
                            echo '<div class="project-box style2">';
                                echo '<div class="project-img">';
                                    echo artraz_img_tag( array(
                                        'url'   => esc_url( $data['project_img']['url']  ),
                                    ));
                                echo '</div>';
                                echo '<div class="project-content">';
                                    echo '<div class="project-number">'.esc_html( $k ).'</div>';
                                    echo '<h3 class="h5 project-title"><a href="'.esc_url( $data['url'] ).'">'.esc_html( $data['project_title'] ).'</a></h3>';
                                    echo '<p class="project-map"><i class="fal fa-location-dot"></i>'.esc_html( $data['location'] ).'</p>';
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    }
                    
                echo '</div>';
            
        else: ?>
            <div class="container th-container3">
                <div class="project-slide-wrap">
                    <div class="row" id="projectSlide3">
                        <?php foreach( $settings['project_list'] as $key => $data ):  
                            $num = $key + 1;
                        ?>
                        <div class="col-lg-6">
                            <div class="project-card">
                                <div class="project-img">
                                    <?php echo artraz_img_tag( array(
                                        'url'   => esc_url( $data['project_img']['url']  ),
                                    )); ?>
                                </div>
                                <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['project_link']['url'] ); ?>"><?php echo esc_html( $data['project_title'] ); ?></a></h3>
                                <p class="project-map"><?php echo wp_kses_post( $data['project_content'] ); ?></p>
                                <?php if( ! empty( $data['project_number_show'])): ?>
                                    <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="slider-nav-wrap">
                        <div class="slider-nav">
                            <button data-slick-prev="#projectSlide3" class="nav-btn"><i class="fal fa-long-arrow-left"></i></button>
                            <div class="custom-dots"></div>
                            <button data-slick-next="#projectSlide3" class="nav-btn"><i class="fal fa-long-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
            </div>

        <?php endif;
			
	}
}