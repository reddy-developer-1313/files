<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Repeater;
use \Elementor\Utils;
use \Elementor\Group_Control_Border;
/**
 *
 * Gallery Widget .
 *
 */
class Artraz_Gallery extends Widget_Base {

	public function get_name() {
		return 'artrazgallery';
	}

	public function get_title() {
		return __( 'Gallery', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'counter_section',
			[
				'label' 	=> __( 'Gallery', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_CONTENT,
			]
        ); 

        $this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Layout Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'artraz' ),
				],
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'gallery_number_show',
			[
				'label' => esc_html__( 'gallery Number Show?', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'artraz' ),
				'label_off' => esc_html__( 'Hide', 'artraz' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'gallery_img',
			[
				'label'     => __( 'Image', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'gallery_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'gallery_link',
			[
				'label' 		=> esc_html__( 'Gallery Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

        $repeater->add_control(
			'gallery_content',
            [
				'label'         => __( 'Content', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4'
			]
		);

		$this->add_control(
			'gallery_list',
			[
				'label' 		=> __( 'Gallery List', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'gallery_title' 		=> __( 'CLASSIC HOTEL PROJECT', 'artraz' ),
					],
				],
			]
		);

		$this->end_controls_section();

		//---------------------------------------
			//Style Section Start
		//---------------------------------------

        //-------------------------------------title styling-------------------------------------//
        $this->start_controls_section(
            'project_title_style_section',
            [
                'label' => __( 'Title Style', 'artraz' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'project_title_color',
            [
                'label' 	=> __( 'Color', 'artraz' ),
                'type' 		=> Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'project_title_typography',
                'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .project-title',
            ]
        );

        $this->add_responsive_control(
            'project_title_margin',
            [
                'label' 		=> __( 'Margin', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'project_title_padding',
            [
                'label' 		=> __( 'Padding', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();	

        //-------------------------------------Location styling-------------------------------------//
        $this->start_controls_section(
            'project_location_style_section',
            [
                'label' => __( 'Location Style', 'artraz' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'project_map_color',
            [
                'label' 	=> __( 'Color', 'artraz' ),
                'type' 		=> Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-map' => 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' 		=> 'project_map_typography',
                'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .project-map',
            ]
        );

        $this->add_responsive_control(
            'project_map_margin',
            [
                'label' 		=> __( 'Margin', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-map' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'project_map_padding',
            [
                'label' 		=> __( 'Padding', 'artraz' ),
                'type' 			=> Controls_Manager::DIMENSIONS,
                'size_units' 	=> [ 'px', '%', 'em' ],
                'selectors' 	=> [
                    '{{WRAPPER}} .project-map' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();	


	}

	protected function render() {

        $settings = $this->get_settings_for_display();
		 ?>
		 <?php if( $settings['layout_style'] == '2' ): ?>


		 <?php else: ?>
            <div class="row gy-30">
                <?php foreach( $settings['gallery_list'] as $key => $data ):  
                    $num = $key + 1;
                ?>
                <div class="col-xl-4 col-md-6">
                    <div class="gallery-box">
                        <div class="project-img">
                            <?php echo artraz_img_tag( array(
                                'url'   => esc_url( $data['gallery_img']['url']  ),
                            )); ?>
                        </div>
                        <div class="gallery-content">
                            <?php if( ! empty( $data['gallery_number_show'])): ?>
                                <div class="project-number"><?php echo esc_html__('0', 'artraz').$num; ?></div>
                            <?php endif; ?>
                            <h3 class="h5 project-title"><a href="<?php echo esc_url( $data['gallery_link']['url'] ); ?>"><?php echo esc_html( $data['gallery_title'] ); ?></a></h3>
                            <p class="project-map"><?php echo wp_kses_post( $data['gallery_content'] ); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

    	<?php
    	endif;
	}

}