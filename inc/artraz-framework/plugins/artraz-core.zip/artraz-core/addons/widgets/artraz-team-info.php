<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Repeater;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Image_Size;
/**
 *
 * Team Info Widget
 *
 */
class Artraz_Team_info extends Widget_Base{

	public function get_name() {
		return 'artrazteaminfo';
	}

	public function get_title() {
		return esc_html__( 'Team Member Info', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	public function get_script_depends() {
		return [ 'artraz-frontend-script' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'team_member_content',
			[
				'label'		=> esc_html__( 'Member Informmation','artraz' ),
				'tab'		=> Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Member Info Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options'		=> [
					'1'  			=> __( 'Style One', 'artraz' ),
					// '2' 			=> __( 'Style Two', 'artraz' ),
				],
			]
		);	

		$this->add_control(
			'content_name',
			[
				'label' 	=> esc_html__( 'Name', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> esc_html__( 'Angela Kwang', 'artraz' ),
                'rows' => '2'
			]
        );

        $this->add_control(
			'content_desig',
			[
				'label' 	=> esc_html__( 'Team Member Designation', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> esc_html__( 'Teacher', 'artraz' ),
                'rows' => '2'
			]
        ); 

        $this->add_control(
			'description',
			[
				'label' 	=> esc_html__( 'Description Text', 'artraz' ),
                'type' 		=> Controls_Manager::WYSIWYG,
                'default'  	=> esc_html__( 'Synergistically procrastinate technology without inexpensive partnerships. Credibly synergize long-term high-impact infomediaries before covalent solution. ', 'artraz' ),
			]
        );  

        $this->add_control(
			'feature_content',
			[
				'label' 	=> esc_html__( 'Feature Content', 'artraz' ),
                'type' 		=> Controls_Manager::WYSIWYG,
                'default'  	=> esc_html__( '', 'artraz' ),
                'rows' => 3,
			]
        );
 
       $this->add_control(
			'social_label',
			[
				'label' 	=> esc_html__( 'Social Label', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'default'  	=> esc_html__( '', 'artraz' ),
                'label_block' => 'true',
                 'condition' => [
                	'layout_style' => ['1']
                ]
			]
        );

        $this->add_control(
			'fb_link',
			[
				'label' 		=> esc_html__( 'Facebook Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'skype_link',
			[
				'label' 		=> esc_html__( 'Skype Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'twitter_link',
			[
				'label' 		=> esc_html__( 'Twitter Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);

		$this->add_control(
			'pinterest_link',
			[
				'label' 		=> esc_html__( 'Pinterest Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
					
				],
			]
		);

		$this->add_control(
			'linkedin_link',
			[
				'label' 		=> esc_html__( 'Linkedin Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
					
				],
			]
		);

		 $this->add_control(
			'button_text',
			[
				'label' 	=> __( 'Button Text', 'artraz' ),
                'type' 		=> Controls_Manager::TEXT,
                'label_block' => true,
                'default'  	=> __( 'Button Text', 'artraz' ),
                  'condition' => [
                	'layout_style' => ['1']
                ]
			]
        );

        $this->add_control(
			'button_link',
			[
				'label' 		=> __( 'Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> __( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
				  'condition' => [
                	'layout_style' => ['1']
                ]
			]
		);

		$this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		/*-----------------------------------------Feedback styling------------------------------------*/

		$this->start_controls_section(
			'overview_con_styling',
			[
				'label' 	=> __( 'Content Styling', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

	        $this->start_controls_tabs(
				'style_tabs2'
			);


				$this->start_controls_tab(
					'style_normal_tab2',
					[
						'label' => esc_html__( 'Name', 'artraz' ),
					]
				);

			    $this->add_control(
						'overview_title_color',
						[
							'label' 		=> __( 'Color', 'artraz' ),
							'type' 			=> Controls_Manager::COLOR,
							'selectors' 	=> [
								'{{WRAPPER}} .team-about_title'	=> 'color: {{VALUE}}!important;',
							],
						]
			    );

			    $this->add_group_control(
					Group_Control_Typography::get_type(),
					 	[
							'name' 			=> 'overview_title_typography',
					 		'label' 		=> __( 'Typography', 'artraz' ),
					 		'selector' 	=> '{{WRAPPER}} .team-about_title',
						]
					);

			    $this->add_responsive_control(
						'overview_title_margin',
						[
							'label' 		=> __( 'Margin', 'artraz' ),
							'type' 			=> Controls_Manager::DIMENSIONS,
							'size_units' 	=> [ 'px', '%', 'em' ],
							'selectors' 	=> [
								'{{WRAPPER}} .team-about_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			                ],
						]
			    );

			    $this->add_responsive_control(
						'overview_title_padding',
						[
							'label' 		=> __( 'Padding', 'artraz' ),
							'type' 			=> Controls_Manager::DIMENSIONS,
							'size_units' 	=> [ 'px', '%', 'em' ],
							'selectors' 	=> [
								'{{WRAPPER}} .team-about_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			                ],
						]
			    );

				$this->end_controls_tab();

				//--------------------secound--------------------//

				$this->start_controls_tab(
					'style_hover_tab2',
					[
						'label' => esc_html__( 'Designation', 'artraz' ),
					]
				);

				$this->add_control(
					'overview_content_color',
					[
						'label' 		=> __( 'Color', 'artraz' ),
						'type' 			=> Controls_Manager::COLOR,
						'selectors' 	=> [
							'{{WRAPPER}} .team-about_desig'	=> 'color: {{VALUE}}!important;',
						],
					]
		        );

			    $this->add_group_control(
					Group_Control_Typography::get_type(),
					 	[
							'name' 			=> 'overview_content_typography',
					 		'label' 		=> __( 'Typography', 'artraz' ),
					 		'selector' 	=> '{{WRAPPER}} .team-about_desig',
						]
					);

			    $this->add_responsive_control(
						'overview_content_margin',
						[
							'label' 		=> __( 'Margin', 'artraz' ),
							'type' 			=> Controls_Manager::DIMENSIONS,
							'size_units' 	=> [ 'px', '%', 'em' ],
							'selectors' 	=> [
								'{{WRAPPER}} .team-about_desig' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			                ],
						]
			    );

			    $this->add_responsive_control(
						'overview_content_padding',
						[
							'label' 		=> __( 'Padding', 'artraz' ),
							'type' 			=> Controls_Manager::DIMENSIONS,
							'size_units' 	=> [ 'px', '%', 'em' ],
							'selectors' 	=> [
								'{{WRAPPER}} .team-about_desig' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			                ],
						]
			   );

				$this->end_controls_tab();

				//--------------------secound--------------------//

				$this->start_controls_tab(
					'style_hover_tab5',
					[
						'label' => esc_html__( 'Content', 'artraz' ),
					]
				);
				$this->add_control(
					'co_content_color',
					[
						'label' 		=> __( 'Color', 'artraz' ),
						'type' 			=> Controls_Manager::COLOR,
						'selectors' 	=> [
							'{{WRAPPER}} p'	=> 'color: {{VALUE}}!important;',
						],
					]
		        );
		        $this->add_group_control(
				Group_Control_Typography::get_type(),
				 	[
						'name' 			=> 'co_content_typography',
				 		'label' 		=> __( 'Typography', 'artraz' ),
				 		'selector' 	=> '{{WRAPPER}} p',
					]
				);

		        $this->add_responsive_control(
					'co_content_margin',
					[
						'label' 		=> __( 'Margin', 'artraz' ),
						'type' 			=> Controls_Manager::DIMENSIONS,
						'size_units' 	=> [ 'px', '%', 'em' ],
						'selectors' 	=> [
							'{{WRAPPER}} p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		                ],
					]
		        );

		        $this->add_responsive_control(
					'co_content_padding',
					[
						'label' 		=> __( 'Padding', 'artraz' ),
						'type' 			=> Controls_Manager::DIMENSIONS,
						'size_units' 	=> [ 'px', '%', 'em' ],
						'selectors' 	=> [
							'{{WRAPPER}} p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		                ],
					]
		        );

				$this->end_controls_tab();

			$this->end_controls_tabs();

		$this->end_controls_section();


		//-------------------------------------Button styling-------------------------------------//

        $this->start_controls_section(
			'button_style_section',
			[
				'label' 	=> __( 'Button Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'button_typography',
				'label' 	=> __( 'Button Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn',
			]
        );


		$this->start_controls_tabs(
			'button_tabs'
		);


		$this->start_controls_tab(
			'normal_tab_label',
			[
				'label' => esc_html__( 'Normal', 'artraz' ),
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' 		=> __( 'Button Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn' => 'color: {{VALUE}}',
                ],
			]
        );

		$this->add_control(
			'button_bg_color',
			[
				'label' 		=> __( 'Button Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn' => 'background-color:{{VALUE}} !important',
                ],
			]
        );
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn',
			]
		);


		$this->end_controls_tab();

		$this->start_controls_tab(
			'hover_tab_label',
			[
				'label' => esc_html__( 'Hover', 'artraz' ),
			]
		);

		$this->add_control(
			'button_color_hover',
			[
				'label' 		=> __( 'Button Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn:hover' => 'color: {{VALUE}}',
                ],
			]
        );

		$this->add_control(
			'button_bg_hover_color',
			[
				'label' 		=> __( 'Button Background Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn:hover:before, {{WRAPPER}} .th-btn.btn:hover' => 'background-color:{{VALUE}} !Important',
                ],
			]
        );

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'border_hover',
				'label' 	=> __( 'Border', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .th-btn.btn:hover',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
			'button_margin',
			[
				'label' 		=> __( 'Button Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
        );

        $this->add_responsive_control(
			'button_padding',
			[
				'label' 		=> __( 'Button Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);

        $this->add_responsive_control(
			'button_border_radius',
			[
				'label' 		=> __( 'Button Border Radius', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-btn.btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'label' => esc_html__( 'Button Shadow', 'artraz' ),
				'selector' => '{{WRAPPER}} .th-btn.btn',
			]
		);

        $this->end_controls_section();
        

	}

	protected function render() {

		$settings = $this->get_settings_for_display(); 

    	?>
    	<?php if( $settings['layout_style'] == '2' ): ?>

	    <?php else: 
	    	$f_target = $settings['fb_link']['is_external'] ? ' target="_blank"' : '';
			$f_nofollow = $settings['fb_link']['nofollow'] ? ' rel="nofollow"' : '';
			$s_target = $settings['skype_link']['is_external'] ? ' target="_blank"' : '';
			$s_nofollow = $settings['skype_link']['nofollow'] ? ' rel="nofollow"' : '';
			$t_target = $settings['twitter_link']['is_external'] ? ' target="_blank"' : '';
			$t_nofollow = $settings['twitter_link']['nofollow'] ? ' rel="nofollow"' : '';
			$p_target = $settings['pinterest_link']['is_external'] ? ' target="_blank"' : '';
			$p_nofollow = $settings['pinterest_link']['nofollow'] ? ' rel="nofollow"' : '';
			$l_target = $settings['linkedin_link']['is_external'] ? ' target="_blank"' : '';
			$l_nofollow = $settings['linkedin_link']['nofollow'] ? ' rel="nofollow"' : '';
	    ?>

			<div class="team-about">
				<h2 class="h3 team-about_title"><?php echo esc_html($settings['content_name']); ?> <span class="team-about_desig"><?php echo esc_html($settings['content_desig']); ?></span></h2>
				<div class="social-box">
					<?php if(!empty($settings['social_label'])): ?>
						<p class="title"><?php echo esc_html($settings['social_label']); ?></p>
					<?php endif; ?>
					<div class="th-social">
						<?php if( ! empty( $settings['fb_link']['url']) ): ?>
							<a <?php echo wp_kses_post( $f_nofollow.$f_target ); ?> href="<?php echo esc_url( $settings['fb_link']['url'] ); ?>"><i class="fab fa-facebook-f"></i></a>
						<?php endif; ?>

						<?php if( ! empty( $settings['skype_link']['url']) ): ?>
							<a <?php echo wp_kses_post( $s_nofollow.$s_target ); ?>  href="<?php echo esc_url( $settings['skype_link']['url'] ); ?>"><i class="fab fa-skype"></i></a>
						<?php endif; ?>

						<?php if( ! empty( $settings['twitter_link']['url']) ): ?>
							<a <?php echo wp_kses_post( $t_nofollow.$t_target ); ?>  href="<?php echo esc_url( $settings['twitter_link']['url'] ); ?>"><i class="fab fa-twitter"></i></a>
						<?php endif; ?>

						<?php if( ! empty( $settings['pinterest_link']['url']) ): ?>
							<a <?php echo wp_kses_post( $p_nofollow.$p_target ); ?>  href="<?php echo esc_url( $settings['pinterest_link']['url'] ); ?>"><i class="fab fa-pinterest-p"></i></a>
						<?php endif; ?>

						<?php if( ! empty( $settings['linkedin_link']['url']) ): ?>
							<a <?php echo wp_kses_post( $l_nofollow.$l_target ); ?>  href="<?php echo esc_url( $settings['linkedin_link']['url'] ); ?>"><i class="fab fa-linkedin-in"></i></a>
						<?php endif; ?>
					</div>
				</div>
				<?php echo wp_kses_post($settings['description']); ?>
				<div class="inner-list mb-40">
					<?php echo wp_kses_post($settings['feature_content']); ?>
				</div>
				<?php if(!empty($settings['button_text'])): ?>
				<a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="th-btn btn"><span class="line left"></span> <?php echo esc_html($settings['button_text']); ?> <span class="line"></span></a>
                <?php endif; ?>
			</div>

    	<?php endif;
		
	}
}