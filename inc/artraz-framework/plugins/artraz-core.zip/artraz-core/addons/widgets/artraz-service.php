<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Service Widget .
 *
 */
class Artraz_Service extends Widget_Base {

	public function get_name() {
		return 'artrazservice';
	}

	public function get_title() {
		return __( 'Services', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'layout_section',
			[
				'label'     => __( 'Layout Style', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

		$this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Services Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2'  		=> __( 'Style Two', 'artraz' ),
					'3'  		=> __( 'Style Three', 'artraz' ),
					'4'  		=> __( 'Style Four', 'artraz' ),
				],
			]
		);

		 $this->end_controls_section();

		 $this->start_controls_section(
			'service_section',
			[
				'label'     => __( 'Services', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,

			]
        );

		 $this->add_control(
			'make_it_slider',
			[
				'label' 		=> __( 'Make It Slider?', 'artraz' ),
				'type' 			=> Controls_Manager::SWITCHER,
				'label_on' 		=> __( 'Yes', 'artraz' ),
				'label_off' 	=> __( 'No', 'artraz' ),
				'return_value' 	=> 'yes',
				'default' 		=> 'yes',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'service_number_show',
			[
				'label' => esc_html__( 'Service Number Show?', 'artraz' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'artraz' ),
				'label_off' => esc_html__( 'Hide', 'artraz' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'service_icon',
			[
				'label'     => __( 'image /Icon', 'artraz' ),
				'type'      => Controls_Manager::MEDIA,
				'dynamic'   => [
					'active' => true,
				],
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

        $repeater->add_control(
			'service_title',
            [
				'label'         => __( 'Title', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

        $repeater->add_control(
			'service_content',
            [
				'label'         => __( 'Content', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Content' , 'artraz' ),
				'label_block'   => true,
				'rows' => '4'
			]
		);
		$repeater->add_control(
			'url',
            [
				'label'         => __( 'Details Page', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( '#' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);
		$repeater->add_control(
			'btn',
            [
				'label'         => __( 'Button', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( ' Explore us ' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

		$this->add_control(
			'servicelist',
			[
				'label' 		=> __( 'Service List', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'service_title' 		=> __( 'Architecture', 'artraz' ),
					],
				],
			]
		);

		
        $this->end_controls_section();

        //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------Genearl styling-------------------------------------//

        $this->start_controls_section(
			'general_section',
			[
				'label' => __( ' General Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'general_color',
			[
				'label' 	=> __( 'Background', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-card' => 'background-color: {{VALUE}}!important;',
					'{{WRAPPER}} .service-block' => 'background-color: {{VALUE}}!important;',
                ],
			]
        );	

        $this->add_control(
			'general_b_color',
			[
				'label' 	=> __( 'Border Color', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-card' => 'border-color: {{VALUE}}!important;',
                ],
			]
        );

		$this->add_responsive_control(
			'general_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}}  .service-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

		$this->end_controls_section();

		/*-----------------------------------------Number styling------------------------------------*/
		$this->start_controls_section(
			'service_number_style',
			[
				'label' 	=> __( 'Number Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
				'condition'	=> [
					'layout_style' => ['1','2']
				]
			]
		);
		$this->add_control(
			'number_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_num'	=> 'color: {{VALUE}}!important;',
				],
			]
		);

		$this->add_group_control(
		Group_Control_Typography::get_type(),
				[
				'name' 			=> 'number_typography',
					'label' 		=> __( 'Typography', 'artraz' ),
					'selector' 	=> '{{WRAPPER}} .service-card_num',
			]
		);

		$this->add_responsive_control(
			'number_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_num ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'number_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_num' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();

		/*-----------------------------------------Title styling------------------------------------*/
		$this->start_controls_section(
			'service_title_style',
			[
				'label' 	=> __( 'Title Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title'	=> 'color: {{VALUE}}!important;',
					'{{WRAPPER}} .service-block_text'	=> 'color: {{VALUE}}!important;',
					'{{WRAPPER}} .project-text'	=> 'color: {{VALUE}}!important;',
				],
			]
        );

        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'title_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .service-card_title,{{WRAPPER}} .service-block_text,{{WRAPPER}} .project-text',
			]
		);

        $this->add_responsive_control(
			'title_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .service-block_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .project-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'title_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .service-block_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .project-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

		/*-----------------------------------------Content styling------------------------------------*/

		$this->start_controls_section(
			'service_desc_style',
			[
				'label' 	=> __( 'Content Style', 'artraz' ),
				'tab' 		=> Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'desc_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text'	=> 'color: {{VALUE}}!important;',
					'{{WRAPPER}} .service-block_title'	=> 'color: {{VALUE}}!important;',
					'{{WRAPPER}} .project-title'	=> 'color: {{VALUE}}!important;',
				],
			]
        );					
        $this->add_group_control(
		Group_Control_Typography::get_type(),
		 	[
				'name' 			=> 'desc_typography',
		 		'label' 		=> __( 'Typography', 'artraz' ),
		 		'selector' 	=> '{{WRAPPER}} .service-card_text,{{WRAPPER}} .service-block_title,{{WRAPPER}} .project-title',
			]
		);

        $this->add_responsive_control(
			'desc_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .service-block_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .project-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'desc_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .service-card_text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .service-block_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .project-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();


	}

	protected function render() {

        $settings = $this->get_settings_for_display();
        ?>

        <?php if( $settings['layout_style'] == '2' ): 

        	echo '<div class="service-box-wrap wow fadeInUp" data-wow-delay="0.2s">';
                foreach( $settings['servicelist'] as $key => $data ) {
                	$num = $key + 1;

                	$acative = $num == 2 ? 'item-active' : '';
	                echo '<div class="service-box hover-item  '.esc_attr( $acative ).'" data-bg-src="'.esc_url( $data['service_icon']['url']  ).'">';
	                    echo '<div class="service-title-wrap">';
	                    	if( ! empty( $data['service_number_show'])){
		                        echo '<p class="service-box_num">'.esc_html__('0', 'artraz').$num.'</p>';
		                    }
		                    if( ! empty( $data['service_title'])){
		                        echo '<h3 class="service-box_title"><a href="'. esc_url( $data['url'] ).'">'. esc_html( $data['service_title'] ).'</a></h3>';
		                    }
	                    echo '</div>';
	                    if( ! empty( $data['service_content'])){
		                    echo '<p class="service-box_text">'. esc_html( $data['service_content'] ).'</p>';
		                }
		                if( ! empty( $data['btn'])){
		                    echo '<a href="'. esc_url( $data['url'] ).'" class="th-btn style2"><span class="line left"></span>'. esc_html( $data['btn'] ).'<span class="line"></span></a>';
		                }
	                echo '</div>';
	            }
                

            echo '</div>';
        elseif( $settings['layout_style'] == '3' ): 
        	echo '<div class="row gy-4 justify-content-center">';

                foreach( $settings['servicelist'] as $data ) {
	                echo '<div class="col-xl-4 col-md-6 hover-item">';
	                    echo '<div class="service-block">';
	                    	if( ! empty( $data['service_title'])){
		                        echo '<p class="service-block_text">'. esc_html( $data['service_title'] ).'</p>';
		                    }
		                    if( ! empty( $data['service_content'])){
		                        echo '<h3 class="service-block_title"><a href="'. esc_url( $data['url'] ).'">'. esc_html( $data['service_content'] ).'</a></h3>';
		                    }
	                        echo '<div class="icon-wrap">';
	                            echo '<a href="'. esc_url( $data['url'] ).'" class="icon-btn"><i class="far fa-plus"></i></a>';
	                            echo '<div class="service-block_icon">';
	                                echo '<img class="svg-img" src="'.esc_url( $data['service_icon']['url']  ).'" alt="service image">';
	                            echo '</div>';
	                        echo '</div>';
	                    echo '</div>';
	                echo '</div>';
	            }
                

            echo '</div>';
        elseif( $settings['layout_style'] == '4' ): 
        	echo '<div class="project-list-wrap">';
        		$i = 0;
                foreach( $settings['servicelist'] as $data ) {
                	$i++;
                	$acative = $i == 2 ? 'item-active' : '';
	                echo '<div class="project-list hover-item  '.esc_attr( $acative ).'">';
	                    echo '<div class="project-img">';
	                        echo '<img src="'.esc_url( $data['service_icon']['url']  ).'" alt="project image">';
	                    echo '</div>';
	                    echo '<div class="project-content">';
	                    	if( ! empty( $data['service_title'])){
		                        echo '<p class="project-text">'. esc_html( $data['service_title'] ).'</p>';
		                    }
	                        echo '<h3 class="h4 project-title"><a href="'. esc_url( $data['url'] ).'">'. esc_html( $data['service_content'] ).'</a></h3>';
	                    echo '</div>';
	                    echo '<a href="'. esc_url( $data['url'] ).'" class="box-btn">';
	                        echo '<span class="icon-btn"><i class="fas fa-arrow-right"></i></span>'. esc_html( $data['btn'] ).'';
	                    echo '</a>';
	                echo '</div>';
	            }
               

            echo '</div>';

    	else: ?>
			<?php if($settings['make_it_slider'] == 'yes'): ?>
				<div class="row th-carousel" data-slide-show="3" data-md-slide-show="2">
			<?php else: ?>
				<div class="row gy-4">
			<?php endif; ?>
				<?php foreach( $settings['servicelist'] as $key => $data ):  
					$num = $key + 1;
				?>
				<div class="col-md-6 col-lg-4">
					<div class="service-card">
						<div class="service-card_icon">
							<?php echo artraz_img_tag( array(
									'url'   => esc_url( $data['service_icon']['url']  ),
									'class' => 'svg-img',
								)); ?>
						</div>
						<?php if( ! empty( $data['service_number_show'])): ?>
							<p class="service-card_num"><?php echo esc_html__('0', 'artraz').$num; ?></p>
						<?php endif; ?>
						<h3 class="service-card_title"><?php echo esc_html( $data['service_title'] ); ?></h3>
						<p class="service-card_text"><?php echo esc_html( $data['service_content'] );  ?></p>
					</div>
				</div>
				<?php endforeach; ?>
			</div>

      <?php endif; 

	}

}