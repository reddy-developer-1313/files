<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Border;
use \Elementor\Repeater;
/**
 *
 * Social Widget .
 *
 */
class Artraz_Social extends Widget_Base {

	public function get_name() {
		return 'artrazsocial';
	}

	public function get_title() {
		return __( 'Social Media', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'team_section',
			[
				'label'     => __( 'Social Content', 'artraz' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
			'layout_style',
			[
				'label' 	=> __( 'Layout Style', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'default' 	=> '1',
				'options' 	=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					// '2' 		=> __( 'Style Two', 'artraz' ),
				],
			]
		);

		$repeater = new Repeater();

        $repeater->add_control(
			'social_icon',
            [
				'label'         => __( 'Social Icon', 'artraz' ),
				'description'         => __( 'Set socail icon class with tag', 'artraz' ),
				'type'          => Controls_Manager::TEXTAREA,
				'default'       => __( 'Title' , 'artraz' ),
				'label_block'   => true,
				'rows' => '2'
			]
		);

		$repeater->add_control(
			'social_link',
			[
				'label' 		=> esc_html__( 'Social Link', 'artraz' ),
				'type' 			=> Controls_Manager::URL,
				'placeholder' 	=> esc_html__( 'https://your-link.com', 'artraz' ),
				'show_external' => true,
				'default' 		=> [
					'url' 			=> '#',
					'is_external' 	=> false,
					'nofollow' 		=> false,
				],
			]
		);
		
		$this->add_control(
			'social_lists',
			[
				'label' 		=> __( 'Social Lists', 'artraz' ),
				'type' 			=> Controls_Manager::REPEATER,
				'fields' 		=> $repeater->get_controls(),
				'default' 		=> [
					[
						'social_icon' 		=> __( '<i class="fab fa-facebook-f"></i>', 'artraz' ),
					],
					[
						'social_icon' 		=> __( '<i class="fab fa-skype"></i>', 'artraz' ),
					],
				],
			]
		);

        $this->end_controls_section();


        //---------------------------------------
			//Style Section Start
		//---------------------------------------

        //-------------------------------------Social styling-------------------------------------//

        $this->start_controls_section(
            'social_section',
            [
                'label' => __( ' Social Style', 'artraz' ),
                'tab' 	=> Controls_Manager::TAB_STYLE,
            ]
        );
	
        $this->add_control(
            'social_color',
            [
                'label' 		=> __( 'Color', 'artraz' ),
                'type' 			=> Controls_Manager::COLOR,
                'selectors' 	=> [
                    '{{WRAPPER}} .th-social a'	=> 'color: {{VALUE}}!important;',
                ],
            ]
        );
        	
        $this->add_control(
            'social_stroke_color',
            [
                'label' 		=> __( 'Stroke Color', 'artraz' ),
                'type' 			=> Controls_Manager::COLOR,
                'selectors' 	=> [
                    '{{WRAPPER}} .th-social a'	=> '-webkit-text-stroke-color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_control(
            'social_h_color',
            [
                'label' 		=> __( 'Hover Color', 'artraz' ),
                'type' 			=> Controls_Manager::COLOR,
                'selectors' 	=> [
                    '{{WRAPPER}} .th-social a:hover'	=> 'color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_control(
            'social_h_stroke_color',
            [
                'label' 		=> __( 'Hover Stroke Color', 'artraz' ),
                'type' 			=> Controls_Manager::COLOR,
                'selectors' 	=> [
                    '{{WRAPPER}} .th-social a:hover'	=> '-webkit-text-stroke-color: {{VALUE}}!important;',
                ],
            ]
        );

        $this->add_control(
            'social_size',
            [
                'label' => esc_html__( 'Social size', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px', 'custom' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .th-social a' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
			'social_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .th-social a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();

		

	}

	protected function render() {

        $settings = $this->get_settings_for_display();

		?>

        <?php if( $settings['layout_style'] == '2' ): ?>

        <?php else: ?>
            <div class="th-social">
                <?php  foreach( $settings['social_lists'] as $data ): ?>
                    <a target="_blank" href="<?php echo esc_url( $data['social_link']['url'] ); ?>"><?php echo wp_kses_post($data['social_icon']); ?></a>
                <?php endforeach; ?>
            </div>

        <?php endif;
        
	}
}