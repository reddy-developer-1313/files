<?php
use \Elementor\Widget_Base;
use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Typography;
use \Elementor\Group_Control_Border;
use \Elementor\Utils;
/**
 *
 * Section Title Widget .
 *
 */
class Artraz_Section_Title extends Widget_Base {

	public function get_name() {
		return 'artrazsectiontitle';
	}

	public function get_title() {
		return __( 'Section Title', 'artraz' );
	}

	public function get_icon() {
		return 'th-icon';
    }

	public function get_categories() {
		return [ 'artraz' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_title_section',
			[
				'label'		 	=> __( 'Section Title', 'artraz' ),
				'tab' 			=> Controls_Manager::TAB_CONTENT,
			]
        );

		
		$this->add_control(
			'layout_style',
			[
				'label' 		=> __( 'Layout Style', 'artraz' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> '1',
				'options' 		=> [
					'1'  		=> __( 'Style One', 'artraz' ),
					'2' 		=> __( 'Style Two', 'artraz' ),
					'3' 		=> __( 'Style Three', 'artraz' ),
				],
			]
		);

		$this->add_control(
			'section_bigtitle',
			[
				'label' 	=> __( 'Section Big Title', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( '', 'artraz' ),
                'rows' 		=> '2',
				'condition'	=> [
					'layout_style' => ['2', '3'],
				]
			]
        );

        $this->add_control(
			'section_subtitle',
			[
				'label' 	=> __( 'Section Subtitle', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Subtitle', 'artraz' ),
                'rows' => '2',
				'condition'	=> [
					'layout_style' => ['1', '3'],
				]
			]
        );

        $this->add_control(
			'section_subtitle_tag',
			[
				'label' 	=> __( 'Subitle Tag', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'p'  => 'P',
					'span'  => 'span',
				],
				'default' 	=> 'span',
				'condition'	=> [
					'section_subtitle!' => '',
					'layout_style' => ['1', '3'],
				]
			]
		);

		$this->add_control(
			'section_title',
			[
				'label' 	=> __( 'Section Title', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Title', 'artraz' )
			]
        );

        $this->add_control(
			'section_title_tag',
			[
				'label' 	=> __( 'Title Tag', 'artraz' ),
				'type' 		=> Controls_Manager::SELECT,
				'options' 	=> [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'span'  => 'span',
				],
				'default' => 'h2',
			]
        );

        $this->add_control(
			'section_desc',
			[
				'label' 	=> __( 'Section Description', 'artraz' ),
                'type' 		=> Controls_Manager::TEXTAREA,
                'default'  	=> __( 'Section Description', 'artraz' ),
				'condition' => [
					'layout_style' => '1',
				]
			]
        );

        $this->add_responsive_control(
			'section_align',
			[
				'label' 		=> __( 'Alignment', 'artraz' ),
				'type' 			=> Controls_Manager::CHOOSE,
				'options' 		=> [
					'left' 	=> [
						'title' 		=> __( 'Left', 'artraz' ),
						'icon' 			=> 'eicon-text-align-left',
					],
					'center' 	=> [
						'title' 		=> __( 'Center', 'artraz' ),
						'icon' 			=> 'eicon-text-align-center',
					],
					'right' 	=> [
						'title' 		=> __( 'Right', 'artraz' ),
						'icon' 			=> 'eicon-text-align-right',
					],
				],
				'default' 	=> 'left',
				'toggle' 	=> true,
				'selectors' 	=> [
					'{{WRAPPER}} .sec-title-area' => 'text-align: {{VALUE}};',
                ]
			]
		);

        $this->end_controls_section();


         //---------------------------------------
			//Style Section Start
		//---------------------------------------

		//-------------------------------------General styling-------------------------------------//

        $this->start_controls_section(
			'general_style_section',
			[
				'label' => __( ' General Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

		 $this->add_responsive_control(
			'general_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sec-title-area' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

		$this->end_controls_section();

		 //-------------------------------------Big title styling-------------------------------------//

		 $this->start_controls_section(
			'section_bigtitle_style_section',
			[
				'label' => __( 'Big Title Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
                    'section_bigtitle!'    => '',
					'layout_style' => ['2', '3'],
                ],
			]
		);

		$this->add_control(
			'section_bigtitle_color',
			[
				'label' 		=> __( 'Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-big-title' => 'color: {{VALUE}}!important',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_bigtitle_typography',
				'label' 	=> __( 'Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-big-title',
			]
        );

        $this->add_responsive_control(
			'section_bigtitle_margin',
			[
				'label' 		=> __( 'Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-big-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

			]
        );

        $this->add_responsive_control(
			'section_bigtitle_padding',
			[
				'label' 		=> __( 'Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-big-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->end_controls_section();

		//-------------------------------------subtitle styling-------------------------------------//
		$this->start_controls_section(
			'section_subtitle_style_section',
			[
				'label' => __( ' Subtitle Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
                    'section_subtitle!'    => '',
					'layout_style' => ['1', '3'],
                ],
			]
		);

		$this->add_control(
			'section_subtitle_color',
			[
				'label' 		=> __( '  Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .e-sub-title' => 'color: {{VALUE}}!important',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_subtitle_typography',
				'label' 	=> __( '  Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .e-sub-title',
			]
        );

        $this->add_responsive_control(
			'section_subtitle_margin',
			[
				'label' 		=> __( '  Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

			]
        );

        $this->add_responsive_control(
			'section_subtitle_padding',
			[
				'label' 		=> __( '  Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .e-sub-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
		
        $this->end_controls_section();

        //-------------------------------------Title styling-------------------------------------//
        $this->start_controls_section(
			'section_title_style_section',
			[
				'label' => __( ' Title Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' 	=> [
                    'section_title!'    => ''
                ]
			]
		);

        $this->add_control(
			'section_title_color',
			[
				'label' 	=> __( '  Color', 'artraz' ),
				'type' 		=> Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .sec-title' => 'color: {{VALUE}}!important;',
                ],
			]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_title_typography',
				'label' 	=> __( '  Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .sec-title',
			]
		);

        $this->add_responsive_control(
			'section_title_margin',
			[
				'label' 		=> __( '  Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sec-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );

        $this->add_responsive_control(
			'section_title_padding',
			[
				'label' 		=> __( '  Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sec-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
		);

        $this->end_controls_section();

        //-------------------------------------Description styling-------------------------------------//

        $this->start_controls_section(
			'section_desc_style_section',
			[
				'label' => __( ' Description Style', 'artraz' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
				'condition' => [
                    'section_desc!'    => '',
					'layout_style' => ['1'],
                ],
			]
		);

		$this->add_control(
			'section_desc_color',
			[
				'label' 		=> __( '  Color', 'artraz' ),
				'type' 			=> Controls_Manager::COLOR,
				'selectors' 	=> [
					'{{WRAPPER}} .sec-text' => 'color: {{VALUE}}!important',
                ],
			]
        );


        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' 		=> 'section_desc_typography',
				'label' 	=> __( '  Typography', 'artraz' ),
                'selector' 	=> '{{WRAPPER}} .sec-text',
			]
        );

        $this->add_responsive_control(
			'section_desc_margin',
			[
				'label' 		=> __( '  Margin', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sec-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

			]
        );
        $this->add_responsive_control(
			'section_desc_padding',
			[
				'label' 		=> __( '  Padding', 'artraz' ),
				'type' 			=> Controls_Manager::DIMENSIONS,
				'size_units' 	=> [ 'px', '%', 'em' ],
				'selectors' 	=> [
					'{{WRAPPER}} .sec-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
			]
        );
        $this->end_controls_section();

	}

	protected function render() {

	$settings = $this->get_settings_for_display();

		$this->add_render_attribute('subtitle_args', 'class', 'sub-title e-sub-title');
		$this->add_render_attribute('title_args', 'class', 'sec-title');

		if( $settings['layout_style'] == '2' ){
			$wrap_class = 'title-area sec-title-area';
		}else{
			$wrap_class = 'sec-title-area';
		}
		if( $settings['layout_style'] == '3' ){
			$bs = 'mb-35';
		}else{
			$bs = '';
		}
	?>
		<div class="<?php echo esc_attr($wrap_class); ?>">

			<?php
				if( !empty($settings['section_bigtitle' ]) ){
					echo '<span class="big-title '.esc_attr($bs).' e-big-title">'.esc_html( $settings['section_bigtitle' ]).'</span>';
				}
					
				if ( !empty($settings['section_subtitle' ]) ){
					printf( '<%1$s %2$s>%3$s</%1$s>',
						$settings['section_subtitle_tag'],
						$this->get_render_attribute_string( 'subtitle_args' ),
						wp_kses_post( $settings['section_subtitle' ] )
					);
				}
			
				
				if ( !empty($settings['section_title' ]) ) :
					printf( '<%1$s %2$s>%3$s</%1$s>',
						$settings['section_title_tag'],
						$this->get_render_attribute_string( 'title_args' ),
						wp_kses_post( $settings['section_title' ] )
						);
				endif;

				if( ! empty( $settings['section_desc'] ) ){
					echo artraz_paragraph_tag( array(
						'text'	=> wp_kses_post( $settings['section_desc'] ),
						'class'	=> 'sec-text'
					) );
				}
			?>
		</div>

	<?php
		
	}
}